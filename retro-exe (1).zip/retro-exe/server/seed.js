import { db, now, tx } from './db.js';
import { EXAMPLE_THEMES, ICONPACK_BY_ID } from '../public/js/data/catalog.js';
import { normalizeThemeData, normalizeThemeMeta } from '../public/js/data/schema.js';

const DAY = 86400000;

export function seedExampleThemes(userId) {
  const ins = db.prepare('INSERT INTO themes (user_id, name, description, folder, data, is_example, created_at, updated_at) VALUES (?,?,?,?,?,1,?,?)');
  const t = now();
  EXAMPLE_THEMES.forEach((th, i) => {
    const meta = normalizeThemeMeta(th);
    ins.run(userId, meta.name, meta.description, meta.folder, JSON.stringify(normalizeThemeData(th.data)), t - i * 1000, t - i * 1000);
  });
}

// ---- Sample community content (flagged is_sample = 1, cannot be logged into) ----
const SAMPLE_USERS = [
  ['pixel_wanderer', 'Pixel Wanderer', 'Collecting dithered skies since the dial-up days. 16 colours is plenty.'],
  ['aero_angel', 'aero angel ☁', 'glass, water, bubbles. bring back glossy UI.'],
  ['liminal_lucy', 'Lucy (Liminal)', 'I photograph empty places and turn them into wallpapers. Pools are my weakness.'],
  ['chromekid2000', 'CHROMEKID2000', 'liquid metal enthusiast. y2k forever. ♡'],
  ['memorycard_max', 'Max · Memory Card', 'Rebuilding the vibe of every console boot screen I ever stared at.'],
  ['webring_rosa', 'Rosa @ the Webring', 'Best viewed in 800x600. Sign my guestbook (metaphorically).'],
  ['dreamfield', 'dreamfield', 'have you been here before? i think you have.'],
  ['neon_sysop', 'NEON_SYSOP', 'night shift. cyan on black. keeping the servers warm.'],
];

const T = (wpBase, palette, pack, widgets, stickers, adjust = {}, overlays = {}, caption = {}) => ({
  wallpaper: { base: wpBase, adjust, overlays, caption },
  palette, icons: { ...ICONPACK_BY_ID[pack].config, pack }, widgets, decor: { stickers },
});
const wp = (id) => ({ type: 'wp', id });

const SAMPLE_POSTS = [
  ['pixel_wanderer', 'Cottage at the End of the Save File', 'Pixel night scene with amber icons. Pairs nicely with a pixel clock.', 'pixel,cozy,night', 'pixelcore',
    T(wp('px-night'), ['#1a1035', '#2b2d42', '#ffd166', '#06d6a0', '#f5f0ff'], 'bitmap-garden', { clock: 'pixel', date: 'sticky' }, ['moon', 'star']), 9],
  ['aero_angel', 'Crystal Lagoon Setup', 'My daily driver: glossy aqua icons over the lagoon wallpaper. Feels like 2007 in the best way.', 'aero,water,glossy', 'frutiger-aero',
    T(wp('img-frutiger-aero'), ['#002a4a', '#00b4ff', '#7ee081', '#b8f1ff', '#ffffff'], 'aqua-drop', { clock: 'xp', date: 'pill' }, ['sparkle', 'cloud'], { saturation: 110 }), 2],
  ['liminal_lucy', 'Pool Hall, 2AM (full theme)', 'Teal tiles, outline icons, no people. Add scanlines for extra hum.', 'liminal,pool,eerie', 'liminal',
    T(wp('img-liminal'), ['#0f2a2a', '#2f6f73', '#9fc9c4', '#e8f4f4', '#f2efe6'], 'pool-tile', { clock: 'lcd', h24: true, date: 'minimal' }, [], {}, { scanlines: 25, grain: 20 }, { text: 'nobody is here', style: 'serif', pos: 'bottom' }), 1],
  ['chromekid2000', 'Chrome Heart Drive', 'pink chrome everything. flip clock is mandatory.', 'y2k,chrome,pink', 'y2k',
    T(wp('y2k-chrome'), ['#2a0b3a', '#3a1f5a', '#ff7ad9', '#9be7ff', '#ffffff'], 'chrome-heart', { clock: 'flip', date: 'pill' }, ['heart', 'sparkle', 'butterfly']), 3],
  ['memorycard_max', 'Boot Sequence Blue', 'Glowing towers + memory card icons. The startup sound plays in my head every time.', 'ps2,console,blue', 'ps2',
    T(wp('ps-boot'), ['#000418', '#04145a', '#1e90ff', '#bfe8ff', '#e6f4ff'], 'memory-card', { clock: 'pixel', date: 'pill' }, ['cd']), 4],
  ['webring_rosa', 'Homepage After Dark', 'Starfield, win98 icons in hot pink, and a sticky note to remind you to update your guestbook.', 'oldweb,stars,homepage', 'old-internet',
    T(wp('oi-stars'), ['#000033', '#000080', '#ff00ff', '#ffff00', '#ffffff'], 'webring', { clock: 'lcd', date: 'sticky' }, ['star', 'sparkle', 'cursor']), 5],
  ['dreamfield', 'the door was always open', 'pastel door in the clouds. outline icons. analog clock ticking softly.', 'dreamcore,pastel,door', 'dreamcore',
    T(wp('dc-door'), ['#2a2350', '#f7d6e8', '#c9b6ff', '#ffb8d9', '#fffaf0'], 'pastel-ghost', { clock: 'analog', date: 'minimal' }, ['cloud', 'flower'], {}, { grain: 20 }, { text: 'come back soon', style: 'serif', pos: 'top' }), 6],
  ['neon_sysop', 'Trace Route // night shift', 'cyan circuits, neon icons, 24h LCD. lights off, monitor on.', 'cyber,neon,night', 'cybercore',
    T(wp('cy-circuit'), ['#05071a', '#0b0f2a', '#00f0ff', '#ff00a8', '#e6fbff'], 'neon-grid', { clock: 'lcd', h24: true, date: 'minimal' }, ['eye'], {}, { scanlines: 30, chroma: 25 }), 7],
  ['aero_angel', 'Fresh Install', 'green hills, glossy bubbles, everything is fine forever.', 'aero,hills,fresh', 'frutiger-aero',
    T(wp('fa-install'), ['#00335a', '#0a8fff', '#9be15d', '#c9f1ff', '#ffffff'], 'luna-glass', { clock: 'xp', date: 'pill' }, ['sparkle']), 8],
  ['liminal_lucy', 'Yellow Hall Forever', "Fluorescent hum, mustard carpet. Don't noclip.", 'liminal,hallway,yellow', 'liminal',
    T(wp('lm-yellow'), ['#2a2410', '#3a3420', '#d9cf8f', '#fffbe0', '#fffbe0'], 'pool-tile', { clock: 'lcd', h24: true, date: 'minimal' }, [], {}, { vhs: 30, grain: 30 }), 10],
  ['dreamfield', 'are you still there?', 'the checkerboard watches back.', 'weirdcore,eye,checker', 'weirdcore',
    T(wp('wd-eye'), ['#2a2340', '#e9e4ff', '#ff9db5', '#a8e6ff', '#ffffff'], 'eyeball-club', { clock: 'analog', date: 'sticky' }, ['eye', 'smiley'], {}, {}, { text: 'are you still there?', style: 'dialog', pos: 'center' }), 11],
  ['chromekid2000', 'Marble Mall Sunset', 'vaporwave sticker icons, sunset grid. ＡＥＳＴＨＥＴＩＣ.', 'vaporwave,sunset,neon', 'vaporwave',
    T(wp('img-vaporwave'), ['#1a0033', '#3a0a5a', '#ff71ce', '#01cdfe', '#fffb96'], 'sticker-sunset', { clock: 'flip', date: 'pill' }, ['star', 'cd']), 12],
  ['pixel_wanderer', 'Arcade Dusk', 'Warm pixel sunset with CRT amber icons.', 'pixel,sunset,retro', 'pixelcore',
    T(wp('rc-arcade'), ['#2a1f3a', '#3a2a5a', '#ffb36b', '#ffd27a', '#fff1d6'], 'crt-amber', { clock: 'pixel', date: 'calendar98' }, ['loading']), 13],
  ['memorycard_max', 'Summer 2004 Save Point', 'Low-poly beach town. You can almost hear the menu music.', 'ps2,summer,lowpoly', 'ps2',
    T(wp('img-ps2'), ['#04145a', '#0a2a8a', '#1e90ff', '#f5c542', '#ffffff'], 'memory-card', { clock: 'pixel', date: 'pill' }, ['star'], { saturation: 110 }), 14],
];

export function seedSampleCommunity() {
  const existing = db.prepare('SELECT COUNT(*) c FROM users WHERE is_sample = 1').get().c;
  if (existing > 0) return;
  tx(() => {
    const t = now();
    const insU = db.prepare('INSERT INTO users (username, display_name, bio, is_guest, is_sample, created_at) VALUES (?,?,?,0,1,?)');
    const ids = {};
    SAMPLE_USERS.forEach(([u, d, b], i) => { ids[u] = insU.run(u, d, b, t - (60 + i * 7) * DAY).lastInsertRowid; });
    const insP = db.prepare('INSERT INTO posts (user_id, title, description, tags, aesthetic, theme, created_at) VALUES (?,?,?,?,?,?,?)');
    const postIds = SAMPLE_POSTS.map(([u, title, desc, tags, aes, theme, daysAgo]) =>
      insP.run(ids[u], title, desc, tags, aes, JSON.stringify(normalizeThemeData(theme)), t - daysAgo * DAY - (daysAgo * 3631000) % DAY).lastInsertRowid);
    // deterministic sample likes/follows so trending looks organic
    const insL = db.prepare('INSERT OR IGNORE INTO likes (user_id, post_id, created_at) VALUES (?,?,?)');
    const insF = db.prepare('INSERT OR IGNORE INTO follows (follower_id, followee_id, created_at) VALUES (?,?,?)');
    const uids = Object.values(ids);
    postIds.forEach((pid, pi) => uids.forEach((uid, ui) => { if ((pi * 7 + ui * 3) % 5 < 3) insL.run(uid, pid, t - ((pi + ui) % 9) * DAY); }));
    uids.forEach((a, i) => uids.forEach((b, j) => { if (a !== b && (i + j * 2) % 3 === 0) insF.run(a, b, t - (i + j) * DAY); }));
  })();
}

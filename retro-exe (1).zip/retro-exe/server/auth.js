import crypto from 'node:crypto';
import { db, now } from './db.js';

const SESSION_TTL = 1000 * 60 * 60 * 24 * 30; // 30 days
const SCRYPT = { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };

export function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(password, salt, 64, SCRYPT);
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}

export function verifyPassword(password, stored) {
  if (!stored || typeof stored !== 'string') return false;
  const [alg, s, k] = stored.split('$');
  if (alg !== 'scrypt' || !s || !k) return false;
  const expected = Buffer.from(k, 'base64');
  const actual = crypto.scryptSync(password, Buffer.from(s, 'base64'), expected.length, SCRYPT);
  return crypto.timingSafeEqual(expected, actual);
}

const sha256 = (t) => crypto.createHash('sha256').update(t).digest('hex');

export function createSession(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const t = now();
  db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?,?,?,?)').run(sha256(token), userId, t, t + SESSION_TTL);
  return token;
}

export function destroySession(token) {
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
}

const getSession = db.prepare(`SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?`);

/** Reads a Bearer token (we avoid cookies so the app works inside embedded previews and is CSRF-immune). */
export function authenticate(req, _res, next) {
  const h = req.get('authorization') || '';
  const m = /^Bearer ([A-Za-z0-9_-]{20,100})$/.exec(h);
  req.token = m ? m[1] : null;
  req.user = m ? getSession.get(sha256(m[1]), now()) || null : null;
  next();
}

export class HttpError extends Error {
  constructor(status, message, code) { super(message); this.status = status; this.code = code; }
}

export const requireUser = (req, _res, next) => (req.user ? next() : next(new HttpError(401, 'Your session has expired. Reload to start a new one.', 'NO_SESSION')));
export const requireAccount = (req, _res, next) => {
  if (!req.user) return next(new HttpError(401, 'Please sign in first.', 'NO_SESSION'));
  if (req.user.is_guest) return next(new HttpError(403, 'Create a free account to use community features.', 'ACCOUNT_REQUIRED'));
  next();
};
export const requireMod = (req, _res, next) => {
  if (!req.user || !['mod', 'admin'].includes(req.user.role)) return next(new HttpError(403, 'Moderator access required.', 'FORBIDDEN'));
  next();
};

// Simple fixed-window in-memory rate limiter (swap for Redis when horizontally scaling).
const buckets = new Map();
export function rateLimit(name, max, windowMs, keyFn = (req) => (req.user ? `u${req.user.id}` : req.ip)) {
  return (req, _res, next) => {
    const key = `${name}:${keyFn(req)}`;
    const t = now();
    let b = buckets.get(key);
    if (!b || b.reset < t) { b = { count: 0, reset: t + windowMs }; buckets.set(key, b); }
    b.count++;
    if (b.count > max) return next(new HttpError(429, `Slow down! Too many requests — try again in ${Math.ceil((b.reset - t) / 1000)}s.`, 'RATE_LIMITED'));
    next();
  };
}
setInterval(() => { const t = now(); for (const [k, b] of buckets) if (b.reset < t) buckets.delete(k); }, 60000).unref();
setInterval(() => db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now()), 3600000).unref();

export function publicUser(u) {
  if (!u) return null;
  let prefs = {};
  try { prefs = JSON.parse(u.prefs || '{}'); } catch {}
  return { id: u.id, username: u.username, displayName: u.display_name, bio: u.bio, isGuest: !!u.is_guest, isSample: !!u.is_sample, role: u.role, prefs, createdAt: u.created_at };
}

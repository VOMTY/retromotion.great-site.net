import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db, now, tx, UPLOAD_DIR } from './db.js';
import { authenticate, createSession, destroySession, hashPassword, verifyPassword, requireUser, requireAccount, requireMod, rateLimit, HttpError, publicUser } from './auth.js';
import { seedExampleThemes, seedSampleCommunity } from './seed.js';
import { normalizeThemeData, normalizeThemeMeta, normalizeComposition, ITEM_TYPES, isItemId } from '../public/js/data/schema.js';
import { AESTHETIC_BY_ID } from '../public/js/data/catalog.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const PORT = Number(process.env.PORT || 3000);
const AI_DAILY_LIMIT = Number(process.env.AI_DAILY_LIMIT || 5);
const MOD_USERNAMES = (process.env.MOD_USERNAMES || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
const AUTO_HIDE_REPORTS = 3;

seedSampleCommunity();

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

// ---------- security headers ----------
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', [
    "default-src 'self'", "script-src 'self'", "style-src 'self' 'unsafe-inline'", "img-src 'self' data: blob:",
    "font-src 'self' data:", "connect-src 'self'", "object-src 'none'", "base-uri 'self'", "form-action 'self'",
  ].join('; '));
  next();
});

app.use('/api', express.json({ limit: '64kb' }));
app.use('/api', authenticate);

// ---------- helpers ----------
const wrap = (fn) => (req, res, next) => { try { const r = fn(req, res, next); if (r && r.catch) r.catch(next); } catch (e) { next(e); } };
const str = (v, max) => (typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max) : '');
const idParam = (v) => { const n = Number(v); if (!Number.isInteger(n) || n < 1) throw new HttpError(400, 'Invalid id'); return n; };
const parseJSON = (s, d) => { try { return JSON.parse(s); } catch { return d; } };
const checkItem = (type, id) => {
  if (!ITEM_TYPES.includes(type)) throw new HttpError(400, 'Unknown item type');
  if (!isItemId(String(id))) throw new HttpError(400, 'Invalid item id');
  return [type, String(id)];
};

function createUser({ username = null, passwordHash = null, displayName, isGuest }) {
  const r = db.prepare('INSERT INTO users (username, password_hash, display_name, is_guest, created_at) VALUES (?,?,?,?,?)')
    .run(username, passwordHash, displayName, isGuest ? 1 : 0, now());
  seedExampleThemes(r.lastInsertRowid);
  return db.prepare('SELECT * FROM users WHERE id = ?').get(r.lastInsertRowid);
}

function maybePromote(user) {
  // MOD_USERNAMES env wins; otherwise the very first real account becomes admin so a fresh deploy can moderate.
  const hasAdmin = db.prepare("SELECT 1 FROM users WHERE role IN ('mod','admin') AND is_sample = 0 LIMIT 1").get();
  if (MOD_USERNAMES.includes(String(user.username).toLowerCase())) db.prepare("UPDATE users SET role='mod' WHERE id=?").run(user.id);
  else if (!hasAdmin && !MOD_USERNAMES.length) db.prepare("UPDATE users SET role='admin' WHERE id=?").run(user.id);
}

function stats(userId) {
  const c = (sql) => db.prepare(sql).get(userId).c;
  return {
    themes: c('SELECT COUNT(*) c FROM themes WHERE user_id=?'), favorites: c('SELECT COUNT(*) c FROM favorites WHERE user_id=?'),
    collections: c('SELECT COUNT(*) c FROM collections WHERE user_id=?'), creations: c('SELECT COUNT(*) c FROM creations WHERE user_id=?'),
    posts: c("SELECT COUNT(*) c FROM posts WHERE user_id=? AND status != 'removed'"),
    followers: c('SELECT COUNT(*) c FROM follows WHERE followee_id=?'), following: c('SELECT COUNT(*) c FROM follows WHERE follower_id=?'),
  };
}

// ---------- auth ----------
const USERNAME_RE = /^[a-z0-9_]{3,20}$/i;

app.post('/api/auth/guest', rateLimit('guest', 30, 3600000, (r) => r.ip), wrap((req, res) => {
  const user = createUser({ displayName: 'Guest', isGuest: true });
  db.prepare('UPDATE users SET display_name=? WHERE id=?').run(`Guest ${String(user.id).padStart(4, '0')}`, user.id);
  const token = createSession(user.id);
  res.status(201).json({ token, user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(user.id)) });
}));

app.get('/api/me', requireUser, (req, res) => res.json({ user: publicUser(req.user), stats: stats(req.user.id) }));

app.post('/api/auth/register', rateLimit('register', 10, 3600000, (r) => r.ip), wrap((req, res) => {
  const username = str(req.body.username, 20);
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const displayName = str(req.body.displayName, 40) || username;
  if (!USERNAME_RE.test(username)) throw new HttpError(400, 'Usernames are 3–20 characters: letters, numbers and underscores.');
  if (password.length < 8 || password.length > 200) throw new HttpError(400, 'Passwords need at least 8 characters.');
  if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(username)) throw new HttpError(409, 'That username is taken.');
  const hash = hashPassword(password);
  let user;
  if (req.user && req.user.is_guest) {
    // upgrade the current guest so all their saved stuff comes along
    db.prepare('UPDATE users SET username=?, password_hash=?, display_name=?, is_guest=0 WHERE id=?').run(username, hash, displayName, req.user.id);
    user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
    destroySession(req.token);
  } else {
    user = createUser({ username, passwordHash: hash, displayName, isGuest: false });
  }
  maybePromote(user);
  user = db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
  res.status(201).json({ token: createSession(user.id), user: publicUser(user) });
}));

app.post('/api/auth/login', rateLimit('login', 20, 900000, (r) => r.ip), wrap((req, res) => {
  const username = str(req.body.username, 20);
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const user = db.prepare('SELECT * FROM users WHERE username = ? AND is_sample = 0').get(username);
  if (!user || !verifyPassword(password, user.password_hash)) throw new HttpError(401, 'Wrong username or password.');
  let merged = 0;
  if (req.user && req.user.is_guest && req.user.id !== user.id) {
    // carry the guest's personal work into the account, then discard the guest
    const g = req.user.id;
    tx(() => {
      merged += db.prepare('UPDATE themes SET user_id=? WHERE user_id=? AND is_example=0').run(user.id, g).changes;
      merged += db.prepare('UPDATE creations SET user_id=? WHERE user_id=?').run(user.id, g).changes;
      merged += db.prepare('UPDATE collections SET user_id=? WHERE user_id=?').run(user.id, g).changes;
      merged += db.prepare('UPDATE uploads SET user_id=? WHERE user_id=?').run(user.id, g).changes;
      merged += db.prepare('INSERT OR IGNORE INTO favorites SELECT ?, item_type, item_id, created_at FROM favorites WHERE user_id=?').run(user.id, g).changes;
      db.prepare('DELETE FROM users WHERE id=?').run(g);
    })();
  } else destroySession(req.token);
  res.json({ token: createSession(user.id), user: publicUser(user), merged });
}));

app.post('/api/auth/logout', (req, res) => { destroySession(req.token); res.json({ ok: true }); });

app.patch('/api/me', requireUser, wrap((req, res) => {
  const u = req.user;
  const displayName = req.body.displayName !== undefined ? str(req.body.displayName, 40) || u.display_name : u.display_name;
  const bio = req.body.bio !== undefined ? str(req.body.bio, 200) : u.bio;
  let prefs = parseJSON(u.prefs, {});
  if (req.body.prefs && typeof req.body.prefs === 'object') {
    const p = req.body.prefs;
    if (p.activeThemeId === null || Number.isInteger(p.activeThemeId)) prefs.activeThemeId = p.activeThemeId;
  }
  db.prepare('UPDATE users SET display_name=?, bio=?, prefs=? WHERE id=?').run(displayName, bio, JSON.stringify(prefs), u.id);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(u.id)) });
}));

app.delete('/api/me', requireUser, wrap((req, res) => {
  const u = req.user;
  if (!u.is_guest && !verifyPassword(String(req.body?.password || ''), u.password_hash)) throw new HttpError(401, 'Password is incorrect.');
  const files = db.prepare('SELECT filename FROM uploads WHERE user_id=?').all(u.id);
  db.prepare('DELETE FROM users WHERE id=?').run(u.id);
  files.forEach((f) => fs.rm(path.join(UPLOAD_DIR, f.filename), { force: true }, () => {}));
  res.json({ ok: true });
}));

app.get('/api/me/export', requireUser, (req, res) => {
  const id = req.user.id;
  const themes = db.prepare('SELECT * FROM themes WHERE user_id=?').all(id).map((t) => ({ ...t, data: parseJSON(t.data, {}) }));
  res.setHeader('Content-Disposition', 'attachment; filename="retro-exe-my-data.json"');
  res.json({
    exportedAt: new Date().toISOString(), user: publicUser(req.user), themes,
    creations: db.prepare('SELECT * FROM creations WHERE user_id=?').all(id).map((c) => ({ ...c, config: parseJSON(c.config, {}) })),
    favorites: db.prepare('SELECT * FROM favorites WHERE user_id=?').all(id),
    collections: db.prepare('SELECT * FROM collections WHERE user_id=?').all(id).map((c) => ({ ...c, items: db.prepare('SELECT item_type, item_id FROM collection_items WHERE collection_id=?').all(c.id) })),
    posts: db.prepare('SELECT id, title, description, tags, created_at FROM posts WHERE user_id=?').all(id),
  });
});

// ---------- favorites ----------
app.get('/api/favorites', requireUser, (req, res) => {
  res.json({ favorites: db.prepare('SELECT item_type type, item_id id, created_at createdAt FROM favorites WHERE user_id=? ORDER BY created_at DESC').all(req.user.id) });
});
app.post('/api/favorites', requireUser, wrap((req, res) => {
  const [type, id] = checkItem(req.body.type, req.body.id);
  if (db.prepare('SELECT COUNT(*) c FROM favorites WHERE user_id=?').get(req.user.id).c >= 2000) throw new HttpError(400, 'Favorite limit reached (2000).');
  db.prepare('INSERT OR IGNORE INTO favorites VALUES (?,?,?,?)').run(req.user.id, type, id, now());
  res.status(201).json({ ok: true });
}));
app.delete('/api/favorites/:type/:id', requireUser, wrap((req, res) => {
  const [type, id] = checkItem(req.params.type, req.params.id);
  db.prepare('DELETE FROM favorites WHERE user_id=? AND item_type=? AND item_id=?').run(req.user.id, type, id);
  res.json({ ok: true });
}));

// ---------- recently viewed ----------
app.get('/api/recent', requireUser, (req, res) => {
  res.json({ recent: db.prepare('SELECT item_type type, item_id id, viewed_at viewedAt FROM recent WHERE user_id=? ORDER BY viewed_at DESC LIMIT 12').all(req.user.id) });
});
app.post('/api/recent', requireUser, wrap((req, res) => {
  const [type, id] = checkItem(req.body.type, req.body.id);
  db.prepare('INSERT INTO recent VALUES (?,?,?,?) ON CONFLICT(user_id,item_type,item_id) DO UPDATE SET viewed_at=excluded.viewed_at').run(req.user.id, type, id, now());
  db.prepare('DELETE FROM recent WHERE user_id=? AND rowid NOT IN (SELECT rowid FROM recent WHERE user_id=? ORDER BY viewed_at DESC LIMIT 30)').run(req.user.id, req.user.id);
  res.json({ ok: true });
}));
app.delete('/api/recent', requireUser, (req, res) => { db.prepare('DELETE FROM recent WHERE user_id=?').run(req.user.id); res.json({ ok: true }); });

// ---------- collections ----------
function collectionsFor(userId) {
  const cols = db.prepare('SELECT id, name, description, created_at createdAt FROM collections WHERE user_id=? ORDER BY created_at DESC').all(userId);
  const items = db.prepare('SELECT item_type type, item_id id, added_at addedAt FROM collection_items WHERE collection_id=? ORDER BY added_at DESC');
  return cols.map((c) => ({ ...c, items: items.all(c.id) }));
}
const ownCollection = (req) => {
  const c = db.prepare('SELECT * FROM collections WHERE id=? AND user_id=?').get(idParam(req.params.id), req.user.id);
  if (!c) throw new HttpError(404, 'Collection not found.');
  return c;
};
app.get('/api/collections', requireUser, (req, res) => res.json({ collections: collectionsFor(req.user.id) }));
app.post('/api/collections', requireUser, wrap((req, res) => {
  const name = str(req.body.name, 50);
  if (!name) throw new HttpError(400, 'Give your collection a name.');
  if (db.prepare('SELECT COUNT(*) c FROM collections WHERE user_id=?').get(req.user.id).c >= 100) throw new HttpError(400, 'Collection limit reached (100).');
  const r = db.prepare('INSERT INTO collections (user_id, name, description, created_at) VALUES (?,?,?,?)').run(req.user.id, name, str(req.body.description, 200), now());
  res.status(201).json({ collection: collectionsFor(req.user.id).find((c) => c.id === r.lastInsertRowid) });
}));
app.patch('/api/collections/:id', requireUser, wrap((req, res) => {
  const c = ownCollection(req);
  const name = req.body.name !== undefined ? str(req.body.name, 50) || c.name : c.name;
  const description = req.body.description !== undefined ? str(req.body.description, 200) : c.description;
  db.prepare('UPDATE collections SET name=?, description=? WHERE id=?').run(name, description, c.id);
  res.json({ ok: true });
}));
app.delete('/api/collections/:id', requireUser, wrap((req, res) => { const c = ownCollection(req); db.prepare('DELETE FROM collections WHERE id=?').run(c.id); res.json({ ok: true }); }));
app.post('/api/collections/:id/items', requireUser, wrap((req, res) => {
  const c = ownCollection(req);
  const [type, id] = checkItem(req.body.type, req.body.id);
  if (db.prepare('SELECT COUNT(*) c FROM collection_items WHERE collection_id=?').get(c.id).c >= 500) throw new HttpError(400, 'This collection is full (500 items).');
  const r = db.prepare('INSERT OR IGNORE INTO collection_items VALUES (?,?,?,?)').run(c.id, type, id, now());
  res.status(201).json({ ok: true, added: r.changes > 0 });
}));
app.delete('/api/collections/:id/items/:type/:itemId', requireUser, wrap((req, res) => {
  const c = ownCollection(req);
  const [type, id] = checkItem(req.params.type, req.params.itemId);
  db.prepare('DELETE FROM collection_items WHERE collection_id=? AND item_type=? AND item_id=?').run(c.id, type, id);
  res.json({ ok: true });
}));

// ---------- themes ----------
const themeOut = (t) => ({ id: t.id, name: t.name, description: t.description, folder: t.folder, isExample: !!t.is_example, createdAt: t.created_at, updatedAt: t.updated_at, data: parseJSON(t.data, {}) });
const ownTheme = (req) => {
  const t = db.prepare('SELECT * FROM themes WHERE id=? AND user_id=?').get(idParam(req.params.id), req.user.id);
  if (!t) throw new HttpError(404, 'Theme not found.');
  return t;
};
app.get('/api/themes', requireUser, (req, res) => res.json({ themes: db.prepare('SELECT * FROM themes WHERE user_id=? ORDER BY updated_at DESC').all(req.user.id).map(themeOut) }));
app.post('/api/themes', requireUser, wrap((req, res) => {
  if (db.prepare('SELECT COUNT(*) c FROM themes WHERE user_id=?').get(req.user.id).c >= 200) throw new HttpError(400, 'Theme limit reached (200). Delete a few first.');
  const meta = normalizeThemeMeta(req.body);
  const data = normalizeThemeData(req.body.data);
  const t = now();
  const r = db.prepare('INSERT INTO themes (user_id, name, description, folder, data, created_at, updated_at) VALUES (?,?,?,?,?,?,?)').run(req.user.id, meta.name, meta.description, meta.folder, JSON.stringify(data), t, t);
  res.status(201).json({ theme: themeOut(db.prepare('SELECT * FROM themes WHERE id=?').get(r.lastInsertRowid)) });
}));
app.patch('/api/themes/:id', requireUser, wrap((req, res) => {
  const t = ownTheme(req);
  const meta = normalizeThemeMeta({ name: req.body.name ?? t.name, description: req.body.description ?? t.description, folder: req.body.folder ?? t.folder });
  const data = req.body.data !== undefined ? normalizeThemeData(req.body.data) : parseJSON(t.data, {});
  db.prepare('UPDATE themes SET name=?, description=?, folder=?, data=?, updated_at=? WHERE id=?').run(meta.name, meta.description, meta.folder, JSON.stringify(data), now(), t.id);
  res.json({ theme: themeOut(db.prepare('SELECT * FROM themes WHERE id=?').get(t.id)) });
}));
app.post('/api/themes/:id/duplicate', requireUser, wrap((req, res) => {
  const t = ownTheme(req);
  const ts = now();
  const name = `${t.name} (copy)`.slice(0, 60);
  const r = db.prepare('INSERT INTO themes (user_id, name, description, folder, data, created_at, updated_at) VALUES (?,?,?,?,?,?,?)').run(req.user.id, name, t.description, t.folder, t.data, ts, ts);
  res.status(201).json({ theme: themeOut(db.prepare('SELECT * FROM themes WHERE id=?').get(r.lastInsertRowid)) });
}));
app.delete('/api/themes/:id', requireUser, wrap((req, res) => { const t = ownTheme(req); db.prepare('DELETE FROM themes WHERE id=?').run(t.id); res.json({ ok: true }); }));

// ---------- creations (custom wallpaper compositions) ----------
const creationOut = (c) => ({ id: c.id, name: c.name, config: parseJSON(c.config, {}), createdAt: c.created_at, updatedAt: c.updated_at });
app.get('/api/creations', requireUser, (req, res) => res.json({ creations: db.prepare('SELECT * FROM creations WHERE user_id=? ORDER BY updated_at DESC').all(req.user.id).map(creationOut) }));
app.post('/api/creations', requireUser, wrap((req, res) => {
  if (db.prepare('SELECT COUNT(*) c FROM creations WHERE user_id=?').get(req.user.id).c >= 300) throw new HttpError(400, 'Creation limit reached (300).');
  const t = now();
  const r = db.prepare('INSERT INTO creations (user_id, name, config, created_at, updated_at) VALUES (?,?,?,?,?)').run(req.user.id, str(req.body.name, 60) || 'Untitled Creation', JSON.stringify(normalizeComposition(req.body.config)), t, t);
  res.status(201).json({ creation: creationOut(db.prepare('SELECT * FROM creations WHERE id=?').get(r.lastInsertRowid)) });
}));
app.patch('/api/creations/:id', requireUser, wrap((req, res) => {
  const c = db.prepare('SELECT * FROM creations WHERE id=? AND user_id=?').get(idParam(req.params.id), req.user.id);
  if (!c) throw new HttpError(404, 'Creation not found.');
  const name = req.body.name !== undefined ? str(req.body.name, 60) || c.name : c.name;
  const config = req.body.config !== undefined ? JSON.stringify(normalizeComposition(req.body.config)) : c.config;
  db.prepare('UPDATE creations SET name=?, config=?, updated_at=? WHERE id=?').run(name, config, now(), c.id);
  res.json({ creation: creationOut(db.prepare('SELECT * FROM creations WHERE id=?').get(c.id)) });
}));
app.delete('/api/creations/:id', requireUser, wrap((req, res) => {
  const r = db.prepare('DELETE FROM creations WHERE id=? AND user_id=?').run(idParam(req.params.id), req.user.id);
  if (!r.changes) throw new HttpError(404, 'Creation not found.');
  res.json({ ok: true });
}));

// ---------- uploads (user images for the wallpaper studio) ----------
const MAGIC = [
  { mime: 'image/png', ext: 'png', test: (b) => b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 },
  { mime: 'image/jpeg', ext: 'jpg', test: (b) => b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { mime: 'image/webp', ext: 'webp', test: (b) => b.length > 12 && b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP' },
];
function storeImage(userId, buf, kind = 'upload') {
  const fmt = MAGIC.find((m) => m.test(buf));
  if (!fmt) throw new HttpError(415, 'Only PNG, JPEG or WebP images are supported.');
  const filename = `${crypto.randomBytes(12).toString('hex')}.${fmt.ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, filename), buf);
  db.prepare('INSERT INTO uploads (user_id, filename, mime, size, kind, created_at) VALUES (?,?,?,?,?,?)').run(userId, filename, fmt.mime, buf.length, kind, now());
  return `/uploads/${filename}`;
}
app.post('/api/uploads', requireUser, rateLimit('upload', 30, 3600000),
  express.raw({ type: ['image/png', 'image/jpeg', 'image/webp'], limit: '6mb' }),
  wrap((req, res) => {
    if (!Buffer.isBuffer(req.body) || !req.body.length) throw new HttpError(400, 'No image received (max 6 MB, PNG/JPEG/WebP).');
    const used = db.prepare('SELECT COALESCE(SUM(size),0) s FROM uploads WHERE user_id=?').get(req.user.id).s;
    if (used + req.body.length > 60 * 1024 * 1024) throw new HttpError(400, 'Storage quota reached (60 MB). Delete some uploads first.');
    res.status(201).json({ url: storeImage(req.user.id, req.body) });
  }));
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '30d', immutable: true, index: false, setHeaders: (res) => res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'") }));

// ---------- AI wallpaper generation (server-side only, key never leaves the server) ----------
const AI_KEY = process.env.OPENAI_API_KEY || '';
const AI_MODEL = process.env.OPENAI_IMAGE_MODEL || 'gpt-image-1';
const today = () => new Date().toISOString().slice(0, 10);
const aiUsed = (uid) => db.prepare('SELECT count FROM ai_usage WHERE user_id=? AND day=?').get(uid, today())?.count || 0;
app.get('/api/ai/status', requireUser, (req, res) => res.json({ enabled: !!AI_KEY, limit: AI_DAILY_LIMIT, used: aiUsed(req.user.id), requiresAccount: true }));
app.post('/api/ai/generate', requireAccount, rateLimit('ai', 6, 60000), wrap(async (req, res) => {
  if (!AI_KEY) throw new HttpError(503, 'AI generation is not configured on this server. Set OPENAI_API_KEY to enable it — the Dream Generator works offline in the meantime.', 'AI_DISABLED');
  const prompt = str(req.body.prompt, 400);
  if (prompt.length < 4) throw new HttpError(400, 'Describe your wallpaper in a few words.');
  if (aiUsed(req.user.id) >= AI_DAILY_LIMIT) throw new HttpError(429, `Daily AI limit reached (${AI_DAILY_LIMIT}/day). Try the Dream Generator, or come back tomorrow.`, 'AI_LIMIT');
  db.prepare('INSERT INTO ai_usage VALUES (?,?,1) ON CONFLICT(user_id,day) DO UPDATE SET count=count+1').run(req.user.id, today());
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 90000);
  try {
    const r = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST', signal: ctrl.signal,
      headers: { Authorization: `Bearer ${AI_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: AI_MODEL, size: '1536x1024', n: 1, prompt: `Nostalgic retro aesthetic desktop wallpaper, no text, no logos. ${prompt}` }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.data?.[0]?.b64_json) {
      db.prepare('UPDATE ai_usage SET count=MAX(0,count-1) WHERE user_id=? AND day=?').run(req.user.id, today());
      throw new HttpError(502, j.error?.message ? `The image service declined: ${j.error.message}` : 'The image service did not return an image. Please try again.', 'AI_UPSTREAM');
    }
    const url = storeImage(req.user.id, Buffer.from(j.data[0].b64_json, 'base64'), 'ai');
    res.status(201).json({ url, used: aiUsed(req.user.id), limit: AI_DAILY_LIMIT });
  } catch (e) {
    if (e.name === 'AbortError') throw new HttpError(504, 'The image service timed out. Please try again.', 'AI_TIMEOUT');
    throw e;
  } finally { clearTimeout(timer); }
}));

// ---------- community ----------
function postsQuery(viewerId, { where = [], params = [], order = 'p.created_at DESC', limit = 24, offset = 0 }) {
  const sql = `
    SELECT p.*, u.username, u.display_name, u.is_sample,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id) AS like_count,
      EXISTS(SELECT 1 FROM likes l WHERE l.post_id = p.id AND l.user_id = @viewer) AS liked,
      EXISTS(SELECT 1 FROM follows f WHERE f.followee_id = p.user_id AND f.follower_id = @viewer) AS following,
      EXISTS(SELECT 1 FROM reports r WHERE r.post_id = p.id AND r.reporter_id = @viewer) AS reported
    FROM posts p JOIN users u ON u.id = p.user_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY ${order} LIMIT @limit OFFSET @offset`;
  return db.prepare(sql).all({ viewer: viewerId || 0, limit, offset, ...Object.assign({}, ...params) }).map((p) => postOut(p, viewerId));
}
function postOut(p, viewerId) {
  return {
    id: p.id, title: p.title, description: p.description, tags: p.tags ? p.tags.split(',').filter(Boolean) : [], aesthetic: p.aesthetic,
    theme: parseJSON(p.theme, {}), status: p.status, createdAt: p.created_at, likes: p.like_count, liked: !!p.liked, reported: !!p.reported,
    author: { id: p.user_id, username: p.username, displayName: p.display_name, isSample: !!p.is_sample, following: !!p.following, isMe: p.user_id === viewerId },
  };
}

app.get('/api/posts', wrap((req, res) => {
  const viewer = req.user?.id || 0;
  const isMod = req.user && ['mod', 'admin'].includes(req.user.role);
  const where = ["p.status = 'visible'"];
  const params = [];
  const q = str(req.query.q, 80).toLowerCase();
  if (q) {
    where.push("(lower(p.title) LIKE @q OR lower(p.description) LIKE @q OR lower(p.tags) LIKE @q OR lower(u.username) LIKE @q OR lower(u.display_name) LIKE @q OR lower(p.aesthetic) LIKE @q)");
    params.push({ q: `%${q.replace(/[%_]/g, '')}%` });
  }
  const aesthetic = str(req.query.aesthetic, 30);
  if (aesthetic && AESTHETIC_BY_ID[aesthetic]) { where.push('p.aesthetic = @aes'); params.push({ aes: aesthetic }); }
  if (req.query.samples === '0') where.push('u.is_sample = 0');
  if (req.query.author) {
    where[0] = isMod || (req.user && String(req.query.author).toLowerCase() === String(req.user.username || '').toLowerCase()) ? "p.status != 'removed'" : where[0];
    where.push('u.username = @author'); params.push({ author: str(req.query.author, 20) });
  }
  const sort = req.query.sort;
  if (sort === 'following') {
    if (!viewer) return res.json({ posts: [], hasMore: false });
    where.push('p.user_id IN (SELECT followee_id FROM follows WHERE follower_id = @viewer)');
  }
  // trending: likes decayed by age (hours)
  const order = sort === 'new' || sort === 'following' ? 'p.created_at DESC'
    : `(like_count + 1.0) / ((((${now()} - p.created_at) / 3600000.0) + 2) * 0.15 + 1) DESC, p.created_at DESC`;
  const limit = Math.min(48, Math.max(1, Number(req.query.limit) || 24));
  const offset = Math.max(0, Number(req.query.offset) || 0);
  const posts = postsQuery(viewer, { where, params, order, limit: limit + 1, offset });
  res.json({ posts: posts.slice(0, limit), hasMore: posts.length > limit });
}));

app.get('/api/posts/:id', wrap((req, res) => {
  const isMod = req.user && ['mod', 'admin'].includes(req.user.role);
  const [p] = postsQuery(req.user?.id, { where: ['p.id = @id'], params: [{ id: idParam(req.params.id) }], limit: 1 });
  if (!p || (p.status !== 'visible' && !isMod && !p.author.isMe)) throw new HttpError(404, 'This post is unavailable.');
  res.json({ post: p });
}));

app.post('/api/posts', requireAccount, rateLimit('post', 10, 3600000), wrap((req, res) => {
  const title = str(req.body.title, 80);
  if (title.length < 3) throw new HttpError(400, 'Titles need at least 3 characters.');
  let theme;
  if (req.body.themeId) {
    const t = db.prepare('SELECT data FROM themes WHERE id=? AND user_id=?').get(idParam(req.body.themeId), req.user.id);
    if (!t) throw new HttpError(404, 'Theme not found.');
    theme = normalizeThemeData(parseJSON(t.data, {}));
  } else theme = normalizeThemeData(req.body.theme);
  if (theme.wallpaper.base.type === 'upload') {
    // only allow the poster's own uploads to be shared publicly
    const fn = theme.wallpaper.base.url.split('/').pop();
    if (!db.prepare('SELECT 1 FROM uploads WHERE filename=? AND user_id=?').get(fn, req.user.id)) throw new HttpError(400, 'You can only share images you uploaded.');
  }
  const tags = (Array.isArray(req.body.tags) ? req.body.tags : String(req.body.tags || '').split(','))
    .map((t) => str(String(t), 24).toLowerCase().replace(/[^a-z0-9-]/g, '')).filter(Boolean).slice(0, 6);
  const aesthetic = AESTHETIC_BY_ID[req.body.aesthetic] ? req.body.aesthetic : '';
  const r = db.prepare('INSERT INTO posts (user_id, title, description, tags, aesthetic, theme, created_at) VALUES (?,?,?,?,?,?,?)')
    .run(req.user.id, title, str(req.body.description, 500), [...new Set(tags)].join(','), aesthetic, JSON.stringify(theme), now());
  const [p] = postsQuery(req.user.id, { where: ['p.id = @id'], params: [{ id: r.lastInsertRowid }], limit: 1 });
  res.status(201).json({ post: p });
}));

app.delete('/api/posts/:id', requireAccount, wrap((req, res) => {
  const p = db.prepare('SELECT * FROM posts WHERE id=?').get(idParam(req.params.id));
  if (!p) throw new HttpError(404, 'Post not found.');
  const isMod = ['mod', 'admin'].includes(req.user.role);
  if (p.user_id !== req.user.id && !isMod) throw new HttpError(403, 'You can only delete your own posts.');
  db.prepare('DELETE FROM posts WHERE id=?').run(p.id);
  res.json({ ok: true });
}));

const visiblePost = (id) => {
  const p = db.prepare("SELECT * FROM posts WHERE id=? AND status='visible'").get(id);
  if (!p) throw new HttpError(404, 'Post not found.');
  return p;
};
const likeCount = (id) => db.prepare('SELECT COUNT(*) c FROM likes WHERE post_id=?').get(id).c;
app.post('/api/posts/:id/like', requireAccount, rateLimit('like', 120, 60000), wrap((req, res) => {
  const p = visiblePost(idParam(req.params.id));
  db.prepare('INSERT OR IGNORE INTO likes VALUES (?,?,?)').run(req.user.id, p.id, now());
  res.json({ liked: true, likes: likeCount(p.id) });
}));
app.delete('/api/posts/:id/like', requireAccount, wrap((req, res) => {
  const id = idParam(req.params.id);
  db.prepare('DELETE FROM likes WHERE user_id=? AND post_id=?').run(req.user.id, id);
  res.json({ liked: false, likes: likeCount(id) });
}));

const REPORT_REASONS = ['spam', 'harassment', 'nsfw', 'copyright', 'hate', 'other'];
app.post('/api/posts/:id/report', requireAccount, rateLimit('report', 20, 3600000), wrap((req, res) => {
  const p = visiblePost(idParam(req.params.id));
  if (p.user_id === req.user.id) throw new HttpError(400, "You can't report your own post.");
  const reason = REPORT_REASONS.includes(req.body.reason) ? req.body.reason : null;
  if (!reason) throw new HttpError(400, 'Choose a reason for the report.');
  const r = db.prepare('INSERT OR IGNORE INTO reports (post_id, reporter_id, reason, details, created_at) VALUES (?,?,?,?,?)').run(p.id, req.user.id, reason, str(req.body.details, 500), now());
  if (!r.changes) throw new HttpError(409, 'You already reported this post. Thanks — moderators will review it.');
  const open = db.prepare("SELECT COUNT(*) c FROM reports WHERE post_id=? AND status='open'").get(p.id).c;
  let hidden = false;
  if (open >= AUTO_HIDE_REPORTS) { db.prepare("UPDATE posts SET status='hidden' WHERE id=?").run(p.id); hidden = true; }
  res.status(201).json({ ok: true, hidden });
}));

// ---------- profiles & follows ----------
app.get('/api/users/:username', wrap((req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE username = ? AND is_guest = 0').get(str(req.params.username, 20));
  if (!u) throw new HttpError(404, 'No user with that name.');
  const s = stats(u.id);
  const following = req.user ? !!db.prepare('SELECT 1 FROM follows WHERE follower_id=? AND followee_id=?').get(req.user.id, u.id) : false;
  const likesReceived = db.prepare("SELECT COUNT(*) c FROM likes l JOIN posts p ON p.id=l.post_id WHERE p.user_id=? AND p.status='visible'").get(u.id).c;
  res.json({ user: { id: u.id, username: u.username, displayName: u.display_name, bio: u.bio, isSample: !!u.is_sample, createdAt: u.created_at, isMe: req.user?.id === u.id },
    stats: { posts: s.posts, followers: s.followers, following: s.following, likes: likesReceived }, following });
}));
app.post('/api/users/:username/follow', requireAccount, rateLimit('follow', 60, 60000), wrap((req, res) => {
  const u = db.prepare('SELECT id FROM users WHERE username=? AND is_guest=0').get(str(req.params.username, 20));
  if (!u) throw new HttpError(404, 'No user with that name.');
  if (u.id === req.user.id) throw new HttpError(400, "You can't follow yourself (but we admire the confidence).");
  db.prepare('INSERT OR IGNORE INTO follows VALUES (?,?,?)').run(req.user.id, u.id, now());
  res.json({ following: true, followers: stats(u.id).followers });
}));
app.delete('/api/users/:username/follow', requireAccount, wrap((req, res) => {
  const u = db.prepare('SELECT id FROM users WHERE username=?').get(str(req.params.username, 20));
  if (!u) throw new HttpError(404, 'No user with that name.');
  db.prepare('DELETE FROM follows WHERE follower_id=? AND followee_id=?').run(req.user.id, u.id);
  res.json({ following: false, followers: stats(u.id).followers });
}));

// ---------- moderation ----------
app.get('/api/mod/queue', requireMod, (req, res) => {
  const status = req.query.status === 'resolved' ? "r.status != 'open'" : "r.status = 'open'";
  const rows = db.prepare(`SELECT r.post_id, COUNT(*) n, GROUP_CONCAT(r.reason) reasons, GROUP_CONCAT(NULLIF(r.details,''), ' | ') details, MAX(r.created_at) last
    FROM reports r WHERE ${status} GROUP BY r.post_id ORDER BY last DESC LIMIT 100`).all();
  const hiddenNoReports = req.query.status === 'resolved' ? [] : db.prepare("SELECT id post_id FROM posts WHERE status='hidden' AND id NOT IN (SELECT post_id FROM reports WHERE status='open')").all();
  const items = [...rows, ...hiddenNoReports.map((h) => ({ ...h, n: 0, reasons: '', details: '', last: 0 }))].map((r) => {
    const [post] = postsQuery(req.user.id, { where: ['p.id = @id'], params: [{ id: r.post_id }], limit: 1 });
    return post ? { post, reports: r.n, reasons: [...new Set((r.reasons || '').split(',').filter(Boolean))], details: r.details || '', last: r.last } : null;
  }).filter(Boolean);
  res.json({ items });
});
app.post('/api/mod/posts/:id', requireMod, wrap((req, res) => {
  const id = idParam(req.params.id);
  const p = db.prepare('SELECT * FROM posts WHERE id=?').get(id);
  if (!p) throw new HttpError(404, 'Post not found.');
  const action = req.body.action;
  const resolve = (status) => db.prepare("UPDATE reports SET status=?, resolved_by=?, resolved_at=? WHERE post_id=? AND status='open'").run(status, req.user.id, now(), id);
  if (action === 'dismiss') { db.prepare("UPDATE posts SET status='visible' WHERE id=?").run(id); resolve('dismissed'); }
  else if (action === 'hide') { db.prepare("UPDATE posts SET status='hidden' WHERE id=?").run(id); resolve('resolved'); }
  else if (action === 'restore') { db.prepare("UPDATE posts SET status='visible' WHERE id=?").run(id); }
  else if (action === 'remove') { db.prepare("UPDATE posts SET status='removed' WHERE id=?").run(id); resolve('resolved'); }
  else throw new HttpError(400, 'Unknown moderation action.');
  res.json({ ok: true });
}));

app.get('/api/health', (_req, res) => res.json({ ok: true, ai: !!AI_KEY }));
app.use('/api', (_req, _res, next) => next(new HttpError(404, 'Unknown API route.')));

// ---------- static frontend ----------
app.use(express.static(PUBLIC_DIR, {
  index: 'index.html', maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0,
  setHeaders: (res, p) => { if (/\.(jpg|webp|ttf)$/.test(p)) res.setHeader('Cache-Control', 'public, max-age=604800'); },
}));
app.get(/^\/(?!api|uploads).*/, (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));

// ---------- errors ----------
app.use((err, req, res, _next) => {
  if (err.type === 'entity.too.large') err = new HttpError(413, 'That file or request is too large.');
  if (err.type === 'entity.parse.failed') err = new HttpError(400, 'Malformed JSON.');
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 && !(err instanceof HttpError) ? 'Something went wrong on our side.' : err.message, code: err.code || undefined });
});

app.listen(PORT, '0.0.0.0', () => console.log(`RETRO.EXE running on http://0.0.0.0:${PORT}`));

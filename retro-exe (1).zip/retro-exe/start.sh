#!/bin/sh
# RETRO.EXE launcher for macOS / Linux
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "RETRO.EXE needs Node.js 20+ - get it from https://nodejs.org"; exit 1; }
[ -d node_modules/better-sqlite3 ] || npm install --omit=dev --no-fund --no-audit || exit 1
echo "RETRO.EXE running at http://localhost:3000 (Ctrl+C to stop)"
( sleep 1.5; (open http://localhost:3000 || xdg-open http://localhost:3000) >/dev/null 2>&1 ) &
node server/index.js

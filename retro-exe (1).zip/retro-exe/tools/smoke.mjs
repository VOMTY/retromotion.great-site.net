// Dev smoke test: visit every route on desktop + mobile, report console errors, save screenshots.
import { chromium } from 'playwright';
const BASE = process.env.BASE || 'http://localhost:3000';
const routes = (process.argv[2] || '/,/explore,/explore/dreamcore,/wallpapers,/studio,/studio?tab=dream,/icons,/world,/world/favorites,/world/collections,/world/creations,/community,/settings,/search?q=pool,/mod,/nope').split(',');
const vp = process.argv[3] || 'desktop';
const sizes = { desktop: { width: 1440, height: 900 }, mobile: { width: 390, height: 844 } };
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: sizes[vp], deviceScaleFactor: 1, isMobile: vp === 'mobile', hasTouch: vp === 'mobile' });
await ctx.addInitScript(() => { sessionStorage.setItem('retro.booted', '1'); });
const page = await ctx.newPage();
const errors = [];
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errors.push(`[${m.type()}] ${page.url()} :: ${m.text()}`); });
page.on('pageerror', (e) => errors.push(`[pageerror] ${page.url()} :: ${e.message}`));
page.on('requestfailed', (r) => errors.push(`[reqfail] ${r.url()} ${r.failure()?.errorText}`));
await page.goto(BASE + '/#/');
await page.waitForTimeout(1500);
for (const r of routes) {
  await page.evaluate((h) => { location.hash = h; }, '#' + r);
  await page.waitForTimeout(1300);
  const name = r.replace(/[^a-z0-9]+/gi, '_') || 'home';
  await page.screenshot({ path: `tools/_shot-${vp}-${name}.png`, fullPage: process.argv[4] === 'full' });
}
console.log(errors.length ? errors.join('\n') : 'NO ERRORS');
await browser.close();

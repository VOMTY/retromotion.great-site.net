// Dev E2E: exercise the main user flows against a running server.
import { chromium } from 'playwright';
const BASE = process.env.BASE || 'http://localhost:3000';
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, acceptDownloads: true });
await ctx.addInitScript(() => sessionStorage.setItem('retro.booted', '1'));
const page = await ctx.newPage();
const errors = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(`[console] ${m.text()}`); });
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}`));
page.on('dialog', (d) => d.accept());
const step = async (name, fn) => { try { await fn(); console.log('✔', name); } catch (e) { console.log('✘', name, '→', e.message.split('\n')[0]); await page.screenshot({ path: `tools/_fail-${name.replace(/\W+/g, '_')}.png` }); } };
const go = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await page.waitForTimeout(900); };
const toastText = async () => (await page.locator('.toast').allInnerTexts()).join(' | ');

await page.goto(BASE + '/#/');
await page.waitForTimeout(1500);

await step('wallpaper preview + favourite', async () => {
  await go('#/wallpapers');
  await page.locator('.wp-grid .card .stretch').first().click();
  await page.locator('.modal').waitFor();
  await page.locator('.modal .seg button', { hasText: 'Phone' }).click();
  await page.locator('.modal .device.mobile').waitFor();
  await page.locator('.modal [data-fav]').click();
  await page.waitForTimeout(400);
  if (!(await toastText()).includes('Favorites')) throw new Error('no fav toast: ' + await toastText());
});
await step('download wallpaper PNG', async () => {
  const dl = page.waitForEvent('download', { timeout: 20000 });
  await page.locator('.modal-foot .btn', { hasText: 'Download' }).click();
  await page.locator('.menu .menu-item').first().click();
  const d = await dl; const p = await d.path();
  const fs = await import('fs'); const size = fs.statSync(p).size;
  if (size < 50000) throw new Error('png too small ' + size);
  console.log('   png bytes', size, d.suggestedFilename());
});
await step('save to new collection', async () => {
  await page.locator('.modal .icon-toggle[aria-label^="Save"]').click();
  await page.locator('.menu .menu-item', { hasText: 'New collection' }).click();
  await page.locator('.modal input.input').last().fill('Night drives');
  await page.locator('.modal-foot .btn-primary').last().click();
  await page.waitForTimeout(700);
  if (!(await toastText()).includes('Night drives')) throw new Error(await toastText());
  await page.keyboard.press('Escape');
});
await step('world: favourites & collections show items', async () => {
  await go('#/world/favorites');
  if (!(await page.locator('.item-tile').count())) throw new Error('no fav tiles');
  await go('#/world/collections');
  if (!(await page.locator('.coll-panel .item-tile').count())) throw new Error('no collection tiles');
});
await step('theme editor create + apply', async () => {
  await go('#/world');
  await page.locator('.toolbar .btn', { hasText: 'New theme' }).click();
  await page.locator('.theme-editor').waitFor();
  await page.locator('.te-form input.input').first().fill('Test Theme Midnight');
  await page.locator('.modal-foot .btn', { hasText: 'Save & apply' }).click();
  await page.waitForTimeout(900);
  if (!(await page.locator('.theme-card.is-active .card-title', { hasText: 'Test Theme Midnight' }).count())) throw new Error('not active');
});
await step('studio: adjust + save creation', async () => {
  await go('#/studio?wp=img-liminal');
  await page.locator('.range input').first().fill('140');
  await page.locator('.range input').first().dispatchEvent('input');
  await page.waitForTimeout(600);
  await page.locator('.studio-head .btn', { hasText: 'Save' }).click();
  await page.locator('.modal input.input').fill('Bright pool');
  await page.locator('.modal-foot .btn-primary').click();
  await page.waitForTimeout(800);
  if (!(await toastText()).includes('Bright pool')) throw new Error(await toastText());
});
await step('studio: scene mode + undo', async () => {
  await page.locator('.seg button', { hasText: 'Scene' }).click();
  await page.waitForTimeout(300);
  await page.locator('button', { hasText: 'Shuffle layout' }).click();
  await page.waitForTimeout(700);
  if (await page.locator('button', { hasText: 'Undo' }).isDisabled()) throw new Error('undo disabled');
});
await step('dream generator renders 6', async () => {
  await go('#/studio?tab=dream');
  await page.waitForTimeout(600);
  const n = await page.locator('.dream-card').count();
  if (n !== 6) throw new Error('dream cards ' + n);
  if (!(await page.locator('.ai-off').count())) throw new Error('ai-off notice missing');
});
await step('icon studio export zip', async () => {
  await go('#/icons?pack=chrome-heart');
  await page.locator('.toggle, .export-box .switch input').first().uncheck({ force: true }).catch(() => {});
  const dl = page.waitForEvent('download', { timeout: 30000 });
  await page.locator('.btn', { hasText: 'Export set' }).click();
  const d = await dl; const fs = await import('fs'); const size = fs.statSync(await d.path()).size;
  console.log('   zip bytes', size, d.suggestedFilename());
  if (size < 20000) throw new Error('zip small');
});
await step('register account', async () => {
  await page.locator('.tray-user').click();
  await page.locator('.menu-item', { hasText: 'Create free account' }).click();
  await page.locator('.modal input').nth(0).fill('dreamer_' + Date.now().toString(36).slice(-5));
  await page.locator('.modal input[type=password]').fill('supersecret1');
  await page.locator('.modal button[type=submit]').click();
  await page.waitForTimeout(1500);
  if (!(await toastText()).includes('Welcome')) throw new Error(await toastText());
});
await step('library kept after register', async () => {
  await go('#/world');
  if (!(await page.locator('.card-title', { hasText: 'Test Theme Midnight' }).count())) throw new Error('theme lost');
});
await step('share theme to community', async () => {
  await page.locator('.theme-card', { hasText: 'Test Theme Midnight' }).locator('.card-actions button').click();
  await page.locator('.menu-item', { hasText: 'Share' }).click();
  await page.locator('.modal input[type=checkbox]').check();
  await page.locator('.modal-foot .btn', { hasText: 'Publish' }).click();
  await page.waitForTimeout(900);
  if (!(await toastText()).includes('live')) throw new Error(await toastText());
});
await step('like + report sample post', async () => {
  await go('#/community');
  await page.waitForTimeout(800);
  const card = page.locator('.post-card.is-sample').first();
  const before = await card.locator('.like-btn').innerText();
  await card.locator('.like-btn').click();
  await page.waitForTimeout(600);
  const after = await card.locator('.like-btn').innerText();
  if (before === after) throw new Error('like count unchanged');
  await card.locator('.card-actions button[aria-label^="More"]').click();
  await page.locator('.menu-item', { hasText: 'Report' }).click();
  await page.locator('.modal .radio').first().click();
  await page.locator('.modal-foot .btn', { hasText: 'Send report' }).click();
  await page.waitForTimeout(700);
  if (!(await toastText()).includes('Report')) throw new Error(await toastText());
});
await step('open post + save theme to world', async () => {
  await page.locator('.post-card .stretch').nth(1).click();
  await page.locator('.post-view').waitFor();
  await page.locator('.post-side .btn', { hasText: 'Save theme to My World' }).click();
  await page.waitForTimeout(800);
  if (!(await toastText()).includes('My Digital World')) throw new Error(await toastText());
  await page.keyboard.press('Escape');
});
await step('mod queue (first account = admin)', async () => {
  await go('#/mod');
  await page.waitForTimeout(800);
  const n = await page.locator('.mod-row').count();
  if (!n) throw new Error('no reported rows');
  await page.locator('.mod-row .btn', { hasText: 'Dismiss' }).first().click();
  await page.waitForTimeout(800);
});
await step('profile page', async () => {
  await go('#/community'); await page.waitForTimeout(600);
  await page.locator('.post-card .author').first().click();
  await page.waitForTimeout(1000);
  if (!(await page.locator('.profile-head').count())) throw new Error('no profile');
});
await step('search', async () => {
  await go('#/search?q=chrome');
  await page.waitForTimeout(1200);
  if ((await page.locator('.card').count()) < 3) throw new Error('few results');
});
await step('settings: legible + reduce motion', async () => {
  await go('#/settings');
  await page.locator('.switch', { hasText: 'Legible mode' }).click();
  await page.locator('.switch', { hasText: 'Animations' }).click();
  const cls = await page.evaluate(() => document.documentElement.className);
  if (!cls.includes('legible') || cls.includes('motion')) throw new Error(cls);
  await page.locator('.switch', { hasText: 'Legible mode' }).click();
  await page.locator('.switch', { hasText: 'Animations' }).click();
});
await step('window minimize/restore', async () => {
  await page.locator('#btn-min').click();
  if (!(await page.locator('#desktop-shortcuts .desk-icon').first().isVisible())) throw new Error('no shortcuts');
  await page.locator('.task-item[data-page="home"]').click();
  await page.waitForTimeout(800);
  if (await page.evaluate(() => document.body.classList.contains('minimized'))) throw new Error('still minimized');
});
await step('start menu + shutdown', async () => {
  await page.locator('#start-btn').click();
  await page.locator('#start-menu .sm-item').first().waitFor();
  await page.locator('.sm-foot button', { hasText: 'Shut Down' }).click();
  await page.waitForTimeout(600);
  await page.locator('#boot').click();
  await page.waitForTimeout(400);
  await page.locator('#boot').click();
  await page.waitForTimeout(800);
});
console.log(errors.length ? errors.join('\n') : 'NO PAGE ERRORS');
await browser.close();

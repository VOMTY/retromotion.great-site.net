@echo off
title RETRO.EXE
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto nonode
if not exist "node_modules\better-sqlite3" (
  echo First run: installing RETRO.EXE ^(about a minute^)...
  call npm install --omit=dev --no-fund --no-audit
  if errorlevel 1 goto installfail
)
echo.
echo   RETRO.EXE is starting at http://localhost:3000
echo   Keep this window open while you use it. Close it to stop RETRO.EXE.
echo.
start "" http://localhost:3000
node server\index.js
pause
exit /b 0
:nonode
echo.
echo   RETRO.EXE needs Node.js (free). Download the LTS version from https://nodejs.org
echo   Install it, then double-click this file again.
echo.
start "" https://nodejs.org
pause
exit /b 1
:installfail
echo.
echo   Installation failed. Check your internet connection and try again.
pause
exit /b 1

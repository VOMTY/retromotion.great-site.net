// RETRO.EXE entry: shell (window, taskbar, start menu, tray), routing, theme application, boot.
import { h, clear, $ } from './core/dom.js';
import { ic, icEl } from './core/icons.js';
import { state, subscribe, applySettings, setSetting, initSession, activeTheme, isGuest, isMod, logout, setActiveTheme } from './core/store.js';
import { parseHash, navigate } from './core/router.js';
import { toast, toastError, loadingBox, errorBox, openMenu, closeMenu, closeAllModals, avatarImg, confirmDialog } from './core/ui.js';
import { startParticles, syncParticles, initCursorTrail, runBoot, runShutdown, setParticleColors } from './lib/effects.js';
import { wallpaperView } from './lib/render.js';
import { iconImg } from './lib/iconkit.js';
import { luminance, lighten } from './lib/wallgen.js';
import { AESTHETICS } from './data/catalog.js';
import { openAuthModal } from './components/auth.js';

export const PAGES = {
  home: { title: 'Home', icon: 'home', glyph: 'home', path: '/' },
  explore: { title: 'Aesthetic Explorer', icon: 'compass', glyph: 'compass', path: '/explore' },
  wallpapers: { title: 'Wallpapers', icon: 'image', glyph: 'photos', path: '/wallpapers' },
  studio: { title: 'Wallpaper Studio', icon: 'sliders', glyph: 'palette', path: '/studio' },
  icons: { title: 'Icon & Widget Studio', icon: 'apps', glyph: 'star', path: '/icons' },
  world: { title: 'My Digital World', icon: 'layers', glyph: 'computer', path: '/world' },
  community: { title: 'Community', icon: 'users', glyph: 'users', path: '/community' },
  profile: { title: 'Profile', icon: 'user', glyph: 'users' },
  settings: { title: 'Control Panel', icon: 'settings', glyph: 'settings', path: '/settings' },
  mod: { title: 'Moderation', icon: 'shield', glyph: 'shield', path: '/mod' },
  search: { title: 'Search', icon: 'search', glyph: 'search', path: '/search' },
  notfound: { title: 'File Not Found', icon: 'warning', glyph: 'folder' },
};
const TASKBAR = [['home', 'Home'], ['explore', 'Explore'], ['wallpapers', 'Wallpapers'], ['icons', 'Icons'], ['world', 'My World'], ['community', 'Community']];
const SHELL_ICON = { style: 'aero', shape: 'squircle', bg: '#2f6cf5', fg: '#ffffff', accent: '#7ee0ff' };
const shellIcons = () => activeTheme()?.data?.icons || SHELL_ICON;

const root = document.getElementById('page-root');
const body = document.body;

// ---------- window controls ----------
let stayMinimized = false;
function setMinimized(on) {
  body.classList.toggle('minimized', on);
  $('#desktop-shortcuts').setAttribute('aria-hidden', String(!on));
  updateTaskbar(parseHash().page);
}
function setMaximized(on) {
  body.classList.toggle('max', on);
  localStorage.setItem('retro.max', on ? '1' : '');
  $('#btn-max').setAttribute('aria-label', on ? 'Restore window size' : 'Maximize window');
  $('#btn-max').title = on ? 'Restore' : 'Maximize';
}
$('#btn-min').addEventListener('click', () => { setMinimized(true); toast('Window minimized. Click a taskbar button or desktop icon to bring it back.', { type: 'info', timeout: 3500 }); });
$('#btn-max').addEventListener('click', () => setMaximized(!body.classList.contains('max')));
$('#btn-close').addEventListener('click', () => { stayMinimized = true; if (parseHash().page === 'home') { setMinimized(true); stayMinimized = false; } else navigate('/'); });
$('#main-titlebar').addEventListener('dblclick', (e) => { if (!e.target.closest('button')) setMaximized(!body.classList.contains('max')); });
setMaximized(localStorage.getItem('retro.max') === '1');

// ---------- taskbar ----------
function updateTaskbar(page) {
  const items = $('#task-items');
  if (!items.children.length) {
    items.append(...TASKBAR.map(([p, label]) => h('a', { class: 'task-item', href: `#${PAGES[p].path}`, 'data-page': p, onclick: (e) => { if (body.classList.contains('minimized') && parseHash().page === p) { e.preventDefault(); setMinimized(false); } } },
      h('span', { class: 'ti-icon' }), h('span', { class: 'ti-label' }, label))));
  }
  items.querySelectorAll('.task-item').forEach((a) => {
    const on = a.dataset.page === page || (page === 'studio' && a.dataset.page === 'wallpapers');
    if (on && !body.classList.contains('minimized')) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
}
function drawTaskIcons() {
  const cfg = shellIcons();
  $('#task-items').querySelectorAll('.task-item').forEach((a) => a.querySelector('.ti-icon').replaceChildren(iconImg(PAGES[a.dataset.page].glyph, cfg, { alt: '' })));
}

// ---------- tray ----------
const trayClock = h('time', { class: 'tray-clock' });
const tickClock = () => { const d = new Date(); trayClock.textContent = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); trayClock.dateTime = d.toISOString(); trayClock.title = d.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); };
setInterval(tickClock, 15000); tickClock();
const crtBtn = h('button', { class: 'tray-btn', 'aria-label': 'CRT scanline effect', title: 'CRT effect', html: ic('tv'), onclick: () => { setSetting('crt', !state.settings.crt); toast(state.settings.crt ? 'CRT mode on. Adjust in Control Panel.' : 'CRT mode off.', { type: 'info', timeout: 2200 }); } });
const fxBtn = h('button', { class: 'tray-btn', 'aria-label': 'Floating particles', title: 'Particles', html: ic('sparkles'), onclick: () => setSetting('particles', !state.settings.particles) });
const userBtn = h('button', { class: 'tray-user', 'aria-haspopup': 'menu', onclick: (e) => openMenu(e.currentTarget, userMenuItems()) });
function drawTray() {
  crtBtn.setAttribute('aria-pressed', String(!!state.settings.crt));
  fxBtn.setAttribute('aria-pressed', String(!!state.settings.particles));
  const u = state.user;
  userBtn.replaceChildren(avatarImg(u?.username || 'guest'), h('span', { class: 'small' }, isGuest() ? 'Guest' : (u.displayName || u.username)));
  userBtn.setAttribute('aria-label', isGuest() ? 'Guest session — account menu' : `Signed in as ${u.username} — account menu`);
}
$('#tray').append(h('button', { class: 'tray-btn', 'aria-label': 'Search', title: 'Search (Ctrl+K)', html: ic('search'), onclick: () => navigate('/search') }), crtBtn, fxBtn, userBtn, trayClock);

function userMenuItems() {
  if (isGuest()) return [{ heading: 'Guest session' }, { label: 'Create free account', icon: 'user', onClick: () => openAuthModal('register') }, { label: 'Sign in', icon: 'login', onClick: () => openAuthModal('login') }, { sep: true }, { label: 'Control Panel', icon: 'settings', onClick: () => navigate('/settings') }];
  return [{ heading: `@${state.user.username}` }, { label: 'My profile', icon: 'user', onClick: () => navigate(`/u/${state.user.username}`) }, { label: 'My Digital World', icon: 'layers', onClick: () => navigate('/world') },
    isMod() ? { label: 'Moderation queue', icon: 'shield', onClick: () => navigate('/mod') } : null, { label: 'Control Panel', icon: 'settings', onClick: () => navigate('/settings') }, { sep: true }, { label: 'Log off', icon: 'logout', onClick: doLogout }].filter(Boolean);
}
async function doLogout() {
  if (!(await confirmDialog({ title: 'Log Off RETRO.EXE', message: 'Log off and start a fresh guest session? Your account data stays safe on the server.', okText: 'Log Off', icon: 'logout' }))) return;
  try { await logout(); toast('Logged off. See you in the next dream.', { type: 'info' }); navigate('/'); } catch (e) { toastError(e); }
}

// ---------- start menu ----------
const startBtn = $('#start-btn'), startMenu = $('#start-menu');
function openStart() {
  closeMenu();
  const u = state.user;
  const cfg = shellIcons();
  const item = (page, title, sub) => h('a', { class: 'sm-item', role: 'menuitem', href: `#${PAGES[page].path}`, onclick: closeStart }, h('span', { class: 'sm-ic' }, iconImg(PAGES[page].glyph, cfg, { alt: '' })), h('span', null, h('b', null, title), sub ? h('small', null, sub) : null));
  const right = (label, icon, onClick) => h('button', { class: 'sm-item', role: 'menuitem', onclick: () => { closeStart(); onClick(); } }, h('span', { class: 'sm-ic', html: ic(icon) }), h('b', null, label));
  clear(startMenu).append(
    h('div', { class: 'sm-head' }, avatarImg(u?.username || 'guest'), h('div', null, isGuest() ? 'Guest' : (u.displayName || u.username), h('small', null, isGuest() ? 'Saved on this device · create an account to sync' : `@${u.username}`))),
    h('div', { class: 'sm-cols' },
      h('div', { class: 'sm-left' }, item('home', 'Home', 'Your desktop dashboard'), item('explore', 'Aesthetic Explorer', '12 aesthetics to wander'), item('wallpapers', 'Wallpapers', 'Browse & download'), item('studio', 'Wallpaper Studio', 'Compose, adjust, generate'), item('icons', 'Icon & Widget Studio', 'Packs, clocks, export'), item('world', 'My Digital World', 'Your themes & saves'), item('community', 'Community', 'Shared themes')),
      h('div', { class: 'sm-right' },
        right('Search', 'search', () => navigate('/search')), right('My Favorites', 'heart', () => navigate('/world/favorites')), right('My Collections', 'folder', () => navigate('/world/collections')),
        !isGuest() ? right('My Profile', 'user', () => navigate(`/u/${u.username}`)) : null,
        h('div', { class: 'sm-sep' }), right('Surprise Me', 'shuffle', surprise), right('Control Panel', 'settings', () => navigate('/settings')),
        isMod() ? right('Moderation', 'shield', () => navigate('/mod')) : null)),
    h('div', { class: 'sm-foot' },
      isGuest() ? h('button', { onclick: () => { closeStart(); openAuthModal('login'); } }, h('span', { class: 'pw yel', html: ic('login') }), 'Log On')
        : h('button', { onclick: () => { closeStart(); doLogout(); } }, h('span', { class: 'pw yel', html: ic('logout') }), 'Log Off'),
      h('button', { onclick: () => { closeStart(); runShutdown(); } }, h('span', { class: 'pw red', html: ic('power') }), 'Shut Down')));
  startMenu.hidden = false;
  startBtn.setAttribute('aria-expanded', 'true');
  requestAnimationFrame(() => startMenu.querySelector('.sm-item')?.focus());
}
function closeStart() { if (startMenu.hidden) return; startMenu.hidden = true; startBtn.setAttribute('aria-expanded', 'false'); }
startBtn.addEventListener('click', (e) => { e.stopPropagation(); startMenu.hidden ? openStart() : closeStart(); });
document.addEventListener('mousedown', (e) => { if (!startMenu.hidden && !startMenu.contains(e.target) && !startBtn.contains(e.target)) closeStart(); });
startMenu.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { closeStart(); startBtn.focus(); }
  if (['ArrowDown', 'ArrowUp'].includes(e.key)) {
    const all = [...startMenu.querySelectorAll('.sm-item, .sm-foot button')]; const i = all.indexOf(document.activeElement);
    all[(i + (e.key === 'ArrowDown' ? 1 : -1) + all.length) % all.length]?.focus(); e.preventDefault();
  }
});

export function surprise() {
  const a = AESTHETICS[Math.floor(Math.random() * AESTHETICS.length)];
  toast(`Teleporting to ${a.name}…`, { type: 'info', title: 'Surprise!', timeout: 2200 });
  navigate(`/explore/${a.id}`, { surprise: 1 });
}

// ---------- desktop shortcuts (visible when minimized) ----------
function drawShortcuts() {
  const cfg = shellIcons();
  clear($('#desktop-shortcuts')).append(...['home', 'explore', 'wallpapers', 'studio', 'icons', 'world', 'community', 'settings'].map((p) =>
    h('a', { class: 'desk-icon', href: `#${PAGES[p].path}`, onclick: () => { if (parseHash().page === p) setMinimized(false); } }, iconImg(PAGES[p].glyph, cfg, { alt: '' }), h('span', null, PAGES[p].title))));
}

// ---------- theme application ----------
function applyDesktop() {
  const wall = $('#desktop-bg .desk-wall');
  const t = activeTheme();
  const cfg = state.settings.desktopOverride || t?.data?.wallpaper;
  if (!cfg) { wall.classList.remove('on'); setTimeout(() => { if (!wall.classList.contains('on')) clear(wall); }, 1200); return; }
  const size = innerWidth < 760 ? 'mobile' : 'desktop';
  clear(wall).append(wallpaperView(cfg, { size, live: true, eager: true }));
  requestAnimationFrame(() => wall.classList.add('on'));
}
function applyThemeVars() {
  const t = activeTheme(); const rs = document.documentElement.style;
  if (!t) { ['--accent', '--accent2', '--accent-ink'].forEach((v) => rs.removeProperty(v)); setParticleColors(['#5ff3ff', '#ff8ad8', '#ffffff', '#a98bff']); return; }
  const p = t.data.palette;
  const fix = (c) => { let x = c; for (let i = 0; i < 6 && luminance(x) < 0.32; i++) x = lighten(x, 0.18); return x; };
  const a1 = fix(p[2]), a2 = fix(p[3]);
  rs.setProperty('--accent', a1); rs.setProperty('--accent2', a2); rs.setProperty('--accent-ink', luminance(a1) > 0.5 ? '#04122a' : '#ffffff');
  setParticleColors([a1, a2, '#ffffff', fix(p[4])]);
}
function applyTheme() { applyDesktop(); applyThemeVars(); drawTaskIcons(); drawShortcuts(); }
let lastW = innerWidth < 760;
addEventListener('resize', () => { const m = innerWidth < 760; if (m !== lastW) { lastW = m; applyDesktop(); } });

// ---------- routing ----------
let token = 0, cleanups = [], lastUserId = null, firstRender = true;
async function route() {
  const r = parseHash();
  const my = ++token;
  closeStart(); closeMenu(); closeAllModals();
  cleanups.splice(0).forEach((fn) => { try { fn(); } catch (e) { console.error(e); } });
  const meta = PAGES[r.page] || PAGES.notfound;
  const setTitle = (t) => { $('#win-title').textContent = `${t} - RETRO.EXE`; document.title = `${t} · RETRO.EXE`; };
  setTitle(meta.title);
  $('#win-icon').innerHTML = ic(meta.icon);
  if (stayMinimized) { stayMinimized = false; setMinimized(true); } else if (body.classList.contains('minimized')) setMinimized(false);
  updateTaskbar(r.page);
  root.replaceChildren(loadingBox(`Opening ${meta.title}...`));
  const win = $('#main-window');
  win.classList.remove('opening'); void win.offsetWidth; win.classList.add('opening');
  const ctx = {
    ...r, setTitle, isActive: () => my === token,
    onCleanup: (fn) => cleanups.push(fn),
    subscribe: (topic, fn) => cleanups.push(subscribe(topic, fn)),
    rerender: () => route(),
  };
  try {
    const mod = await import(`./pages/${r.page}.js`);
    if (my !== token) return;
    const pageEl = h('div', { class: `page page-${r.page}` });
    root.replaceChildren(pageEl);
    if (!firstRender) window.scrollTo({ top: 0, behavior: 'instant' });
    await mod.render(pageEl, ctx);
    if (!firstRender && my === token) $('#win-title').focus?.({ preventScroll: true });
  } catch (e) {
    console.error(e);
    if (my === token) root.replaceChildren(errorBox(e, route));
  }
  firstRender = false;
}
$('#win-title').tabIndex = -1;
addEventListener('hashchange', route);

// ---------- keyboard shortcuts ----------
addEventListener('keydown', (e) => {
  const typing = /input|textarea|select/i.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); navigate('/search'); }
  else if (e.key === '/' && !typing && !document.querySelector('.modal-backdrop')) { e.preventDefault(); navigate('/search'); }
});

// ---------- store reactions ----------
subscribe('settings', (key) => {
  drawTray();
  if (['particles', 'motion'].includes(key)) syncParticles();
  if (key === 'desktopOverride') applyDesktop();
});
subscribe('activeTheme', applyTheme);
subscribe('themes', () => { applyTheme(); });
subscribe('user', () => {
  drawTray();
  const id = state.user?.id;
  if (lastUserId !== null && id !== lastUserId && state.ready) route(); // signed in / out → refresh view
  lastUserId = id;
});

// ---------- boot ----------
async function boot() {
  applySettings();
  startParticles();
  initCursorTrail();
  drawTray();
  updateTaskbar(parseHash().page);
  drawTaskIcons();
  drawShortcuts();
  const bootDone = runBoot();
  try {
    await initSession();
    lastUserId = state.user?.id ?? null;
    // first visit: dress the desktop with an example theme so it feels alive (once per guest)
    const autoKey = `retro.autoTheme.${state.user.id}`;
    if (isGuest() && !state.activeThemeId && state.themes.length && !localStorage.getItem(autoKey)) {
      localStorage.setItem(autoKey, '1');
      const t = state.themes.find((x) => /after midnight/i.test(x.name)) || state.themes[state.themes.length - 1];
      state.activeThemeId = t.id;
      setActiveTheme(t.id).catch(() => {});
    }
    drawTray();
    applyTheme();
    await route();
  } catch (e) {
    console.error(e);
    await bootDone;
    root.replaceChildren(h('div', { class: 'bsod', role: 'alert' },
      h('p', { class: 'bsod-title' }, ' RETRO.EXE '),
      h('p', null, 'A fatal exception occurred while connecting to your digital world. The server may be offline or restarting.'),
      h('p', null, `* ${e.message}`),
      h('p', null, h('button', { class: 'btn', onclick: () => location.reload() }, icEl('refresh'), 'Press here to try again'))));
  }
}
boot();

// Wallpapers: browse the library with aesthetic / colour / mood / device filters.
import { h, debounce } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { isFav, state } from '../core/store.js';
import { replaceQuery } from '../core/router.js';
import { emptyState } from '../core/ui.js';
import { AESTHETICS, AESTHETIC_BY_ID, WALLPAPERS, COLORS, MOODS } from '../data/catalog.js';
import { wallpaperCard } from '../components/cards.js';
import { openWallpaperPreview } from '../components/preview.js';
import { selectField, segField } from '../components/fields.js';

export function studioTabs(active) {
  return h('nav', { class: 'tabs studio-tabs', 'aria-label': 'Wallpaper Studio sections' },
    ...[['browse', 'Browse library', '#/wallpapers', 'grid'], ['compose', 'Compose & adjust', '#/studio', 'sliders'], ['dream', 'Dream Generator', '#/studio?tab=dream', 'wand']].map(([k, l, href, i]) =>
      h('a', { href, role: 'tab', 'aria-selected': String(k === active), 'aria-current': k === active ? 'page' : null }, icEl(i), l)));
}

const COLOR_HEX = { blue: '#3d7bff', purple: '#a06bff', pink: '#ff8ad8', green: '#5bd27a', cyan: '#5ff3ff', warm: '#ffa45c', dark: '#1a1f3a', pastel: '#f7d6e8' };

export async function render(root, ctx) {
  const f = {
    q: ctx.query.q || '', aesthetic: AESTHETIC_BY_ID[ctx.query.aesthetic] ? ctx.query.aesthetic : '',
    colors: new Set((ctx.query.colors || '').split(',').filter((c) => COLORS.includes(c))),
    mood: MOODS.includes(ctx.query.mood) ? ctx.query.mood : '', device: ['desktop', 'mobile', 'tablet'].includes(ctx.query.device) ? ctx.query.device : 'desktop',
    fav: ctx.query.fav === '1', sort: ctx.query.sort || 'featured',
  };
  const grid = h('div', { class: 'grid g-md wp-grid' });
  const count = h('span', { class: 'small muted', 'aria-live': 'polite' });
  const draw = () => {
    replaceQuery({ q: f.q, aesthetic: f.aesthetic, colors: [...f.colors].join(','), mood: f.mood, device: f.device === 'desktop' ? '' : f.device, fav: f.fav ? '1' : '', sort: f.sort === 'featured' ? '' : f.sort });
    const needle = f.q.toLowerCase();
    let list = WALLPAPERS.filter((w) => (!f.aesthetic || w.aesthetic === f.aesthetic)
      && (!f.colors.size || w.colors.some((c) => f.colors.has(c))) && (!f.mood || w.mood === f.mood)
      && w.devices.includes(f.device) && (!f.fav || isFav('wallpaper', w.id))
      && (!needle || `${w.title} ${AESTHETIC_BY_ID[w.aesthetic]?.name} ${w.mood} ${w.colors.join(' ')}`.toLowerCase().includes(needle)));
    if (f.sort === 'az') list = [...list].sort((a, b) => a.title.localeCompare(b.title));
    if (f.sort === 'art') list = [...list].sort((a, b) => (a.kind === 'image' ? 0 : 1) - (b.kind === 'image' ? 0 : 1));
    count.textContent = `${list.length} wallpaper${list.length === 1 ? '' : 's'}`;
    grid.classList.toggle('tall', f.device === 'mobile');
    grid.replaceChildren(...(list.length ? list.map((w) => wallpaperCard(w, { onOpen: openWallpaperPreview, size: f.device === 'mobile' ? 'mobile' : 'desktop' }))
      : [emptyState({ icon: f.fav ? 'heart' : 'search', title: f.fav ? 'No favourite wallpapers match' : 'No wallpapers match these filters', text: 'Loosen a filter or two — or make your own in the Studio.', action: h('button', { class: 'btn btn-cyan', onclick: reset }, icEl('refresh'), 'Reset filters') })]));
  };
  const colorChips = h('div', { class: 'chips', role: 'group', 'aria-label': 'Colour' }, ...COLORS.map((c) => h('button', { type: 'button', class: 'chip', 'aria-pressed': String(f.colors.has(c)), onclick: (e) => { f.colors.has(c) ? f.colors.delete(c) : f.colors.add(c); e.currentTarget.setAttribute('aria-pressed', String(f.colors.has(c))); draw(); } }, h('span', { class: 'dot', style: { background: COLOR_HEX[c] } }), c)));
  const search = h('input', { class: 'input', type: 'search', value: f.q, placeholder: 'Search wallpapers…', 'aria-label': 'Search wallpapers', oninput: debounce((e) => { f.q = e.target.value.trim(); draw(); }, 120) });
  const aesF = selectField('Aesthetic', [['', 'All aesthetics'], ...AESTHETICS.map((a) => [a.id, a.name])], f.aesthetic, (v) => { f.aesthetic = v; draw(); });
  const moodF = selectField('Mood', [['', 'Any mood'], ...MOODS.map((m) => [m, m[0].toUpperCase() + m.slice(1)])], f.mood, (v) => { f.mood = v; draw(); });
  const sortF = selectField('Sort', [['featured', 'Featured'], ['art', 'Illustrated first'], ['az', 'A → Z']], f.sort, (v) => { f.sort = v; draw(); });
  const devF = segField('Device', [['desktop', 'Desktop', 'monitor'], ['mobile', 'Phone', 'phone'], ['tablet', 'Tablet', 'tablet']], f.device, (v) => { f.device = v; draw(); });
  const favBtn = h('button', { class: `btn btn-sm ${f.fav ? 'is-on' : 'btn-ghost'}`, 'aria-pressed': String(f.fav), onclick: () => { f.fav = !f.fav; syncFav(); draw(); } }, icEl('heart'), 'Favourites');
  const syncFav = () => { favBtn.className = `btn btn-sm ${f.fav ? 'is-on' : 'btn-ghost'}`; favBtn.setAttribute('aria-pressed', String(f.fav)); };
  function reset() {
    Object.assign(f, { q: '', aesthetic: '', mood: '', device: 'desktop', fav: false, sort: 'featured' }); f.colors.clear();
    search.value = ''; aesF.set(''); moodF.set(''); sortF.set('featured'); devF.set('desktop'); syncFav();
    colorChips.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', 'false'));
    draw();
  }

  root.append(
    studioTabs('browse'),
    h('header', { class: 'page-head' }, h('div', null, h('p', { class: 'eyebrow' }, 'Wallpaper Studio'), h('h2', { class: 'h1' }, 'Wallpapers for every timeline.'),
      h('p', { class: 'muted' }, 'Original illustrations and resolution-independent procedural scenes. Preview on any device, save favourites, remix in the Studio and export full-size PNGs.')),
      h('a', { class: 'btn btn-primary', href: '#/studio' }, icEl('sliders'), 'Open composer')),
    h('div', { class: 'filters panel' },
      h('div', { class: 'filters-row' }, h('div', { class: 'search', style: { flex: '2 1 240px' } }, h('span', { class: 'search-ic', html: ic('search') }), search), h('div', { style: { flex: '1 1 160px' } }, aesF), h('div', { style: { flex: '1 1 130px' } }, moodF), h('div', { style: { flex: '1 1 140px' } }, sortF)),
      h('div', { class: 'filters-row' }, devF, h('div', { class: 'field' }, h('span', { class: 'small muted', style: { fontWeight: 700 } }, 'Colour'), colorChips)),
      h('div', { class: 'filters-row' }, count, h('span', { class: 'spacer' }), favBtn, h('button', { class: 'btn btn-sm btn-ghost', onclick: reset }, icEl('refresh'), 'Reset'))),
    grid,
    h('p', { class: 'small dim license-note' }, icEl('info'), ' All artwork is original to RETRO.EXE (illustrations generated for this project and procedural vector scenes). Free for personal wallpapers; please don’t resell. Items marked ', h('span', { class: 'badge badge-plus' }, 'Plus'), ' preview the future RETRO+ library and are free during the beta.'));
  draw();
  ctx.subscribe('favorites', () => { if (f.fav) draw(); });
}

// Control Panel: display & accessibility, account management, data export/deletion, RETRO+ preview, about.
import { h, swap, downloadBlob, timeAgo } from '../core/dom.js';
import { icEl, ic } from '../core/icons.js';
import { get } from '../core/api.js';
import { state, setSetting, isGuest, updateProfile, deleteAccount, logout } from '../core/store.js';
import { navigate } from '../core/router.js';
import { toast, toastError, withBusy, promptDialog, openModal, avatarImg, confirmDialog } from '../core/ui.js';
import { PREMIUM_FEATURES } from '../data/catalog.js';
import { wallpaperView } from '../lib/render.js';
import { runBoot } from '../lib/effects.js';
import { toggleField, textField } from '../components/fields.js';
import { openAuthModal } from '../components/auth.js';

export async function render(root, ctx) {
  const t = (key, label, desc) => toggleField(label, desc, state.settings[key], (v) => { setSetting(key, v); if (key === 'motion' && !v) toast('Animations reduced. Particles and trails pause too.', { type: 'info' }); });
  const display = h('section', { class: 'cp-section panel', id: 'display' },
    h('h3', { class: 'h3' }, icEl('monitor'), ' Display & effects'),
    h('div', { class: 'cp-grid' },
      t('motion', 'Animations', 'Window transitions, typing effects and gentle motion. Off = reduced motion.'),
      t('particles', 'Floating particles', 'Sparkles drifting behind the windows.'),
      t('trail', 'Cursor sparkle trail', 'Mouse only.'),
      t('cursor', 'Retro pixel cursor', 'Classic arrow & hand cursors.'),
      t('crt', 'CRT scanlines', 'Subtle scanlines and screen curvature glow.'),
      t('vhs', 'VHS noise', 'Faint tape noise overlay.'),
      t('boot', 'Boot screen', 'Show the BIOS + loading screen once per session.'),
      t('hideSamples', 'Hide sample community posts', 'Only show posts from real people.')),
    h('div', { class: 'row tight' }, h('button', { class: 'btn btn-ghost btn-sm', onclick: () => runBoot({ force: true }) }, icEl('power'), 'Replay boot screen'),
      h('button', { class: 'btn btn-ghost btn-sm', onclick: () => { ['crt', 'vhs', 'particles', 'trail'].forEach((k) => setSetting(k, false)); toast('All visual effects turned off.', { type: 'info' }); ctx.rerender(); } }, icEl('eyeOff'), 'Disable all effects')));
  const access = h('section', { class: 'cp-section panel', id: 'accessibility' },
    h('h3', { class: 'h3' }, icEl('eye'), ' Accessibility'),
    h('div', { class: 'cp-grid' },
      t('legible', 'Legible mode', 'Larger text, standard fonts instead of pixel fonts, standard cursor, higher-contrast secondary text.')),
    h('p', { class: 'small dim', style: { margin: 0 } }, 'Your system “reduce motion” preference is respected automatically on first visit. Keyboard: Tab to move, Enter to activate, Esc closes windows and menus, Ctrl+K or / opens search.'));

  const deskBox = h('div', { class: 'row tight' });
  const drawDesk = () => {
    const o = state.settings.desktopOverride;
    swap(deskBox, o ? h('div', { class: 'thumb-sm' }, wallpaperView(o, { thumb: true })) : null,
      h('span', { class: 'small' }, o ? 'Custom wallpaper (overrides your active theme)' : state.activeThemeId ? 'Using your active theme’s wallpaper' : 'Default RETRO.EXE night sky'),
      o ? h('button', { class: 'btn btn-ghost btn-sm', onclick: () => { setSetting('desktopOverride', null); drawDesk(); } }, icEl('undo'), 'Use theme wallpaper') : null,
      h('a', { class: 'btn btn-ghost btn-sm', href: '#/world' }, icEl('layers'), 'Choose theme'));
  };
  drawDesk();
  const desktop = h('section', { class: 'cp-section panel' }, h('h3', { class: 'h3' }, icEl('image'), ' Desktop background'), deskBox);

  root.append(
    h('header', { class: 'page-head' }, h('div', null, h('p', { class: 'eyebrow' }, 'Control Panel'), h('h2', { class: 'h1' }, 'Settings'), h('p', { class: 'muted' }, 'Display preferences are saved on this device. Your library and account live on the server.'))),
    h('nav', { class: 'cp-nav', 'aria-label': 'Control Panel sections' }, ...[['display', 'monitor', 'Display'], ['accessibility', 'eye', 'Accessibility'], ['account', 'user', 'Account'], ['plus', 'star', 'RETRO+'], ['about', 'info', 'About']].map(([id, i, l]) =>
      h('button', { class: 'cp-link', onclick: () => root.querySelector(`#${id}`)?.scrollIntoView({ behavior: state.settings.motion ? 'smooth' : 'auto', block: 'start' }) }, h('span', { class: 'cp-ic', html: ic(i) }), l))),
    display, access, desktop, accountSection(ctx), plusSection(), aboutSection());
}

function accountSection(ctx) {
  const box = h('section', { class: 'cp-section panel', id: 'account' }, h('h3', { class: 'h3' }, icEl('user'), ' Account'));
  if (isGuest()) {
    box.append(h('p', null, 'You’re using a ', h('b', null, 'guest session'), '. Your themes, favourites, collections and creations are stored on the server under a private guest token kept in this browser. Clearing site data would lose them.'),
      h('div', { class: 'row tight' }, h('button', { class: 'btn btn-primary', onclick: () => openAuthModal('register') }, icEl('user'), 'Create free account'), h('button', { class: 'btn btn-ghost', onclick: () => openAuthModal('login') }, icEl('login'), 'Sign in')),
      h('p', { class: 'small dim' }, 'With an account you can share themes, like and follow, use AI generation, and sign in from any device.'));
    return box;
  }
  const u = state.user;
  const s = { themes: state.themes.length, favorites: state.favorites.size, collections: state.collections.length, creations: state.creations.length, posts: state.stats?.posts ?? 0 };
  const nameEl = h('b', null, u.displayName || u.username);
  box.append(
    h('div', { class: 'row' }, avatarImg(u.username, 'lg'), h('div', { class: 'stack', style: { gap: '2px' } }, nameEl, h('span', { class: 'small muted' }, `@${u.username} · ${u.role === 'admin' ? 'Administrator' : u.role === 'mod' ? 'Moderator' : 'Member'} · joined ${timeAgo(u.createdAt)}`))),
    h('div', { class: 'profile-stats' }, ...[['themes', 'themes'], ['favorites', 'favourites'], ['collections', 'collections'], ['creations', 'creations'], ['posts', 'posts']].map(([k, l]) => h('span', null, h('b', null, s[k] ?? 0), ` ${l}`))),
    h('div', { class: 'row tight' },
      h('button', { class: 'btn btn-ghost btn-sm', onclick: async () => { const n = await promptDialog({ title: 'Display name', label: 'Display name', value: u.displayName || '', maxLength: 40 }); if (n === null) return; try { await updateProfile({ displayName: n }); nameEl.textContent = n || u.username; toast('Display name updated.'); } catch (e) { toastError(e); } } }, icEl('edit'), 'Change display name'),
      h('a', { class: 'btn btn-ghost btn-sm', href: `#/u/${u.username}` }, icEl('user'), 'View public profile'),
      h('button', { class: 'btn btn-ghost btn-sm', onclick: async () => { if (await confirmDialog({ title: 'Log off?', message: 'You’ll continue as a new guest.', okText: 'Log off', icon: 'logout' })) { try { await logout(); navigate('/'); } catch (e) { toastError(e); } } } }, icEl('logout'), 'Log off')),
    h('h4', { class: 'h3', style: { marginTop: '18px' } }, 'Your data'),
    h('div', { class: 'row tight' },
      h('button', { class: 'btn btn-cyan btn-sm', onclick: (e) => withBusy(e.currentTarget, async () => { try { const d = await get('/me/export'); downloadBlob(new Blob([JSON.stringify(d, null, 2)], { type: 'application/json' }), `retro-exe-${u.username}-export.json`); toast('Your data export has downloaded.'); } catch (err) { toastError(err); } }) }, icEl('download'), 'Export my data (JSON)'),
      h('button', { class: 'btn btn-danger btn-sm', onclick: () => openDelete(u) }, icEl('trash'), 'Delete account…')));
  return box;
}

function openDelete(u) {
  const pw = textField('Confirm with your password', { maxlength: 200 });
  pw.input.type = 'password'; pw.input.autocomplete = 'current-password';
  const err = h('div', { class: 'form-error', role: 'alert' });
  const go = h('button', { class: 'btn btn-danger', onclick: () => withBusy(go, async () => {
    try { await deleteAccount(pw.input.value); m.close(); toast('Your account and all its data have been deleted.', { type: 'info', title: 'Account deleted' }); navigate('/'); }
    catch (e) { err.textContent = e.message; }
  }) }, icEl('trash'), 'Delete forever');
  const m = openModal({ title: 'Delete account', icon: 'warning', width: 460, className: 'dialog98',
    body: h('div', { class: 'stack' }, h('p', { style: { margin: 0 } }, 'This permanently deletes ', h('b', null, `@${u.username}`), ', your themes, collections, creations, uploads, posts, likes and follows. This can’t be undone.'), pw, err),
    footer: [h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancel'), go] });
}

function plusSection() {
  return h('section', { class: 'cp-section panel plus-section', id: 'plus' },
    h('h3', { class: 'h3' }, h('span', { class: 'badge badge-plus' }, 'RETRO+'), ' Coming someday'),
    h('p', null, 'RETRO.EXE’s core — browsing, the Studio, themes, icon export and the community — is free. A future optional RETRO+ membership may add:'),
    h('ul', { class: 'plus-list' }, ...PREMIUM_FEATURES.map((f) => h('li', null, h('span', { class: 'ic', html: ic('star') }), h('div', null, h('b', null, f.title), h('div', { class: 'small muted' }, f.text))))),
    h('p', { class: 'small dim', style: { margin: 0 } }, 'Nothing is for sale yet and no payment details are ever requested. Items marked “Plus” are previews and are free during the beta.'));
}

function aboutSection() {
  return h('section', { class: 'cp-section panel', id: 'about' },
    h('h3', { class: 'h3' }, icEl('info'), ' About RETRO.EXE'),
    h('div', { class: 'about-box' },
      h('p', null, h('b', null, 'RETRO.EXE — Retro Aesthetic Studio'), h('br'), 'Version 1.0 (Build 2003.10)'),
      h('p', { class: 'small' }, 'Artwork: original illustrations created for RETRO.EXE plus procedural vector scenes drawn in your browser. Free for personal wallpapers.'),
      h('p', { class: 'small' }, 'Fonts: VT323 and Press Start 2P, both under the SIL Open Font License. UI text uses your system’s Tahoma/Segoe fonts.'),
      h('p', { class: 'small' }, 'Not affiliated with Microsoft, Sony or any company whose products inspired these aesthetics.'),
      h('p', { class: 'small dim' }, 'Shortcuts: Ctrl+K or / — search · Esc — close window · double-click title bar — maximize.')));
}

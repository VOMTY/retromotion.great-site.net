// My Digital World: themes library, favourites, collections and creations.
import { h, debounce, timeAgo } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { state, createTheme, updateTheme, duplicateTheme, deleteTheme, themeById, setActiveTheme, favoritesOf, toggleFavorite,
  createCollection, renameCollection, deleteCollection, removeFromCollection, deleteCreation, updateCreation, creationById, isGuest } from '../core/store.js';
import { navigate, replaceQuery } from '../core/router.js';
import { toast, toastError, confirmDialog, promptDialog, emptyState, openModal, withBusy, openMenu } from '../core/ui.js';
import { EXAMPLE_THEMES, WP_BY_ID } from '../data/catalog.js';
import { normalizeThemeData } from '../data/schema.js';
import { themePreview, paletteStrip } from '../components/themeview.js';
import { openThemeEditor, blankThemeData } from '../components/themeEditor.js';
import { creationCard, moreButton, sectionHead } from '../components/cards.js';
import { itemTile } from '../components/items.js';
import { openShareDialog } from '../components/community.js';
import { openWallpaperPreview, downloadMenu } from '../components/preview.js';
import { selectField, segField } from '../components/fields.js';
import { openAuthModal } from '../components/auth.js';
import { openPcExport } from '../components/pcExport.js';

const TABS = [['themes', 'Themes', 'layers'], ['favorites', 'Favourites', 'heart'], ['collections', 'Collections', 'folder'], ['creations', 'Creations', 'sliders']];

export async function render(root, ctx) {
  const tab = TABS.some(([k]) => k === ctx.params.tab) ? ctx.params.tab : 'themes';
  const counts = { themes: state.themes.length, favorites: state.favorites.size, collections: state.collections.length, creations: state.creations.length };
  root.append(
    h('header', { class: 'page-head' }, h('div', null, h('p', { class: 'eyebrow' }, 'My Digital World'), h('h2', { class: 'h1' }, 'Your corner of the internet.'),
      h('p', { class: 'muted' }, 'Themes bundle a wallpaper, palette, icons, widgets and decorations. Apply one to restyle RETRO.EXE, or use “Use on my PC” to install it on Windows and in Chrome, Edge or Firefox.'))),
    isGuest() ? h('div', { class: 'notice' }, icEl('info'), h('span', null, 'Guest library — saved in this browser’s session. ', h('button', { class: 'link-btn inline', onclick: () => openAuthModal('register') }, 'Create an account'), ' to keep it forever and sync across devices.')) : null,
    h('nav', { class: 'tabs', 'aria-label': 'My Digital World sections' }, ...TABS.map(([k, l, i]) => h('a', { href: `#/world${k === 'themes' ? '' : '/' + k}`, role: 'tab', 'aria-selected': String(k === tab), 'aria-current': k === tab ? 'page' : null }, icEl(i), l, h('span', { class: 'tab-count' }, counts[k])))));
  const body = h('div', { class: 'world-body' });
  root.append(body);
  ({ themes: themesTab, favorites: favoritesTab, collections: collectionsTab, creations: creationsTab })[tab](body, ctx);
}

// ---------------- themes ----------------
export function openThemeWindow(t) {
  let size = 'desktop';
  const stage = h('div', { class: 'post-stage' });
  const draw = () => stage.replaceChildren(themePreview(t.data, { size, live: true }));
  const isActive = state.activeThemeId === t.id;
  const m = openModal({
    title: `${t.name} — Theme`, icon: 'layers', width: 960,
    body: h('div', { class: 'post-view' },
      h('div', { class: 'stack' }, segField(null, [['desktop', 'Desktop', 'monitor'], ['mobile', 'Phone', 'phone']], size, (v) => { size = v; draw(); }), stage),
      h('aside', { class: 'stack post-side' }, h('h3', { class: 'h2', style: { margin: 0 } }, t.name), isActive ? h('span', { class: 'badge badge-ok' }, 'Active') : null,
        t.description ? h('p', { class: 'post-desc' }, t.description) : h('p', { class: 'dim' }, 'No description.'),
        t.folder ? h('span', { class: 'tag' }, icEl('folder'), ' ', t.folder) : null,
        h('div', null, h('div', { class: 'small muted', style: { marginBottom: '4px' } }, 'Palette'), paletteStrip(t.data.palette)),
        h('div', { class: 'small dim' }, `Edited ${timeAgo(t.updatedAt)}`),
        h('button', { class: 'btn btn-green', onclick: (e) => withBusy(e.currentTarget, () => applyTheme(t).then(() => m.close())) }, icEl('check'), isActive ? 'Re-apply' : 'Apply to RETRO.EXE'),
        h('button', { class: 'btn btn-primary', onclick: () => { m.close(); openThemeEditor(t); } }, icEl('edit'), 'Edit'),
        h('button', { class: 'btn btn-cyan', onclick: () => { m.close(); openPcExport(t); } }, icEl('monitor'), 'Use on my PC / browser'),
        h('div', { class: 'row tight' },
          h('button', { class: 'btn btn-ghost btn-sm', onclick: () => { m.close(); openShareDialog(t); } }, icEl('share'), 'Share'),
          h('button', { class: 'btn btn-ghost btn-sm', 'aria-haspopup': 'menu', onclick: (e) => downloadMenu(e.currentTarget, t.data.wallpaper, t.name) }, icEl('download'), 'Wallpaper'),
          h('a', { class: 'btn btn-ghost btn-sm', href: `#/icons?pack=${t.data.icons.pack}`, onclick: () => m.close() }, icEl('apps'), 'Icons')))),
  });
  draw();
}
async function applyTheme(t) {
  try { await setActiveTheme(t.id); toast(`“${t.name}” applied. Welcome to your new desktop.`, { title: 'Theme applied', action: { label: 'Undo', onClick: () => setActiveTheme(null).catch(toastError) } }); }
  catch (e) { toastError(e, "Couldn't apply theme"); }
}
function themeMenu(t) {
  return [
    { label: state.activeThemeId === t.id ? 'Remove from desktop' : 'Apply', icon: 'check', onClick: () => (state.activeThemeId === t.id ? setActiveTheme(null).then(() => toast('Back to the default RETRO.EXE look.', { type: 'info' })).catch(toastError) : applyTheme(t)) },
    { label: 'Edit…', icon: 'edit', onClick: () => openThemeEditor(t) },
    { label: 'Duplicate', icon: 'copy', onClick: () => duplicateTheme(t.id).then((c) => toast(`Duplicated as “${c.name}”.`)).catch(toastError) },
    { label: 'Move to folder…', icon: 'folder', onClick: async () => { const f = await promptDialog({ title: 'Move to folder', label: 'Folder name (leave empty for none)', value: t.folder, maxLength: 30, okText: 'Move', icon: 'folder' }); if (f === null) return; updateTheme(t.id, { folder: f.trim() }).then(() => toast(f.trim() ? `Moved to “${f.trim()}”.` : 'Removed from folder.', { type: 'info' })).catch(toastError); } },
    { label: 'Use on my PC / browser…', icon: 'monitor', onClick: () => openPcExport(t) },
    { label: 'Share to community…', icon: 'share', onClick: () => openShareDialog(t) },
    { sep: true },
    { label: 'Delete', icon: 'trash', danger: true, onClick: async () => { if (await confirmDialog({ title: 'Delete theme?', message: `“${t.name}” will be permanently deleted. Posts you shared stay in the community.`, okText: 'Delete', danger: true })) deleteTheme(t.id).then(() => toast('Theme deleted.', { type: 'info' })).catch(toastError); } },
  ];
}
function themeCard(t) {
  const active = state.activeThemeId === t.id;
  return h('article', { class: `card clickable theme-card ${active ? 'is-active' : ''}` },
    h('div', { class: 'card-media' }, themePreview(t.data, { labels: false })),
    h('button', { class: 'stretch', 'aria-label': `Open theme ${t.name}`, onclick: () => openThemeWindow(t) }),
    h('div', { class: 'card-badges' }, active ? h('span', { class: 'badge badge-ok' }, icEl('check'), ' Active') : null),
    h('div', { class: 'card-actions' }, moreButton(`Actions for ${t.name}`, () => themeMenu(t))),
    h('div', { class: 'card-body' }, h('h3', { class: 'card-title' }, t.name),
      h('div', { class: 'row tight', style: { justifyContent: 'space-between' } }, h('span', { class: 'card-meta' }, t.folder ? [icEl('folder'), ' ', t.folder, ' · '] : null, timeAgo(t.updatedAt)), paletteStrip(t.data.palette)),
      h('div', { class: 'row tight card-cta' },
        h('button', { class: `btn btn-sm ${active ? 'btn-ghost' : 'btn-green'}`, disabled: active, onclick: (e) => { e.stopPropagation(); withBusy(e.currentTarget, () => applyTheme(t)); } }, icEl('check'), active ? 'Applied' : 'Apply'),
        h('button', { class: 'btn btn-sm btn-ghost', onclick: (e) => { e.stopPropagation(); openThemeEditor(t); } }, icEl('edit'), 'Edit'))));
}
function exampleMenu(anchor) {
  openMenu(anchor, [{ heading: 'Start from an example' }, ...EXAMPLE_THEMES.map((ex) => ({ label: ex.name, icon: 'layers', onClick: () => createTheme({ name: ex.name, description: ex.description, folder: ex.folder, data: ex.data }).then((t) => toast(`“${t.name}” added to your library.`, { action: { label: 'Apply', onClick: () => applyTheme(t) } })).catch(toastError) }))]);
}

function themesTab(body, ctx) {
  // deep links: ?newTheme=<wallpaperId>, ?fromCreation=<id>, ?theme=<id>
  const q0 = ctx.query;
  if (q0.newTheme || q0.fromCreation || q0.theme) {
    queueMicrotask(() => {
      if (q0.theme && themeById(q0.theme)) openThemeWindow(themeById(q0.theme));
      else if (q0.fromCreation && creationById(q0.fromCreation)) { const c = creationById(q0.fromCreation); openThemeEditor(null, { name: `${c.name} Theme`, data: { ...blankThemeData(), wallpaper: c.config } }); }
      else if (q0.newTheme && WP_BY_ID[q0.newTheme]) openThemeEditor(null, { name: `${WP_BY_ID[q0.newTheme].title} Theme`, data: blankThemeData({ type: 'wp', id: q0.newTheme }) });
      replaceQuery({});
    });
  }
  let q = '', folder = '', sort = 'recent';
  const grid = h('div', { class: 'grid g-md' });
  const folderSel = h('div', { style: { flex: '0 1 200px' } });
  const drawFolders = () => {
    const folders = [...new Set(state.themes.map((t) => t.folder).filter(Boolean))].sort();
    if (folder && !folders.includes(folder)) folder = '';
    folderSel.replaceChildren(selectField('Folder', [['', `All folders (${state.themes.length})`], ...folders.map((f) => [f, `${f} (${state.themes.filter((t) => t.folder === f).length})`])], folder, (v) => { folder = v; draw(); }));
  };
  const draw = () => {
    let list = state.themes.filter((t) => (!folder || t.folder === folder) && (!q || `${t.name} ${t.description} ${t.folder}`.toLowerCase().includes(q)));
    if (sort === 'az') list = [...list].sort((a, b) => a.name.localeCompare(b.name));
    else list = [...list].sort((a, b) => (b.id === state.activeThemeId) - (a.id === state.activeThemeId) || b.updatedAt - a.updatedAt);
    grid.replaceChildren(...(list.length ? list.map(themeCard) : [state.themes.length
      ? emptyState({ icon: 'search', title: 'No themes match', text: 'Try a different search or folder.' })
      : emptyState({ icon: 'layers', title: 'Your library is empty', text: 'Create a theme from scratch or start from one of our examples.', action: h('button', { class: 'btn btn-primary', onclick: (e) => exampleMenu(e.currentTarget) }, icEl('plus'), 'Add an example theme') })]));
  };
  body.append(h('div', { class: 'toolbar' },
    h('button', { class: 'btn btn-primary', onclick: () => openThemeEditor(null) }, icEl('plus'), 'New theme'),
    h('button', { class: 'btn btn-ghost', 'aria-haspopup': 'menu', onclick: (e) => exampleMenu(e.currentTarget) }, icEl('star'), 'From example'),
    h('div', { class: 'search', style: { flex: '1 1 200px' } }, h('span', { class: 'search-ic', html: ic('search') }), h('input', { class: 'input', type: 'search', placeholder: 'Search themes…', 'aria-label': 'Search your themes', oninput: debounce((e) => { q = e.target.value.trim().toLowerCase(); draw(); }, 120) })),
    folderSel,
    h('div', { style: { flex: '0 1 170px' } }, selectField('Sort', [['recent', 'Recently edited'], ['az', 'Name A → Z']], sort, (v) => { sort = v; draw(); }))), grid);
  drawFolders(); draw();
  ctx.subscribe('themes', () => { drawFolders(); draw(); });
  ctx.subscribe('activeTheme', draw);
}

// ---------------- favourites ----------------
function favoritesTab(body, ctx) {
  const GROUPS = [['wallpaper', 'Wallpapers', 'image'], ['aesthetic', 'Aesthetics', 'compass'], ['collection', 'Collections', 'folder'], ['iconpack', 'Icon packs', 'apps'], ['post', 'Community themes', 'users']];
  const draw = () => {
    const sections = GROUPS.map(([type, label, icon]) => {
      const tiles = favoritesOf(type).map((id) => itemTile({ type, id }, { onRemove: () => toggleFavorite(type, id).then(() => toast('Removed from favourites.', { type: 'info' })).catch(toastError) })).filter(Boolean);
      return tiles.length ? h('section', { class: 'section' }, sectionHead(`${label} (${tiles.length})`, icon), h('div', { class: 'grid g-sm' }, ...tiles)) : null;
    }).filter(Boolean);
    body.replaceChildren(...(sections.length ? sections : [emptyState({ icon: 'heart', title: 'No favourites yet', text: 'Tap the heart on wallpapers, aesthetics, collections, icon packs or community themes.', action: h('a', { class: 'btn btn-cyan', href: '#/wallpapers' }, icEl('image'), 'Browse wallpapers') })]));
  };
  draw();
  ctx.subscribe('favorites', draw);
}

// ---------------- collections ----------------
function collectionsTab(body, ctx) {
  const list = h('div', { class: 'stack' });
  const draw = () => {
    list.replaceChildren(...(state.collections.length ? state.collections.map((c) => {
      const tiles = c.items.map((it) => itemTile(it, { keepMissing: true, onRemove: () => removeFromCollection(c.id, it.type, it.id).then(() => toast(`Removed from “${c.name}”.`, { type: 'info' })).catch(toastError) }));
      return h('section', { class: 'panel coll-panel' },
        h('div', { class: 'row' }, h('div', { class: 'stack', style: { gap: '2px' } }, h('h3', { class: 'h3', style: { margin: 0 } }, icEl('folder'), ' ', c.name), h('span', { class: 'small muted' }, `${c.items.length} item${c.items.length === 1 ? '' : 's'}${c.description ? ' · ' + c.description : ''}`)),
          h('span', { class: 'spacer' }),
          moreButton(`Actions for ${c.name}`, [
            { label: 'Rename…', icon: 'edit', onClick: async () => { const n = await promptDialog({ title: 'Rename collection', label: 'Name', value: c.name, maxLength: 50 }); if (n) renameCollection(c.id, n).catch(toastError); } },
            { label: 'Edit description…', icon: 'type', onClick: async () => { const d = await promptDialog({ title: 'Collection description', label: 'Description', value: c.description || '', maxLength: 200, multiline: true }); if (d !== null) renameCollection(c.id, undefined, d).catch(toastError); } },
            { sep: true },
            { label: 'Delete collection', icon: 'trash', danger: true, onClick: async () => { if (await confirmDialog({ title: 'Delete collection?', message: `“${c.name}” will be deleted. The items themselves aren’t affected.`, okText: 'Delete', danger: true })) deleteCollection(c.id).then(() => toast('Collection deleted.', { type: 'info' })).catch(toastError); } },
          ])),
        tiles.length ? h('div', { class: 'hscroll cards-row small-cards' }, ...tiles) : h('p', { class: 'small dim', style: { margin: '8px 0 0' } }, 'Empty — use the bookmark button on any wallpaper, pack or post to save it here.'));
    }) : [emptyState({ icon: 'folder', title: 'No collections yet', text: 'Collections group wallpapers, aesthetics, icon packs, themes and community posts however you like.' })]));
  };
  body.append(h('div', { class: 'toolbar' }, h('button', { class: 'btn btn-primary', onclick: async () => {
    const name = await promptDialog({ title: 'New collection', label: 'Collection name', placeholder: 'e.g. Rainy pool rooms', maxLength: 50, okText: 'Create', icon: 'folder' });
    if (name) createCollection(name).then(() => toast(`Created “${name}”.`)).catch(toastError);
  } }, icEl('plus'), 'New collection')), list);
  draw();
  ctx.subscribe('collections', draw);
}

// ---------------- creations ----------------
function creationsTab(body, ctx) {
  const grid = h('div', { class: 'grid g-md' });
  const draw = () => {
    grid.replaceChildren(...(state.creations.length ? state.creations.map((c) => creationCard(c, {
      onOpen: () => openWallpaperPreview({ title: c.name, config: c.config, creationId: c.id }),
      actions: [moreButton(`Actions for ${c.name}`, [
        { label: 'Edit in Studio', icon: 'sliders', onClick: () => navigate('/studio', { creation: c.id }) },
        { label: 'Use in new theme', icon: 'layers', onClick: () => navigate('/world', { fromCreation: c.id }) },
        { label: 'Rename…', icon: 'edit', onClick: async () => { const n = await promptDialog({ title: 'Rename creation', label: 'Name', value: c.name, maxLength: 60 }); if (n) updateCreation(c.id, { name: n }).catch(toastError); } },
        { sep: true },
        { label: 'Delete', icon: 'trash', danger: true, onClick: async () => { if (await confirmDialog({ title: 'Delete creation?', message: `“${c.name}” will be permanently deleted.`, okText: 'Delete', danger: true })) deleteCreation(c.id).then(() => toast('Creation deleted.', { type: 'info' })).catch(toastError); } },
      ])],
    })) : [emptyState({ icon: 'sliders', title: 'No creations yet', text: 'Compose a wallpaper in the Studio or roll one in the Dream Generator, then save it.', action: h('a', { class: 'btn btn-primary', href: '#/studio' }, icEl('sliders'), 'Open the Studio') })]));
  };
  body.append(h('div', { class: 'toolbar' }, h('a', { class: 'btn btn-primary', href: '#/studio' }, icEl('plus'), 'New composition'), h('a', { class: 'btn btn-ghost', href: '#/studio?tab=dream' }, icEl('wand'), 'Dream Generator')), grid);
  draw();
  ctx.subscribe('creations', draw);
}

// Aesthetic Explorer: index of 12 aesthetics + a themed detail view for each.
import { h, debounce, copyText } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { get } from '../core/api.js';
import { state, addRecent, isFav } from '../core/store.js';
import { navigate, replaceQuery } from '../core/router.js';
import { emptyState, errorBox, toast } from '../core/ui.js';
import { AESTHETICS, AESTHETIC_BY_ID, WALLPAPERS, COLLECTIONS, ICON_PACKS } from '../data/catalog.js';
import { aestheticCard, wallpaperCard, collectionCard, iconPackCard, favButton, sectionHead } from '../components/cards.js';
import { openWallpaperPreview, openCollectionPreview } from '../components/preview.js';
import { postCard } from '../components/community.js';
import { openThemeEditor, themeDataFromAesthetic } from '../components/themeEditor.js';
import { segField } from '../components/fields.js';
import { wallpaperView } from '../lib/render.js';

const countFor = (id) => WALLPAPERS.filter((w) => w.aesthetic === id).length + COLLECTIONS.filter((c) => c.aesthetic === id).length + ICON_PACKS.filter((p) => p.aesthetic === id).length;

export async function render(root, ctx) {
  if (ctx.params.aesthetic) return detail(root, ctx, ctx.params.aesthetic);
  let q = ctx.query.q || '', show = ctx.query.show || 'all';
  const grid = h('div', { class: 'grid g-lg aes-grid' });
  const draw = () => {
    const needle = q.toLowerCase();
    const list = AESTHETICS.filter((a) => (show !== 'fav' || isFav('aesthetic', a.id)) && (!needle || `${a.name} ${a.tagline} ${a.description} ${a.keywords.join(' ')}`.toLowerCase().includes(needle)));
    grid.replaceChildren(...(list.length ? list.map((a) => aestheticCard(a, countFor(a.id)))
      : [emptyState({ icon: show === 'fav' ? 'heart' : 'search', title: show === 'fav' ? 'No favourite aesthetics yet' : `Nothing matches “${q}”`, text: show === 'fav' ? 'Tap the heart on any aesthetic to pin it here.' : 'Try a mood like “eerie”, a colour like “pink”, or an era like “2004”.' })]));
    replaceQuery({ q, show: show === 'all' ? '' : show });
  };
  const search = h('input', { class: 'input', type: 'search', value: q, placeholder: 'Filter aesthetics by name, mood or keyword…', 'aria-label': 'Filter aesthetics', oninput: debounce((e) => { q = e.target.value.trim(); draw(); }, 120) });
  root.append(
    h('header', { class: 'page-head' }, h('div', null, h('p', { class: 'eyebrow' }, 'Aesthetic Explorer'), h('h2', { class: 'h1' }, 'Twelve worlds, one desktop.'), h('p', { class: 'muted' }, 'Each aesthetic has its own palette, typography and curated wallpapers, collections and icon packs.'))),
    h('div', { class: 'toolbar' }, h('div', { class: 'search' }, h('span', { class: 'search-ic', html: ic('search') }), search),
      segField(null, [['all', 'All'], ['fav', 'Favourites', 'heart']], show, (v) => { show = v; draw(); })),
    grid);
  draw();
  ctx.subscribe('favorites', () => { if (show === 'fav') draw(); });
}

function detail(root, ctx, id) {
  const a = AESTHETIC_BY_ID[id];
  if (!a) {
    root.append(emptyState({ icon: 'warning', title: 'Aesthetic not found', text: `“${id}” isn’t one of our twelve worlds (yet).`, action: h('a', { class: 'btn btn-primary', href: '#/explore' }, 'Back to Explorer') }));
    return;
  }
  ctx.setTitle(`${a.name} — Aesthetic Explorer`);
  addRecent('aesthetic', a.id);
  const idx = AESTHETICS.indexOf(a);
  const prev = AESTHETICS[(idx + AESTHETICS.length - 1) % AESTHETICS.length], next = AESTHETICS[(idx + 1) % AESTHETICS.length];
  const wps = WALLPAPERS.filter((w) => w.aesthetic === a.id);
  const cols = COLLECTIONS.filter((c) => c.aesthetic === a.id || c.items.some((i) => wps.some((w) => w.id === i)));
  const packs = ICON_PACKS.filter((p) => p.aesthetic === a.id);
  const cover = wps.find((w) => w.kind === 'image') || wps[0];

  const hero = h('section', { class: `aes-hero ${a.font} ${ctx.query.surprise ? 'surprise-in' : ''}`, style: { '--a0': a.palette[0], '--a1': a.palette[1], '--a2': a.palette[2], '--a3': a.palette[3], '--a4': a.palette[4] } },
    h('div', { class: 'aes-hero-bg' }, wallpaperView({ base: { type: 'wp', id: cover.id }, overlays: { vignette: 60 } }, { live: true, eager: true })),
    h('div', { class: 'aes-hero-content' },
      h('a', { class: 'link-btn back', href: '#/explore' }, icEl('arrowLeft'), 'All aesthetics'),
      h('h2', { class: 'aes-title' }, a.name),
      h('p', { class: 'aes-tagline' }, a.tagline),
      h('p', { class: 'aes-desc' }, a.description),
      h('div', { class: 'chips' }, ...a.keywords.map((k) => h('a', { class: 'chip glass', href: `#/search?q=${encodeURIComponent(k)}` }, `#${k}`))),
      h('div', { class: 'aes-palette', 'aria-label': 'Palette — click a colour to copy it' }, ...a.palette.map((c) => h('button', { class: 'pal-chip', style: { '--c': c }, title: `Copy ${c}`, 'aria-label': `Copy colour ${c}`, onclick: () => copyText(c).then(() => toast(`Copied ${c}`, { type: 'info', timeout: 1600 })) }, h('span', null, c)))),
      h('div', { class: 'row' },
        h('button', { class: 'btn btn-primary', onclick: () => openThemeEditor(null, { name: `${a.name} Desktop`, description: a.tagline, folder: a.name, data: themeDataFromAesthetic(a) }) }, icEl('layers'), 'Make a theme from this'),
        h('a', { class: 'btn btn-ghost', href: `#/studio?wp=${cover.id}` }, icEl('sliders'), 'Remix in Studio'),
        favButton('aesthetic', a.id, a.name))));

  // filters within the aesthetic
  let type = ctx.query.type || 'all', q = ctx.query.q || '', favOnly = ctx.query.fav === '1';
  const body = h('div', { class: 'stack' });
  const match = (text) => !q || text.toLowerCase().includes(q.toLowerCase());
  const draw = () => {
    replaceQuery({ type: type === 'all' ? '' : type, q, fav: favOnly ? '1' : '' });
    const fw = wps.filter((w) => match(`${w.title} ${w.mood} ${w.colors.join(' ')}`) && (!favOnly || isFav('wallpaper', w.id)));
    const fc = cols.filter((c) => match(`${c.title} ${c.description}`) && (!favOnly || isFav('collection', c.id)));
    const fp = packs.filter((p) => match(`${p.name} ${p.config.style}`) && (!favOnly || isFav('iconpack', p.id)));
    const out = [];
    if ((type === 'all' || type === 'wallpapers') && fw.length) out.push(h('section', { class: 'section' }, sectionHead(`Wallpapers (${fw.length})`, 'image'), h('div', { class: 'grid g-md' }, ...fw.map((w) => wallpaperCard(w, { onOpen: openWallpaperPreview })))));
    if ((type === 'all' || type === 'collections') && fc.length) out.push(h('section', { class: 'section' }, sectionHead(`Curated collections (${fc.length})`, 'folder'), h('div', { class: 'grid g-md' }, ...fc.map((c) => collectionCard(c, { onOpen: openCollectionPreview })))));
    if ((type === 'all' || type === 'icons') && fp.length) out.push(h('section', { class: 'section' }, sectionHead(`Icon packs (${fp.length})`, 'apps'), h('div', { class: 'grid g-md' }, ...fp.map(iconPackCard))));
    body.replaceChildren(...(out.length ? out : [emptyState({ icon: favOnly ? 'heart' : 'search', title: favOnly ? 'No favourites here yet' : 'No matches', text: favOnly ? `Heart some ${a.name} items and they’ll collect here.` : 'Try clearing the search or picking “All”.' })]));
  };
  const toolbar = h('div', { class: 'toolbar' },
    h('div', { class: 'search' }, h('span', { class: 'search-ic', html: ic('search') }), h('input', { class: 'input', type: 'search', value: q, placeholder: `Search ${a.name}…`, 'aria-label': `Search within ${a.name}`, oninput: debounce((e) => { q = e.target.value.trim(); draw(); }, 120) })),
    segField(null, [['all', 'All'], ['wallpapers', 'Wallpapers'], ['collections', 'Collections'], ['icons', 'Icons']], type, (v) => { type = v; draw(); }),
    h('button', { class: `btn btn-sm ${favOnly ? 'is-on' : 'btn-ghost'}`, 'aria-pressed': String(favOnly), onclick: (e) => { favOnly = !favOnly; e.currentTarget.setAttribute('aria-pressed', String(favOnly)); e.currentTarget.className = `btn btn-sm ${favOnly ? 'is-on' : 'btn-ghost'}`; draw(); } }, icEl('heart'), 'Favourites only'));

  const community = h('div', { class: 'grid g-md' }, h('div', { class: 'card skeleton', style: { aspectRatio: '4/3.4' } }));
  const loadCommunity = async () => {
    try {
      const r = await get('/posts', { query: { aesthetic: a.id, limit: 6, samples: state.settings.hideSamples ? '0' : undefined } });
      if (!ctx.isActive()) return;
      community.replaceChildren(...(r.posts.length ? r.posts.map((p) => postCard(p, { onRemoved: loadCommunity })) : [emptyState({ icon: 'users', title: `No ${a.name} themes shared yet`, text: 'Make one with the button above and share it from My Digital World.' })]));
    } catch (e) { if (ctx.isActive()) community.replaceChildren(errorBox(e, loadCommunity)); }
  };

  root.append(hero, h('div', { class: `aes-body ${a.font}`, style: { '--a0': a.palette[0], '--a1': a.palette[1] } }, toolbar, body,
    h('section', { class: 'section' }, sectionHead(`${a.name} in the community`, 'users', h('a', { class: 'link-btn', href: `#/community?aesthetic=${a.id}` }, 'More ', icEl('arrowRight'))), community),
    h('nav', { class: 'aes-pager', 'aria-label': 'Other aesthetics' },
      h('a', { class: 'btn btn-ghost', href: `#/explore/${prev.id}` }, icEl('arrowLeft'), prev.name),
      h('a', { class: 'btn btn-ghost', href: `#/explore/${next.id}` }, next.name, icEl('arrowRight')))));
  draw();
  loadCommunity();
  ctx.subscribe('favorites', () => { if (favOnly) draw(); });
}

// Wallpaper Studio: composer (base, adjustments, overlays, caption) + Dream Generator (AI or procedural).
import { h, swap, debounce } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { api, get, post } from '../core/api.js';
import { state, createCreation, updateCreation, creationById, setSetting, isGuest } from '../core/store.js';
import { navigate, replaceQuery } from '../core/router.js';
import { toast, toastError, withBusy, promptDialog, errorBox, loadingBox, hourglass } from '../core/ui.js';
import { normalizeComposition, SCENES, SCENE_LABELS, SCENE_OBJECTS, CAPTION_STYLES, CAPTION_POS } from '../data/schema.js';
import { AESTHETICS, AESTHETIC_BY_ID, WALLPAPERS, WP_BY_ID, MOODS } from '../data/catalog.js';
import { wallpaperView, baseInfo } from '../lib/render.js';
import { mix, rng } from '../lib/wallgen.js';
import { deviceFrame, downloadMenu, enableTilt } from '../components/preview.js';
import { openWallpaperPicker } from '../components/pickers.js';
import { rangeField, toggleField, colorField, selectField, segField, textField } from '../components/fields.js';
import { requireAccount } from '../components/auth.js';
import { studioTabs } from './wallpapers.js';

const PAL_LABELS = {
  grid: ['Sky top', 'Sky bottom', 'Sun top', 'Sun bottom', 'Grid'], hills: ['Sky top', 'Sky bottom', 'Hill light', 'Hill dark', 'Clouds'],
  clouds: ['Sky top', 'Sky bottom', 'Clouds', 'Object', 'Ground'], bubbles: ['Top', 'Bottom', 'Bubbles', 'Wave 1', 'Wave 2'],
  hallway: ['Walls', 'Floor', 'Ceiling', 'Lights', 'Door'], pool: ['Tiles', 'Grout', 'Water', 'Light', 'Deep water'],
  chrome: ['Back 1', 'Back 2', 'Back 3', 'Tint', 'Sparkle'], circuit: ['Background', 'Trace 1', 'Trace 2', 'City', 'Glow'],
  checker: ['Sky top', 'Sky bottom', 'Check 1', 'Check 2', 'Object'], stars: ['Top', 'Bottom', 'Stars', 'Globe', 'Accent'],
  pixel: ['Sky top', 'Sky bottom', 'Mountains', 'Ground', 'Lights'], desktop98: ['Desktop', 'Window face', 'Title 1', 'Title 2', 'Accent'],
  ps2: ['Top', 'Bottom', 'Towers', 'Glow', 'Particles'], bsod: ['Background', 'Text', 'Accent', 'Unused', 'Unused'],
  aurora: ['Sky top', 'Sky bottom', 'Aurora 1', 'Aurora 2', 'Hills'], mesh: ['Base', 'Blob 1', 'Blob 2', 'Blob 3', 'Blob 4'],
};
const CAPTION_LABELS = { pixel: 'Pixel', chrome: 'Chrome', serif: 'Dream serif', dialog: 'Error dialog', vcr: 'VCR', glitch: 'Glitch' };
export const AES_SCENES = { dreamcore: ['clouds', 'hills', 'aurora', 'checker'], y2k: ['chrome', 'bubbles', 'mesh'], windowscore: ['hills', 'desktop98', 'bsod'], retrocore: ['desktop98', 'checker', 'grid'], 'frutiger-aero': ['bubbles', 'hills', 'aurora'], liminal: ['hallway', 'pool'], vaporwave: ['grid', 'checker'], cybercore: ['circuit', 'grid'], weirdcore: ['checker', 'hallway', 'clouds'], ps2: ['ps2', 'stars'], 'old-internet': ['stars', 'checker', 'desktop98'], pixelcore: ['pixel'] };
const MOOD_FX = {
  dreamy: { adjust: { brightness: 106, saturation: 92 }, overlays: { vignette: 25, grain: 10 } },
  eerie: { adjust: { saturation: 70, contrast: 108, brightness: 92 }, overlays: { grain: 30, vignette: 55, scanlines: 15 } },
  cozy: { adjust: { saturation: 105 }, overlays: { tint: '#ff9a3c', tintAmount: 14, vignette: 30 } },
  energetic: { adjust: { saturation: 130, contrast: 112 }, overlays: { chroma: 25 } },
  calm: { adjust: { saturation: 85, brightness: 103 }, overlays: { vignette: 15 } },
  nostalgic: { adjust: { saturation: 88, contrast: 95 }, overlays: { grain: 25, vhs: 30, scanlines: 20 } },
};
const genTemplate = (scene, aes) => WALLPAPERS.find((w) => w.kind === 'gen' && w.gen.scene === scene && w.aesthetic === aes) || WALLPAPERS.find((w) => w.kind === 'gen' && w.gen.scene === scene);

/** Procedural "dream": a varied scene for an aesthetic + mood. */
export function dreamComposition(aesId, mood, seed = Math.floor(Math.random() * 1e6)) {
  const r = rng(seed);
  const a = AESTHETIC_BY_ID[aesId] || AESTHETICS[Math.floor(r() * AESTHETICS.length)];
  const scenes = AES_SCENES[a.id] || SCENES;
  const scene = scenes[Math.floor(r() * scenes.length)];
  const tpl = genTemplate(scene, a.id);
  const basePal = tpl ? tpl.gen.palette : a.palette;
  const palette = basePal.map((c) => mix(c, a.palette[Math.floor(r() * a.palette.length)], r() * 0.35));
  const objects = ['dreamcore', 'weirdcore', 'liminal'].includes(a.id) ? SCENE_OBJECTS : ['none'];
  const fx = MOOD_FX[mood] || {};
  return normalizeComposition({
    base: { type: 'gen', scene, palette, seed: Math.floor(r() * 1e6), opts: { stars: tpl?.gen.opts?.stars ?? r() > 0.5, sun: tpl?.gen.opts?.sun ?? r() > 0.4, object: objects[Math.floor(r() * objects.length)] } },
    adjust: fx.adjust, overlays: fx.overlays,
  });
}

export async function render(root, ctx) {
  if (ctx.query.tab === 'dream') return dreamTab(root, ctx);
  let editing = ctx.query.creation ? creationById(ctx.query.creation) : null;
  if (ctx.query.creation && !editing) toast('That creation could not be found — starting a new composition.', { type: 'err' });
  let comp = normalizeComposition(editing ? structuredClone(editing.config)
    : ctx.query.wp && WP_BY_ID[ctx.query.wp] ? { base: { type: 'wp', id: ctx.query.wp } }
    : ctx.query.upload ? { base: { type: 'upload', url: ctx.query.upload, label: 'Dream Generator image' } }
    : ctx.query.dream ? JSON.parse(sessionStorage.getItem('retro.dream') || 'null') || { base: { type: 'wp', id: 'img-dreamcore' } }
    : { base: { type: 'wp', id: 'img-vaporwave' } });
  let size = 'desktop', dirty = false;
  const history = [];
  let pendingSnap = null, snapTimer = 0;

  ctx.setTitle(editing ? `${editing.name} — Wallpaper Studio` : 'Wallpaper Studio');
  const stage = h('div', { class: 'studio-stage' });
  const drawStage = () => {
    const frame = deviceFrame(wallpaperView(comp, { size, live: true, eager: true, label: 'Composition preview' }), size);
    stage.replaceChildren(frame); enableTilt(frame);
  };
  const raf = { id: 0 };
  const changed = () => {
    dirty = true;
    if (!pendingSnap) pendingSnap = JSON.stringify(lastState);
    clearTimeout(snapTimer);
    snapTimer = setTimeout(() => { history.push(pendingSnap); if (history.length > 40) history.shift(); pendingSnap = null; undoBtn.disabled = false; lastState = structuredClone(comp); }, 450);
    cancelAnimationFrame(raf.id); raf.id = requestAnimationFrame(drawStage);
  };
  let lastState = structuredClone(comp);
  ctx.onCleanup(() => { clearTimeout(snapTimer); cancelAnimationFrame(raf.id); });

  // ---------- base controls ----------
  const baseBox = h('div', { class: 'stack' });
  const modeSeg = segField('Source', [['wp', 'Library', 'image'], ['gen', 'Scene', 'wand'], ['upload', 'Upload', 'upload']], comp.base.type, (v) => switchMode(v));
  function switchMode(mode) {
    if (mode === comp.base.type) return;
    if (mode === 'gen') {
      const cur = comp.base.type === 'wp' ? WP_BY_ID[comp.base.id] : null;
      comp.base = cur?.kind === 'gen' ? structuredClone(cur.gen) : dreamComposition(cur?.aesthetic || 'vaporwave').base;
    } else if (mode === 'wp') comp.base = { type: 'wp', id: 'img-vaporwave' };
    else { drawBase('upload-pick'); return; }
    changed(); drawBase();
  }
  function drawBase(force) {
    const b = comp.base;
    modeSeg.set(force === 'upload-pick' ? 'upload' : b.type);
    const out = [];
    if (force === 'upload-pick' || b.type === 'upload') {
      const file = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp,image/gif', class: 'sr-only', id: 'studio-upload', onchange: (e) => handleUpload(e.target.files[0], e.target) });
      out.push(b.type === 'upload' ? h('div', { class: 'row tight' }, h('div', { class: 'thumb-sm' }, wallpaperView({ base: b }, { thumb: true })), h('span', { class: 'small' }, b.label || 'My image')) : null,
        h('label', { class: 'btn btn-primary btn-sm', for: 'studio-upload', tabindex: 0, onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); file.click(); } } }, icEl('upload'), b.type === 'upload' ? 'Replace image' : 'Choose an image'), file,
        h('p', { class: 'small dim', style: { margin: 0 } }, 'PNG, JPG, WebP or GIF up to 6 MB. Images are resized on your device, stored privately on your account, and only become public if you share a theme that uses them. Only upload artwork you own or have rights to.'));
    } else if (b.type === 'wp') {
      const wp = WP_BY_ID[b.id];
      out.push(h('div', { class: 'row tight' }, h('div', { class: 'thumb-sm' }, wallpaperView({ base: b }, { thumb: true })), h('div', { class: 'stack', style: { gap: '2px' } }, h('b', null, wp?.title || 'Wallpaper'), h('span', { class: 'small muted' }, AESTHETIC_BY_ID[wp?.aesthetic]?.name || ''))),
        h('button', { class: 'btn btn-primary btn-sm', onclick: () => openWallpaperPicker({ onPick: (cfg) => { comp.base = normalizeComposition(cfg).base; if (cfg.adjust) { comp = normalizeComposition({ ...cfg }); syncAll(); } changed(); drawBase(); } }) }, icEl('image'), 'Choose from library'));
    } else if (b.type === 'gen') {
      const labels = PAL_LABELS[b.scene] || PAL_LABELS.mesh;
      out.push(selectField('Scene', SCENES.map((s) => [s, SCENE_LABELS[s] || s]), b.scene, (v) => { const tpl = genTemplate(v); b.scene = v; if (tpl) { b.palette = [...tpl.gen.palette]; b.opts = { ...b.opts, ...tpl.gen.opts }; } changed(); drawBase(); }),
        h('div', { class: 'color-grid' }, ...b.palette.map((c, i) => (b.scene === 'bsod' && i > 2 ? null : colorField(labels[i], c, (v) => { b.palette[i] = v; changed(); })))),
        h('div', { class: 'row tight' },
          h('button', { class: 'btn btn-cyan btn-sm', onclick: () => { b.seed = Math.floor(Math.random() * 1e6); changed(); } }, icEl('dice'), 'Shuffle layout'),
          h('button', { class: 'btn btn-ghost btn-sm', onclick: () => { const a = AESTHETICS[Math.floor(Math.random() * AESTHETICS.length)]; b.palette = b.palette.map((c) => mix(c, a.palette[Math.floor(Math.random() * 5)], 0.5)); changed(); drawBase(); } }, icEl('palette'), 'Remix colours')),
        toggleField('Stars', null, b.opts.stars, (v) => { b.opts.stars = v; changed(); }),
        toggleField('Sun / moon', null, b.opts.sun, (v) => { b.opts.sun = v; changed(); }),
        selectField('Dream object', SCENE_OBJECTS.map((o) => [o, o === 'none' ? 'None' : o[0].toUpperCase() + o.slice(1)]), b.opts.object || 'none', (v) => { b.opts.object = v; changed(); }),
        h('p', { class: 'small dim', style: { margin: 0 } }, 'Scenes are vector art drawn in your browser, so exports stay crisp at any resolution.'));
    }
    baseBox.replaceChildren(modeSeg, ...out.filter(Boolean));
  }
  async function handleUpload(file, input) {
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) { toast('That file is over 12 MB. Please pick a smaller image.', { type: 'err' }); return; }
    const dismiss = toast('Uploading image…', { type: 'info', timeout: 30000 });
    try {
      const blob = await downscale(file, 2560);
      if (blob.size > 6 * 1024 * 1024) throw new Error('Even after resizing the image is over 6 MB. Try a smaller file.');
      const r = await api('POST', '/uploads', blob);
      comp.base = { type: 'upload', url: r.url, label: file.name.slice(0, 40) };
      dismiss(); toast('Image uploaded.', { title: 'Upload complete' });
      changed(); drawBase();
    } catch (e) { dismiss(); toastError(e, 'Upload failed'); }
    input.value = '';
  }

  // ---------- adjust / overlays / caption ----------
  const adj = [['brightness', 'Brightness', 30, 170, '%'], ['contrast', 'Contrast', 30, 170, '%'], ['saturation', 'Saturation', 0, 200, '%'], ['hue', 'Hue shift', -180, 180, '°'], ['blur', 'Blur', 0, 20, '']]
    .map(([k, l, min, max, unit]) => [k, rangeField(l, { min, max, value: comp.adjust[k], unit, onInput: (v) => { comp.adjust[k] = v; changed(); } })]);
  const ovs = [['grain', 'Film grain'], ['scanlines', 'Scanlines'], ['chroma', 'Chromatic aberration'], ['vhs', 'VHS tracking'], ['vignette', 'Vignette']]
    .map(([k, l]) => [k, rangeField(l, { value: comp.overlays[k], unit: '%', onInput: (v) => { comp.overlays[k] = v; changed(); } })]);
  const tintC = colorField('Tint colour', comp.overlays.tint, (v) => { comp.overlays.tint = v; changed(); });
  const tintA = rangeField('Tint amount', { value: comp.overlays.tintAmount, unit: '%', onInput: (v) => { comp.overlays.tintAmount = v; changed(); } });
  const capText = textField('Caption', { value: comp.caption.text, maxlength: 80, placeholder: 'e.g. “you have 1 new memory”', onInput: (v) => { comp.caption.text = v; changed(); } });
  const capStyle = selectField('Caption style', CAPTION_STYLES.map((s) => [s, CAPTION_LABELS[s]]), comp.caption.style, (v) => { comp.caption.style = v; changed(); });
  const capPos = segField('Position', CAPTION_POS.map((p) => [p, p[0].toUpperCase() + p.slice(1)]), comp.caption.pos, (v) => { comp.caption.pos = v; changed(); });
  function syncAll() {
    adj.forEach(([k, f]) => f.set(comp.adjust[k])); ovs.forEach(([k, f]) => f.set(comp.overlays[k]));
    tintC.set(comp.overlays.tint); tintA.set(comp.overlays.tintAmount);
    capText.input.value = comp.caption.text; capStyle.set(comp.caption.style); capPos.set(comp.caption.pos);
    drawBase();
  }

  // ---------- actions ----------
  const undoBtn = h('button', { class: 'btn btn-ghost btn-sm', disabled: true, onclick: () => {
    if (pendingSnap) { history.push(pendingSnap); pendingSnap = null; clearTimeout(snapTimer); }
    const prev = history.pop(); if (!prev) return;
    comp = normalizeComposition(JSON.parse(prev)); lastState = structuredClone(comp);
    undoBtn.disabled = !history.length; syncAll(); drawStage();
  } }, icEl('undo'), 'Undo');
  const resetFx = () => { comp = normalizeComposition({ base: comp.base }); changed(); syncAll(); toast('Adjustments and overlays reset.', { type: 'info', timeout: 1800 }); };
  const randomFx = () => {
    const mood = MOODS[Math.floor(Math.random() * MOODS.length)];
    comp = normalizeComposition({ ...comp, ...MOOD_FX[mood], caption: comp.caption });
    changed(); syncAll(); toast(`Applied a random “${mood}” mood.`, { type: 'info', timeout: 1800 });
  };
  const save = async (asNew = false) => {
    const name = await promptDialog({ title: editing && !asNew ? 'Save creation' : 'Save as new creation', label: 'Name', value: editing && !asNew ? editing.name : `${baseInfo(comp.base).title} remix`, okText: 'Save', maxLength: 60, icon: 'save' });
    if (!name) return;
    try {
      if (editing && !asNew) editing = await updateCreation(editing.id, { name, config: comp });
      else { editing = await createCreation(name, comp); replaceQuery({ creation: editing.id }); }
      dirty = false; ctx.setTitle(`${editing.name} — Wallpaper Studio`); drawHead();
      toast(`“${editing.name}” saved to My Digital World → Creations.`, { title: 'Saved', action: { label: 'View', onClick: () => navigate('/world/creations') } });
    } catch (e) { toastError(e, "Couldn't save"); }
  };
  const head = h('div', { class: 'studio-head' });
  const drawHead = () => swap(head, 
    h('div', null, h('p', { class: 'eyebrow' }, editing ? 'Editing creation' : 'New composition'), h('h2', { class: 'h2', style: { margin: 0 } }, editing ? editing.name : 'Compose a wallpaper')),
    h('span', { class: 'spacer' }), undoBtn,
    h('button', { class: 'btn btn-ghost btn-sm', onclick: randomFx }, icEl('shuffle'), 'Random mood'),
    h('button', { class: 'btn btn-ghost btn-sm', onclick: resetFx }, icEl('refresh'), 'Reset effects'),
    editing ? h('button', { class: 'btn btn-ghost btn-sm', onclick: () => save(true) }, icEl('copy'), 'Save as new') : null,
    h('button', { class: 'btn btn-green btn-sm', onclick: () => save(false) }, icEl('save'), 'Save'),
    h('button', { class: 'btn btn-primary btn-sm', 'aria-haspopup': 'menu', onclick: (e) => downloadMenu(e.currentTarget, comp, editing?.name || 'retro-wallpaper') }, icEl('download'), 'Export'));
  drawHead();

  const group = (title, icon, kids, open = false) => h('details', { class: 'xp-group', open }, h('summary', null, icEl(icon), title), h('div', { class: 'xg-body' }, kids));
  const deviceSeg = segField(null, [['desktop', 'Desktop', 'monitor'], ['mobile', 'Phone', 'phone'], ['tablet', 'Tablet', 'tablet']], size, (v) => { size = v; drawStage(); });

  root.append(studioTabs('compose'), head,
    h('div', { class: 'studio' },
      h('div', { class: 'studio-left' }, h('div', { class: 'row' }, deviceSeg, h('span', { class: 'spacer' }), h('span', { class: 'small dim hide-sm' }, 'Live preview · exports render at full resolution')), stage,
        h('div', { class: 'row tight studio-more' },
          h('button', { class: 'btn btn-ghost btn-sm', onclick: () => { setSetting('desktopOverride', structuredClone(comp)); toast('Set as your RETRO.EXE desktop background.', { action: { label: 'Undo', onClick: () => setSetting('desktopOverride', null) } }); } }, icEl('monitor'), 'Set as app desktop'),
          h('button', { class: 'btn btn-ghost btn-sm', onclick: async () => { if (!editing) { toast('Save your creation first, then you can build a theme around it.', { type: 'info' }); await save(false); if (!editing) return; } navigate('/world', { fromCreation: editing.id }); } }, icEl('layers'), 'Use in new theme'))),
      h('aside', { class: 'studio-panel', 'aria-label': 'Composition controls' },
        group('Wallpaper source', 'image', baseBox, true),
        group('Adjustments', 'sliders', adj.map(([, f]) => f), true),
        group('Overlays', 'layers', [...ovs.map(([, f]) => f), h('div', { class: 'color-grid' }, tintC), tintA]),
        group('Caption', 'type', [capText, capStyle, capPos]))));
  drawBase(); drawStage();

  const beforeUnload = (e) => { if (dirty) { e.preventDefault(); e.returnValue = ''; } };
  addEventListener('beforeunload', beforeUnload);
  ctx.onCleanup(() => removeEventListener('beforeunload', beforeUnload));
}

/** Resize large images client-side before upload (keeps GIFs as-is). */
async function downscale(file, max) {
  if (file.type === 'image/gif') return file;
  const bmp = await createImageBitmap(file).catch(() => { throw new Error("That file doesn't look like an image we can read."); });
  const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
  if (s === 1 && file.size < 3 * 1024 * 1024) return file;
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('Could not process image'))), file.type === 'image/png' ? 'image/png' : 'image/jpeg', 0.9));
}

// ---------------- Dream Generator ----------------
async function dreamTab(root, ctx) {
  ctx.setTitle('Dream Generator — Wallpaper Studio');
  const aiBox = h('section', { class: 'panel ai-box' }, loadingBox('Checking the dream machine...'));
  root.append(studioTabs('dream'),
    h('header', { class: 'page-head' }, h('div', null, h('p', { class: 'eyebrow' }, 'Dream Generator'), h('h2', { class: 'h1' }, 'Generate something you almost remember.'),
      h('p', { class: 'muted' }, 'Describe a scene for the AI generator, or let the procedural dream machine invent original scenes from any aesthetic — free and unlimited.'))),
    aiBox, proceduralBox(ctx));
  loadAi(aiBox, ctx);
}

async function loadAi(box, ctx) {
  let status;
  try { status = await get('/ai/status'); } catch (e) { box.replaceChildren(errorBox(e, () => loadAi(box, ctx))); return; }
  if (!ctx.isActive()) return;
  if (!status.enabled) {
    box.replaceChildren(h('div', { class: 'ai-off' },
      h('div', { class: 'dialog-msg' }, h('span', { class: 'dm-ic', style: { color: '#ffd166' }, html: ic('info') }),
        h('div', null, h('h3', { class: 'h3', style: { marginTop: 0 } }, 'AI image generation isn’t switched on for this server'),
          h('p', null, 'RETRO.EXE can generate wallpapers with an AI image model, but that needs an API key that only the server owner can provide. Keys are never sent to your browser.'),
          h('p', { class: 'small muted' }, 'Server owner: set ', h('code', null, 'OPENAI_API_KEY'), ' (and optionally ', h('code', null, 'OPENAI_IMAGE_MODEL'), ', ', h('code', null, 'AI_DAILY_LIMIT'), ') in the environment and restart. Each account then gets a daily allowance.'),
          h('p', { style: { marginBottom: 0 } }, h('b', null, 'In the meantime, the procedural Dream Machine below works offline and has no limits.'))))));
    return;
  }
  const left = () => Math.max(0, status.limit - status.used);
  const prompt = textField('Describe your wallpaper', { multiline: true, maxlength: 400, placeholder: 'e.g. an empty shopping mall at night, pastel neon signs, soft fog, 2003 digital camera' });
  const styleChips = h('div', { class: 'chips' }, ...AESTHETICS.map((a) => h('button', { type: 'button', class: 'chip', onclick: () => { const t = prompt.input; t.value = `${t.value.trim()}${t.value.trim() ? ', ' : ''}${a.name.toLowerCase()} aesthetic`.slice(0, 400); t.focus(); } }, `+ ${a.name}`)));
  const meter = h('div', { class: 'small muted' });
  const result = h('div', { class: 'ai-result' });
  const drawMeter = () => { meter.textContent = isGuest() ? `Requires a free account · ${status.limit} images per day` : `${left()} of ${status.limit} generations left today`; };
  const go = h('button', { class: 'btn btn-primary btn-lg', onclick: () => {
    if (!requireAccount('Create a free account to use AI generation. Each account gets a daily allowance.')) return;
    const text = prompt.input.value.trim();
    if (text.length < 4) { toast('Describe your wallpaper in a few more words.', { type: 'err' }); prompt.input.focus(); return; }
    if (!left()) { toast('You’ve used today’s AI generations. They reset at midnight (server time). The procedural Dream Machine is unlimited!', { type: 'err', title: 'Daily limit reached' }); return; }
    withBusy(go, async () => {
      result.replaceChildren(h('div', { class: 'ai-wait' }, hourglass(), h('div', null, h('b', null, 'Dreaming…'), h('div', { class: 'small muted' }, 'This usually takes 10–60 seconds.')), h('div', { class: 'xp-progress' })));
      try {
        const r = await post('/ai/generate', { prompt: text });
        status.used = r.used; drawMeter();
        const comp = { base: { type: 'upload', url: r.url, label: text.slice(0, 40) } };
        result.replaceChildren(h('div', { class: 'ai-out' }, h('div', { class: 'ai-img' }, wallpaperView(comp, { live: true, eager: true, label: `AI wallpaper: ${text}` })),
          h('div', { class: 'row tight' },
            h('button', { class: 'btn btn-cyan', onclick: () => navigate('/studio', { upload: r.url }) }, icEl('sliders'), 'Open in composer'),
            h('button', { class: 'btn btn-green', onclick: (e) => withBusy(e.currentTarget, async () => { try { await createCreation(text.slice(0, 60), comp); toast('Saved to Creations.'); } catch (err) { toastError(err); } }) }, icEl('save'), 'Save'),
            h('button', { class: 'btn btn-primary', onclick: (e) => downloadMenu(e.currentTarget, comp, 'dream') }, icEl('download'), 'Export'))));
      } catch (e) {
        const msg = { AI_LIMIT: 'You’ve reached today’s AI limit. Try the procedural Dream Machine below.', AI_TIMEOUT: 'The image service took too long. Please try again.', AI_UPSTREAM: e.message, AI_DISABLED: 'AI generation was just switched off on the server.' }[e.code] || e.message;
        result.replaceChildren(h('div', { class: 'notice warn' }, icEl('warning'), h('span', null, msg)));
        if (e.code === 'AI_LIMIT') { status.used = status.limit; drawMeter(); }
      }
    });
  } }, icEl('wand'), 'Generate');
  drawMeter();
  box.replaceChildren(h('div', { class: 'stack' }, h('div', { class: 'row' }, h('h3', { class: 'h3', style: { margin: 0 } }, icEl('wand'), ' AI generator'), h('span', { class: 'spacer' }), meter),
    prompt, h('div', { class: 'field' }, h('span', { class: 'small muted', style: { fontWeight: 700 } }, 'Add a style'), styleChips),
    h('div', { class: 'row' }, go, h('span', { class: 'small dim' }, 'Generated images are saved privately to your account. Please don’t request real people, logos or copyrighted characters.')), result));
}

function proceduralBox(ctx) {
  let aes = '', mood = '';
  const grid = h('div', { class: 'grid g-md dream-grid' });
  const roll = () => {
    const seeds = Array.from({ length: 6 }, () => Math.floor(Math.random() * 1e6));
    grid.replaceChildren(...seeds.map((seed) => {
      const comp = dreamComposition(aes, mood, seed);
      const label = `${SCENE_LABELS[comp.base.scene] || comp.base.scene} #${seed.toString(36).toUpperCase()}`;
      return h('article', { class: 'card dream-card' },
        h('div', { class: 'card-media' }, wallpaperView(comp, { thumb: true })),
        h('div', { class: 'card-body' }, h('span', { class: 'card-title' }, label),
          h('div', { class: 'row tight' },
            h('button', { class: 'btn btn-cyan btn-sm', onclick: () => { sessionStorage.setItem('retro.dream', JSON.stringify(comp)); navigate('/studio', { dream: 1 }); } }, icEl('sliders'), 'Edit'),
            h('button', { class: 'btn btn-green btn-sm', onclick: (e) => withBusy(e.currentTarget, async () => { try { await createCreation(`Dream ${label}`, comp); toast('Saved to Creations.', { action: { label: 'View', onClick: () => navigate('/world/creations') } }); } catch (err) { toastError(err); } }) }, icEl('save'), 'Save'),
            h('button', { class: 'btn btn-ghost btn-sm', 'aria-label': `Export ${label}`, onclick: (e) => downloadMenu(e.currentTarget, comp, `dream-${seed}`) }, icEl('download')))));
    }));
  };
  const box = h('section', { class: 'section' },
    h('div', { class: 'section-head' }, h('h2', { class: 'h2' }, h('span', { class: 'ic', style: { color: 'var(--accent)' }, html: ic('sparkles') }), 'Procedural Dream Machine')),
    h('div', { class: 'panel filters' }, h('div', { class: 'filters-row' },
      h('div', { style: { flex: '1 1 200px' } }, selectField('Aesthetic', [['', 'Surprise me'], ...AESTHETICS.map((a) => [a.id, a.name])], aes, (v) => { aes = v; roll(); })),
      h('div', { style: { flex: '1 1 160px' } }, selectField('Mood', [['', 'Any mood'], ...MOODS.map((m) => [m, m[0].toUpperCase() + m.slice(1)])], mood, (v) => { mood = v; roll(); })),
      h('button', { class: 'btn btn-pink btn-lg', onclick: roll }, icEl('dice'), 'Dream again'))),
    grid);
  roll();
  return box;
}

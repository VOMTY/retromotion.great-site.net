// Public profile: bio, stats, follow, and the user's shared themes.
import { h, timeAgo } from '../core/dom.js';
import { icEl } from '../core/icons.js';
import { get } from '../core/api.js';
import { state, updateProfile } from '../core/store.js';
import { emptyState, errorBox, loadingBox, avatarImg, promptDialog, toast, toastError } from '../core/ui.js';
import { postCard, followButton, sampleBadge } from '../components/community.js';

export async function render(root, ctx) {
  const username = ctx.params.username;
  root.append(loadingBox(`Loading @${username}...`));
  let data;
  try { data = await get(`/users/${encodeURIComponent(username)}`); }
  catch (e) {
    if (!ctx.isActive()) return;
    root.replaceChildren(e.status === 404 ? emptyState({ icon: 'user', title: 'User not found', text: `There’s nobody called @${username} here (guest sessions don’t have public profiles).`, action: h('a', { class: 'btn btn-primary', href: '#/community' }, 'Back to Community') }) : errorBox(e, ctx.rerender));
    return;
  }
  if (!ctx.isActive()) return;
  const { user: u, stats } = data;
  ctx.setTitle(`${u.displayName || u.username} (@${u.username})`);
  const followers = h('b', null, stats.followers);
  const bio = h('p', { class: 'profile-bio' }, u.bio || (u.isMe ? 'Add a short bio so people know your vibe.' : 'No bio yet.'));
  const grid = h('div', { class: 'grid g-md' });
  const loadPosts = async () => {
    grid.replaceChildren(loadingBox('Loading themes...'));
    try {
      const r = await get('/posts', { query: { author: u.username, sort: 'new', limit: 48 } });
      if (!ctx.isActive()) return;
      grid.replaceChildren(...(r.posts.length ? r.posts.map((p) => postCard(p, { onRemoved: loadPosts }))
        : [emptyState({ icon: 'layers', title: u.isMe ? 'You haven’t shared anything yet' : 'No shared themes yet', text: u.isMe ? 'Open My Digital World, pick a theme and choose “Share to community”.' : 'Check back later.', action: u.isMe ? h('a', { class: 'btn btn-primary', href: '#/world' }, 'Open My Digital World') : null })]));
    } catch (e) { grid.replaceChildren(errorBox(e, loadPosts)); }
  };
  root.replaceChildren(
    h('section', { class: 'profile-head panel' },
      avatarImg(u.username, 'xl'),
      h('div', { class: 'stack', style: { gap: '6px', flex: 1, minWidth: '220px' } },
        h('div', { class: 'row tight' }, h('h2', { class: 'h1', style: { margin: 0 } }, u.displayName || u.username), u.isSample ? sampleBadge() : null, u.isMe ? h('span', { class: 'badge badge-ok' }, 'You') : null),
        h('span', { class: 'muted' }, `@${u.username} · joined ${timeAgo(u.createdAt)}`),
        bio,
        u.isSample ? h('p', { class: 'small dim', style: { margin: 0 } }, 'This is a sample account run by the RETRO.EXE team to demonstrate the community.') : null,
        h('div', { class: 'profile-stats' }, h('span', null, h('b', null, stats.posts), ' themes'), h('span', null, followers, ' followers'), h('span', null, h('b', null, stats.following), ' following'), h('span', null, h('b', null, stats.likes), ' likes received'))),
      h('div', { class: 'stack', style: { gap: '8px' } },
        u.isMe ? h('button', { class: 'btn btn-ghost', onclick: async () => {
          const b = await promptDialog({ title: 'Edit bio', label: 'Bio', value: u.bio || '', maxLength: 200, multiline: true, icon: 'edit' });
          if (b === null) return;
          try { await updateProfile({ bio: b }); u.bio = b; bio.textContent = b || 'Add a short bio so people know your vibe.'; toast('Bio updated.'); } catch (e) { toastError(e); }
        } }, icEl('edit'), 'Edit bio') : followButton(u.username, data.following, { onChange: (r) => { followers.textContent = r.followers; } }),
        u.isMe ? h('a', { class: 'btn btn-ghost', href: '#/settings' }, icEl('settings'), 'Account settings') : null)),
    h('section', { class: 'section' }, h('div', { class: 'section-head' }, h('h2', { class: 'h2' }, 'Shared themes')), grid));
  loadPosts();
}

// 404 page, in the style of a classic "page cannot be displayed" error.
import { h } from '../core/dom.js';
import { icEl } from '../core/icons.js';

export async function render(root, ctx) {
  root.append(h('div', { class: 'notfound' },
    h('div', { class: 'nf-ic' }, '?'),
    h('div', { class: 'stack' },
      h('h2', { class: 'h1', style: { margin: 0 } }, 'The page cannot be displayed'),
      h('p', { class: 'muted', style: { margin: 0 } }, `“${ctx.path}” isn’t a place in this digital world. It may have been moved, renamed, or it only existed in a dream.`),
      h('ul', { class: 'steps small' }, h('li', null, 'Check the address for typos.'), h('li', null, 'Use the taskbar or start menu to find your way.')),
      h('div', { class: 'row tight' }, h('a', { class: 'btn btn-primary', href: '#/' }, icEl('home'), 'Go Home'), h('a', { class: 'btn btn-ghost', href: '#/search' }, icEl('search'), 'Search')))));
}

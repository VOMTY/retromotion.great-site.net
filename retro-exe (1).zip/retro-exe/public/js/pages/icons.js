// Icon & Widget Studio: icon packs, styles, widgets, decor, matching sets, ZIP export + device setup guide.
import { h, swap, downloadBlob, slug } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { state, createTheme, addRecent } from '../core/store.js';
import { navigate, replaceQuery } from '../core/router.js';
import { toast, toastError, withBusy, promptDialog } from '../core/ui.js';
import { ICON_PACKS, ICONPACK_BY_ID, AESTHETIC_BY_ID, WALLPAPERS, WP_BY_ID } from '../data/catalog.js';
import { normalizeIcons, normalizeThemeData, CLOCK_STYLES, DATE_STYLES, STICKERS } from '../data/schema.js';
import { GLYPHS, iconImg, iconPNG } from '../lib/iconkit.js';
import { clockSVG, dateSVG, stickerSrc, STICKER_LABELS, stickerSVG } from '../lib/widgets.js';
import { wallpaperView, extractPalette, renderToCanvas, EXPORT_SIZES } from '../lib/render.js';
import { luminance } from '../lib/wallgen.js';
import { makeZip } from '../lib/zip.js';
import { iconControls, openWallpaperPicker } from '../components/pickers.js';
import { segField, toggleField, chipToggles } from '../components/fields.js';
import { themePreview, clockEl, dateEl } from '../components/themeview.js';
import { iconPackCard, favButton, saveButton, sectionHead } from '../components/cards.js';
import { CLOCK_LABELS, DATE_LABELS } from '../components/themeEditor.js';

export async function render(root, ctx) {
  const pack = ICONPACK_BY_ID[ctx.query.pack];
  if (pack) addRecent('iconpack', pack.id);
  const cfg = normalizeIcons(pack ? { ...pack.config, pack: pack.id } : { ...(ICON_PACKS[0].config), pack: ICON_PACKS[0].id });
  const set = {
    wallpaper: { base: { type: 'wp', id: wpFor(pack ? pack.aesthetic : 'windowscore') } },
    widgets: { clock: 'xp', h24: false, date: 'pill', showDate: true },
    stickers: ['sparkle', 'star'],
  };
  const palette = () => [darkOf(cfg), cfg.bg, cfg.accent, cfg.fg, '#ffffff'];
  const data = () => normalizeThemeData({ wallpaper: set.wallpaper, palette: palette(), icons: cfg, widgets: set.widgets, decor: { stickers: set.stickers } });

  // ---------- previews ----------
  const phone = h('div', { class: 'icon-phone' });
  const glyphGrid = h('div', { class: 'glyph-grid', 'aria-label': 'All icons in this set' });
  const widgetRow = h('div', { class: 'widget-gallery' });
  const draw = () => {
    phone.replaceChildren(themePreview(data(), { size: 'mobile', live: true }));
    glyphGrid.replaceChildren(...Object.entries(GLYPHS).map(([g, info]) => h('figure', { class: 'glyph' }, iconImg(g, cfg, { alt: info.label }), h('figcaption', null, info.label))));
    drawWidgets();
    replaceQuery({ pack: cfg.pack });
    swap(packHead, ...packHeader());
  };
  const packHead = h('div', { class: 'row tight pack-head' });
  const packHeader = () => {
    const p = ICONPACK_BY_ID[cfg.pack];
    return p ? [h('b', null, p.name), h('span', { class: 'small muted' }, `· ${AESTHETIC_BY_ID[p.aesthetic]?.name}`), p.tier === 'plus' ? h('span', { class: 'badge badge-plus' }, 'Plus · free in beta') : null, h('span', { class: 'spacer' }), saveButton('iconpack', p.id, p.name), favButton('iconpack', p.id, p.name)]
      : [h('b', null, 'Custom icon style'), h('span', { class: 'small muted' }, '· your own mix')];
  };

  // ---------- controls ----------
  const controls = iconControls(cfg, () => draw());
  const wallRow = h('div', { class: 'row tight' });
  const drawWall = () => wallRow.replaceChildren(h('div', { class: 'thumb-sm' }, wallpaperView(set.wallpaper, { thumb: true })),
    h('div', { class: 'stack', style: { gap: '6px' } },
      h('button', { class: 'btn btn-ghost btn-sm', onclick: () => openWallpaperPicker({ title: 'Background for this set', onPick: (c) => { set.wallpaper = c; drawWall(); draw(); } }) }, icEl('image'), 'Change background'),
      h('button', { class: 'btn btn-cyan btn-sm', onclick: (e) => withBusy(e.currentTarget, async () => {
        try {
          const p = await extractPalette(set.wallpaper);
          const sorted = [...p].sort((a, b) => luminance(a) - luminance(b));
          Object.assign(cfg, { bg: sorted[2], accent: sorted[4], fg: luminance(sorted[2]) > 0.45 ? '#16213e' : '#ffffff', pack: '' });
          controls.sync(); draw(); toast('Icons recoloured to match the background.');
        } catch (err) { toastError(err); }
      }) }, icEl('wand'), 'Match icons to background')));
  drawWall();

  // ---------- widgets ----------
  function drawWidgets() {
    const p = palette();
    widgetRow.replaceChildren(
      h('div', { class: 'wg-col' }, h('span', { class: 'small muted' }, 'Clock styles'), h('div', { class: 'wg-options' }, ...CLOCK_STYLES.map((s) => h('button', { class: 'wg-opt', 'aria-pressed': String(set.widgets.clock === s), 'aria-label': `${CLOCK_LABELS[s]} clock`, onclick: () => { set.widgets.clock = s; draw(); } }, h('span', { class: 'wg-svg', html: clockSVG(s, { h24: set.widgets.h24, palette: p }) }), h('span', { class: 'small' }, CLOCK_LABELS[s]))))),
      h('div', { class: 'wg-col' }, h('span', { class: 'small muted' }, 'Date widgets'), h('div', { class: 'wg-options' }, ...DATE_STYLES.map((s) => h('button', { class: 'wg-opt', 'aria-pressed': String(set.widgets.date === s), 'aria-label': `${DATE_LABELS[s]} date widget`, onclick: () => { set.widgets.date = s; set.widgets.showDate = true; draw(); } }, h('span', { class: 'wg-svg', html: dateSVG(s, { palette: p }) }), h('span', { class: 'small' }, DATE_LABELS[s]))))));
  }
  const h24 = toggleField('24-hour clock', null, false, (v) => { set.widgets.h24 = v; draw(); });
  const showDate = toggleField('Show date widget', null, true, (v) => { set.widgets.showDate = v; draw(); });
  const stickers = chipToggles(STICKERS.map((s) => [s, STICKER_LABELS[s], h('span', { class: 'chip-stk', html: stickerSVG(s, palette()) })]), set.stickers, (v) => { set.stickers = v; draw(); }, { max: 6 });

  // ---------- save & export ----------
  const incWall = toggleField('Include wallpaper', 'Desktop + phone PNGs (adds ~5 MB)', true, () => {});
  const doExport = (btn) => withBusy(btn, async () => {
    const name = ICONPACK_BY_ID[cfg.pack]?.name || 'Custom Icons';
    const dismiss = toast('Packing your set… this can take a few seconds.', { type: 'info', timeout: 60000 });
    try {
      const files = [];
      for (const g of Object.keys(GLYPHS)) files.push({ name: `icons/${g}.png`, data: await iconPNG(g, cfg, 512) });
      for (const s of set.stickers) files.push({ name: `stickers/${s}.png`, data: await svgToPng(stickerSrc(s, palette()), 512) });
      if (incWall.querySelector('input').checked) {
        for (const k of ['desktop', 'mobile']) { const { w, h: hh } = EXPORT_SIZES[k]; const c = await renderToCanvas(set.wallpaper, w, hh); files.push({ name: `wallpaper-${k}.png`, data: await new Promise((r) => c.toBlob(r, 'image/png')) }); }
      }
      files.push({ name: 'README.txt', data: readme(name, cfg, set, palette()) });
      downloadBlob(await makeZip(files), `${slug(name)}-retro-set.zip`);
      dismiss(); toast(`${files.length} files exported. See README.txt for device setup.`, { title: 'Set exported' });
    } catch (e) { dismiss(); toastError(e, 'Export failed'); }
  });
  const saveTheme = async (btn) => {
    const nm = await promptDialog({ title: 'Save as theme', label: 'Theme name', value: `${ICONPACK_BY_ID[cfg.pack]?.name || 'Custom'} Set`, okText: 'Save theme', icon: 'layers' });
    if (!nm) return;
    withBusy(btn, async () => {
      try { const t = await createTheme({ name: nm, description: 'Made in the Icon & Widget Studio.', folder: 'Icon sets', data: data() }); toast(`“${t.name}” saved to My Digital World.`, { action: { label: 'Open', onClick: () => navigate('/world', { theme: t.id }) } }); }
      catch (e) { toastError(e); }
    });
  };

  const group = (title, icon, kids, open = false) => h('details', { class: 'xp-group', open }, h('summary', null, icEl(icon), title), h('div', { class: 'xg-body' }, kids));
  root.append(
    h('header', { class: 'page-head' }, h('div', null, h('p', { class: 'eyebrow' }, 'Icon & Widget Studio'), h('h2', { class: 'h1' }, 'Icons that match your wallpaper.'),
      h('p', { class: 'muted' }, 'Pick a pack or design your own style, add clocks, dates and stickers, then save it as a theme or export everything for your phone or PC.'))),
    h('div', { class: 'notice' }, icEl('info'), h('span', null, h('b', null, 'What applies where: '), 'saving & applying a theme changes RETRO.EXE instantly (desktop, icons, clock, stickers). Your real phone or computer can’t be changed from a website — export the set and follow the ', h('a', { href: '#guide' , onclick: (e) => { e.preventDefault(); root.querySelector('#guide')?.scrollIntoView({ behavior: 'smooth' }); } }, 'device setup guide'), ' below.')),
    h('div', { class: 'icon-studio' },
      h('aside', { class: 'studio-panel', 'aria-label': 'Icon controls' },
        group('Icon style', 'apps', controls, true),
        group('Matching background', 'image', wallRow, true),
        group('Widgets', 'clock', [h24, showDate, h('p', { class: 'small dim', style: { margin: 0 } }, 'Choose clock & date styles in the gallery on the right.')]),
        group('Stickers & decor', 'sparkles', [h('span', { class: 'small muted' }, 'Up to 6 stickers'), stickers]),
        h('div', { class: 'stack export-box panel' }, incWall,
          h('button', { class: 'btn btn-primary', onclick: (e) => doExport(e.currentTarget) }, icEl('download'), 'Export set (.zip)'),
          h('button', { class: 'btn btn-green', onclick: (e) => saveTheme(e.currentTarget) }, icEl('layers'), 'Save as theme'))),
      h('div', { class: 'icon-preview stack' }, packHead,
        h('div', { class: 'icon-preview-grid' }, phone, h('div', { class: 'stack' }, glyphGrid, widgetRow))),
    ),
    h('section', { class: 'section' }, sectionHead('Icon packs', 'star'), h('div', { class: 'grid g-md' }, ...ICON_PACKS.map(iconPackCard))),
    guide());
  draw();
}

function wpFor(aes) { return (WP_BY_ID[`img-${aes}`] || WALLPAPERS.find((w) => w.aesthetic === aes) || WALLPAPERS[0]).id; }
function darkOf(cfg) { return luminance(cfg.bg) < 0.05 ? cfg.bg : '#0b1030'; }

async function svgToPng(src, size) {
  const img = new Image(); img.src = src; await img.decode();
  const c = document.createElement('canvas'); c.width = c.height = size;
  c.getContext('2d').drawImage(img, 0, 0, size, size);
  return new Promise((r, j) => c.toBlob((b) => (b ? r(b) : j(new Error('Sticker export failed'))), 'image/png'));
}

function readme(name, cfg, set, pal) {
  return `RETRO.EXE — ${name}
==========================================
Icons:     icons/*.png (512×512)
Stickers:  stickers/*.png
Wallpaper: wallpaper-desktop.png / wallpaper-mobile.png (if included)

Colours
  Icon background  ${cfg.bg}
  Icon symbol      ${cfg.fg}
  Accent           ${cfg.accent}
  Palette          ${pal.join('  ')}
Widgets: ${set.widgets.clock} clock${set.widgets.h24 ? ' (24h)' : ''}, ${set.widgets.showDate ? set.widgets.date + ' date' : 'no date'}

SETTING UP YOUR DEVICE
iPhone / iPad
  1. Set the wallpaper: Photos > wallpaper-mobile.png > Share > Use as Wallpaper.
  2. Icons: open Shortcuts > + > Add Action > "Open App" > choose the app.
     Tap the share/info button > Add to Home Screen > tap the icon > Choose Photo > pick one of the PNGs.
  3. Widgets: use a widget app (e.g. Widgetsmith or Color Widgets) and enter the hex colours above.
Android
  1. Long-press the home screen > Wallpapers > choose wallpaper-mobile.png.
  2. Icons: install a launcher that supports custom icons (e.g. Nova or Lawnchair),
     long-press an app > Edit > tap the icon > choose the PNG.
  3. Widgets: KWGT lets you recreate the clock & date with the colours above.
Windows
  1. Right-click wallpaper-desktop.png > Set as desktop background.
  2. For .ico icons, a one-click theme installer and a browser theme: save this set as a theme in
     RETRO.EXE, open My Digital World and choose "Use on my PC / browser".
macOS
  1. System Settings > Wallpaper > Add Photo.
  2. Open a PNG in Preview > Cmd+A, Cmd+C. Select an app/folder > Get Info > click the small icon > Cmd+V.

Artwork is original to RETRO.EXE — free for personal use, please don't resell.
`;
}

function guide() {
  const item = (title, icon, steps) => h('details', { class: 'xp-group' }, h('summary', null, icEl(icon), title), h('div', { class: 'xg-body' }, h('ol', { class: 'steps' }, ...steps.map((s) => h('li', null, s)))));
  return h('section', { class: 'section', id: 'guide' }, sectionHead('Device setup guide', 'info'),
    h('div', { class: 'guide-grid' },
      h('div', { class: 'panel stack' }, h('h3', { class: 'h3', style: { margin: 0 } }, icEl('check'), ' Works instantly inside RETRO.EXE'),
        h('ul', { class: 'steps' }, h('li', null, 'Applying a theme in My Digital World changes this app’s desktop wallpaper, accent colours, taskbar & start-menu icons, the home clock and stickers.'), h('li', null, 'Wallpapers can be set as the app desktop straight from any preview.'), h('li', null, 'Everything is saved to your library on the server.'))),
      h('div', { class: 'stack' },
        item('iPhone & iPad', 'phone', ['Export the set and save the PNGs to Photos or Files.', 'Wallpaper: Photos → choose wallpaper-mobile.png → Share → Use as Wallpaper.', 'Icons: Shortcuts app → + → Add Action → Open App → pick the app → Add to Home Screen → tap the icon → Choose Photo.', 'Widgets: use a widget app such as Widgetsmith or Color Widgets with the hex colours from README.txt.']),
        item('Android', 'phone', ['Wallpaper: long-press your home screen → Wallpapers → choose wallpaper-mobile.png.', 'Icons: use a launcher with custom icons (Nova, Lawnchair…) → long-press app → Edit → tap the icon → pick the PNG.', 'Widgets: KWGT can recreate the clock & date using the README colours.']),
        item('Windows & your browser', 'monitor', ['Easiest: save this set as a theme, open it in My Digital World and choose “Use on my PC / browser”. You get a one-click Windows installer (wallpaper, accent colour, dark mode), a Chrome/Edge/Firefox theme, ready-made .ico icons and a desktop clock.', 'Manual: right-click wallpaper-desktop.png → Set as desktop background.', 'Icons from this ZIP are PNGs; the PC pack includes real .ico files for shortcuts and folders.']),
        item('macOS', 'monitor', ['System Settings → Wallpaper → Add Photo.', 'Open an icon PNG in Preview → Select All → Copy. Select an app or folder → Get Info → click the small icon → Paste.']))));
}

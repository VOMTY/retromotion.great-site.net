// Home: the living desktop dashboard.
import { h } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { get } from '../core/api.js';
import { state, activeTheme, isGuest, clearRecent } from '../core/store.js';
import { navigate } from '../core/router.js';
import { emptyState, errorBox, toastError } from '../core/ui.js';
import { AESTHETICS, WALLPAPERS, COLLECTION_BY_ID, FEATURED_COLLECTIONS, ICON_PACKS } from '../data/catalog.js';
import { iconImg } from '../lib/iconkit.js';
import { logoEl } from '../lib/effects.js';
import { collectionCard, sectionHead } from '../components/cards.js';
import { openCollectionPreview } from '../components/preview.js';
import { itemTile } from '../components/items.js';
import { postCard } from '../components/community.js';
import { themePreview, clockEl, dateEl } from '../components/themeview.js';
import { openAuthModal } from '../components/auth.js';
import { surprise } from '../main.js';

const SUGGEST = ['pool rooms', 'chrome', 'green hills', 'ps2', 'sunset grid', 'eerie', 'pastel', 'bubbles'];
const DEFAULT_ICONS = { style: 'aero', shape: 'squircle', bg: '#2f6cf5', fg: '#ffffff', accent: '#7ee0ff' };

function greeting() {
  const hr = new Date().getHours();
  return hr < 5 ? 'Still up' : hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening';
}

function typeLine(el, text) {
  if (!state.settings.motion) { el.textContent = text; return () => {}; }
  let i = 0; el.textContent = '';
  const t = setInterval(() => { el.textContent = text.slice(0, ++i); if (i >= text.length) clearInterval(t); }, 45);
  return () => clearInterval(t);
}

export async function render(root, ctx) {
  const icons = () => activeTheme()?.data?.icons || DEFAULT_ICONS;
  const pal = () => activeTheme()?.data?.palette || ['#0b1030', '#1b2a6b', '#3d8bff', '#ff8ad8', '#eaf2ff'];
  const name = isGuest() ? 'traveller' : (state.user.displayName || state.user.username);

  // --- hero ---
  const typed = h('span', { class: 'typed' });
  ctx.onCleanup(typeLine(typed, 'WELCOME BACK TO YOUR DIGITAL WORLD.'));
  const q = h('input', { class: 'input', type: 'search', name: 'q', placeholder: 'Search aesthetics, wallpapers, themes…', 'aria-label': 'Search aesthetics, wallpapers and themes', autocomplete: 'off' });
  const search = h('form', { class: 'search big', role: 'search', onsubmit: (e) => { e.preventDefault(); navigate('/search', { q: q.value.trim() }); } },
    h('span', { class: 'search-ic', html: ic('search') }), q, h('button', { class: 'btn btn-primary', type: 'submit' }, 'Search'));
  const hero = h('section', { class: 'home-hero' },
    h('div', { class: 'hero-main' },
      logoEl(true),
      h('p', { class: 'hero-welcome', 'aria-label': 'Welcome back to your digital world.' }, h('span', { 'aria-hidden': 'true' }, typed, h('span', { class: 'caret' }, '█'))),
      h('p', { class: 'muted hero-sub' }, `${greeting()}, ${name}. Wallpapers, icons, widgets and whole themes from the internet you remember.`),
      search,
      h('div', { class: 'chips', 'aria-label': 'Popular searches' }, h('span', { class: 'small dim' }, 'Try:'), ...SUGGEST.map((s) => h('a', { class: 'chip', href: `#/search?q=${encodeURIComponent(s)}` }, s)))),
    h('div', { class: 'hero-side' }, sysWidget(ctx, pal)));

  // --- quick launch ---
  const quick = h('section', { class: 'quick-grid', 'aria-label': 'Quick launch' },
    ...[
      ['wallpapers', 'photos', 'Wallpapers', `${WALLPAPERS.length} originals · filter, tweak, export`, '/wallpapers'],
      ['icons', 'star', 'Icons & Widgets', `${ICON_PACKS.length} packs · clocks · stickers`, '/icons'],
      ['themes', 'computer', 'Themes', `${state.themes.length} in your library`, '/world'],
      ['collections', 'folder', 'Collections', `${state.collections.length} of yours · curated sets`, '/world/collections'],
    ].map(([k, g, t, s, href]) => h('a', { class: `quick-card q-${k}`, href: `#${href}` }, h('span', { class: 'qc-icon' }, iconImg(g, icons(), { alt: '' })), h('span', { class: 'qc-text' }, h('b', null, t), h('small', null, s)), h('span', { class: 'qc-arrow', html: ic('arrowRight') }))));

  // --- aesthetics strip ---
  const aes = h('section', { class: 'section' }, sectionHead('Pick an aesthetic', 'compass', h('a', { class: 'link-btn', href: '#/explore' }, 'Open Explorer ', icEl('arrowRight'))),
    h('div', { class: 'aes-strip hscroll' }, ...AESTHETICS.map((a) => h('a', { class: `aes-pill ${a.font}`, href: `#/explore/${a.id}`, style: { '--a0': a.palette[0], '--a1': a.palette[1], '--a2': a.palette[2] } }, h('span', { class: 'ap-dot' }), a.name))));

  // --- featured collections ---
  const featured = h('section', { class: 'section' }, sectionHead('Featured collections', 'star'),
    h('div', { class: 'hscroll cards-row' }, ...FEATURED_COLLECTIONS.map((id) => COLLECTION_BY_ID[id]).filter(Boolean).map((c) => collectionCard(c, { onOpen: openCollectionPreview }))));

  // --- recently viewed ---
  const recentBody = h('div');
  const drawRecent = () => {
    const tiles = state.recent.map((r) => itemTile(r)).filter(Boolean);
    recentBody.replaceChildren(tiles.length ? h('div', { class: 'hscroll cards-row small-cards' }, ...tiles)
      : emptyState({ icon: 'clock', title: 'Nothing here yet', text: 'Wallpapers, collections, aesthetics and posts you open will appear here so you can jump back in.', action: h('a', { class: 'btn btn-cyan', href: '#/explore' }, icEl('compass'), 'Start exploring') }));
    clearBtn.hidden = !state.recent.length;
  };
  const clearBtn = h('button', { class: 'link-btn', onclick: () => clearRecent().catch(toastError) }, icEl('trash'), 'Clear');
  const recent = h('section', { class: 'section' }, sectionHead('Recently viewed', 'clock', clearBtn), recentBody);
  drawRecent();
  ctx.subscribe('recent', drawRecent);

  // --- trending ---
  const trendBody = h('div', { class: 'grid g-md' }, ...Array.from({ length: 3 }, () => h('div', { class: 'card skeleton', style: { aspectRatio: '4/3.4' } })));
  const trending = h('section', { class: 'section' }, sectionHead('Trending in the community', 'sparkles', h('a', { class: 'link-btn', href: '#/community' }, 'See all ', icEl('arrowRight'))), trendBody);
  const loadTrending = async () => {
    try {
      const r = await get('/posts', { query: { sort: 'trending', limit: 6, samples: state.settings.hideSamples ? '0' : undefined } });
      if (!ctx.isActive()) return;
      trendBody.replaceChildren(...(r.posts.length ? r.posts.map((p) => postCard(p, { onRemoved: loadTrending })) : [emptyState({ icon: 'users', title: 'The community is quiet', text: 'Be the first to share a theme from My Digital World.' })]));
    } catch (e) { if (ctx.isActive()) trendBody.replaceChildren(errorBox(e, loadTrending)); }
  };
  loadTrending();

  const guestNote = isGuest() ? h('div', { class: 'notice home-guest' }, icEl('info'), h('span', null, 'You’re in a ', h('b', null, 'guest session'), ' — everything you save is kept for this browser. ',
    h('button', { class: 'link-btn inline', onclick: () => openAuthModal('register') }, 'Create a free account'), ' to keep it safe, share themes and follow people.')) : null;

  root.append(hero, guestNote, quick, aes, featured, recent, trending);
  // keep side widget in sync with theme changes
  ctx.subscribe('activeTheme', () => { hero.querySelector('.hero-side').replaceChildren(sysWidget(ctx, pal)); quick.querySelectorAll('.qc-icon').forEach((el, i) => el.replaceChildren(iconImg(['photos', 'star', 'computer', 'folder'][i], icons(), { alt: '' }))); });
}

function sysWidget(ctx, pal) {
  const t = activeTheme();
  const p = pal();
  const w = t?.data?.widgets || { clock: 'xp', h24: false, date: 'pill', showDate: true };
  return h('div', { class: 'sys-widget panel' },
    h('div', { class: 'sw-widgets' }, clockEl(w.clock, w.h24, p), w.showDate ? dateEl(w.date, p) : null),
    h('div', { class: 'sw-theme' },
      h('div', { class: 'small muted' }, 'Active theme'),
      t ? h('a', { class: 'sw-theme-card', href: `#/world?theme=${t.id}` }, themePreview(t.data, { labels: false }), h('b', null, t.name))
        : h('div', { class: 'small' }, 'None applied — ', h('a', { href: '#/world' }, 'choose one in My Digital World'), '.')),
    h('button', { class: 'btn btn-pink btn-lg surprise-btn', onclick: surprise }, icEl('shuffle'), 'Surprise Me'),
    h('p', { class: 'small dim', style: { margin: 0, textAlign: 'center' } }, 'Teleports you to a random aesthetic.'));
}

// Community: searchable feed of shared themes with trending / new / following views.
import { h, debounce } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { get } from '../core/api.js';
import { state, setSetting, isGuest } from '../core/store.js';
import { replaceQuery, navigate } from '../core/router.js';
import { emptyState, errorBox, openMenu } from '../core/ui.js';
import { AESTHETICS, AESTHETIC_BY_ID } from '../data/catalog.js';
import { postCard, openShareDialog, sampleBadge } from '../components/community.js';
import { selectField, segField, toggleField } from '../components/fields.js';
import { openAuthModal } from '../components/auth.js';

const PAGE = 18;

export async function render(root, ctx) {
  const f = { q: ctx.query.q || '', sort: ['trending', 'new', 'following'].includes(ctx.query.sort) ? ctx.query.sort : 'trending', aesthetic: AESTHETIC_BY_ID[ctx.query.aesthetic] ? ctx.query.aesthetic : '' };
  let offset = 0, req = 0;
  const grid = h('div', { class: 'grid g-md' });
  const more = h('button', { class: 'btn btn-ghost', hidden: true, onclick: () => load(true) }, icEl('refresh'), 'Load more');
  const status = h('p', { class: 'small muted', 'aria-live': 'polite', style: { margin: 0 } });

  async function load(append = false) {
    const my = ++req;
    replaceQuery({ q: f.q, sort: f.sort === 'trending' ? '' : f.sort, aesthetic: f.aesthetic });
    if (!append) { offset = 0; grid.replaceChildren(...Array.from({ length: 6 }, () => h('div', { class: 'card skeleton', style: { aspectRatio: '4/3.4' } }))); }
    if (f.sort === 'following' && isGuest()) {
      grid.replaceChildren(emptyState({ icon: 'users', title: 'Follow people to fill this feed', text: 'Create a free account, follow creators you like, and their new themes appear here.', action: h('button', { class: 'btn btn-primary', onclick: () => openAuthModal('register') }, icEl('user'), 'Create account') }));
      more.hidden = true; status.textContent = ''; return;
    }
    more.disabled = true;
    try {
      const r = await get('/posts', { query: { q: f.q, sort: f.sort, aesthetic: f.aesthetic, samples: state.settings.hideSamples ? '0' : undefined, limit: PAGE, offset } });
      if (my !== req || !ctx.isActive()) return;
      const cards = r.posts.map((p) => postCard(p, { onRemoved: () => load() }));
      if (!append) grid.replaceChildren();
      offset += r.posts.length;
      if (!offset) {
        grid.replaceChildren(emptyState(f.sort === 'following'
          ? { icon: 'users', title: 'Nothing from people you follow yet', text: 'Follow creators from their posts or profiles.', action: h('button', { class: 'btn btn-cyan', onclick: () => setSort('trending') }, 'See trending') }
          : { icon: 'search', title: f.q ? `No themes match “${f.q}”` : 'No themes here yet', text: f.q || f.aesthetic ? 'Try another search or aesthetic.' : 'Be the first to share one from My Digital World.' }));
      } else grid.append(...cards);
      more.hidden = !r.hasMore; more.disabled = false;
      status.textContent = offset ? `Showing ${offset} theme${offset === 1 ? '' : 's'}` : '';
    } catch (e) {
      if (my !== req) return;
      if (append) { more.disabled = false; status.textContent = e.message; } else grid.replaceChildren(errorBox(e, () => load()));
    }
  }
  const sortSeg = segField(null, [['trending', 'Trending', 'sparkles'], ['new', 'New', 'clock'], ['following', 'Following', 'users']], f.sort, (v) => { f.sort = v; load(); });
  const setSort = (v) => { f.sort = v; sortSeg.set(v); load(); };
  const shareBtn = h('button', { class: 'btn btn-primary', 'aria-haspopup': 'menu', onclick: (e) => {
    if (isGuest()) { openAuthModal('register', 'Create a free account to share themes with the community.'); return; }
    if (!state.themes.length) { navigate('/world'); return; }
    openMenu(e.currentTarget, [{ heading: 'Share which theme?' }, ...state.themes.slice(0, 15).map((t) => ({ label: t.name, icon: 'layers', onClick: () => openShareDialog(t, { onPosted: () => setSort('new') }) }))]);
  } }, icEl('share'), 'Share a theme');

  root.append(
    h('header', { class: 'page-head' }, h('div', null, h('p', { class: 'eyebrow' }, 'Community'), h('h2', { class: 'h1' }, 'Desktops from other dreamers.'),
      h('p', { class: 'muted' }, 'Browse themes people have shared, like and save your favourites, follow creators, and report anything that breaks the rules.')), shareBtn),
    h('div', { class: 'notice' }, icEl('info'), h('span', null, 'Posts with a ', sampleBadge(), ' badge are example content from the RETRO.EXE team so the community isn’t empty on day one. Everything else is shared by real people.')),
    h('div', { class: 'toolbar' },
      h('div', { class: 'search', style: { flex: '2 1 240px' } }, h('span', { class: 'search-ic', html: ic('search') }), h('input', { class: 'input', type: 'search', value: f.q, placeholder: 'Search titles, tags, creators…', 'aria-label': 'Search community themes', oninput: debounce((e) => { f.q = e.target.value.trim(); load(); }, 250) })),
      sortSeg,
      h('div', { style: { flex: '1 1 170px' } }, selectField('Aesthetic', [['', 'All aesthetics'], ...AESTHETICS.map((a) => [a.id, a.name])], f.aesthetic, (v) => { f.aesthetic = v; load(); })),
      toggleField('Hide sample posts', null, state.settings.hideSamples, (v) => { setSetting('hideSamples', v); load(); })),
    status, grid, h('div', { class: 'row', style: { justifyContent: 'center', marginTop: '16px' } }, more),
    h('details', { class: 'xp-group guidelines' }, h('summary', null, icEl('shield'), 'Community guidelines'),
      h('div', { class: 'xg-body' }, h('ul', { class: 'steps' },
        h('li', null, 'Share only artwork you made or have the right to share.'), h('li', null, 'No hate, harassment, sexual or graphic content.'), h('li', null, 'No spam or advertising.'),
        h('li', null, 'Use “Report” on any post that breaks these rules. Posts with multiple reports are hidden automatically until a moderator reviews them.')))));
  load();
}

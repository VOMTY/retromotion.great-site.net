// Global search: aesthetics, wallpapers, collections, icon packs, your library and community posts.
import { h, debounce } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { get } from '../core/api.js';
import { state } from '../core/store.js';
import { replaceQuery, navigate } from '../core/router.js';
import { emptyState, errorBox } from '../core/ui.js';
import { AESTHETICS, AESTHETIC_BY_ID, WALLPAPERS, COLLECTIONS, ICON_PACKS } from '../data/catalog.js';
import { aestheticCard, wallpaperCard, collectionCard, iconPackCard, creationCard, sectionHead } from '../components/cards.js';
import { openWallpaperPreview, openCollectionPreview } from '../components/preview.js';
import { postCard } from '../components/community.js';
import { themePreview } from '../components/themeview.js';
import { openThemeWindow } from './world.js';

const SUGGEST = ['dreamcore', 'pool', 'chrome', 'hills', 'neon', 'pastel', 'eerie', 'pixel', 'aqua', 'midnight'];

export async function render(root, ctx) {
  let q = ctx.query.q || '', req = 0;
  const results = h('div', { class: 'stack' });
  const input = h('input', { class: 'input', type: 'search', value: q, placeholder: 'Search everything…', 'aria-label': 'Search RETRO.EXE', autocomplete: 'off', oninput: debounce(() => { q = input.value.trim(); run(); }, 220) });
  const run = async () => {
    replaceQuery({ q });
    const my = ++req;
    if (!q) {
      results.replaceChildren(h('div', { class: 'panel stack' }, h('p', { class: 'muted', style: { margin: 0 } }, 'Search across aesthetics, wallpapers, collections, icon packs, your own themes and the community.'),
        h('div', { class: 'chips' }, ...SUGGEST.map((s) => h('button', { class: 'chip', onclick: () => { input.value = s; q = s; run(); } }, s)))));
      return;
    }
    const n = q.toLowerCase();
    const has = (...parts) => parts.join(' ').toLowerCase().includes(n);
    const aes = AESTHETICS.filter((a) => has(a.name, a.tagline, a.description, a.keywords.join(' ')));
    const aesIds = new Set(aes.map((a) => a.id));
    const wps = WALLPAPERS.filter((w) => has(w.title, w.mood, w.colors.join(' '), AESTHETIC_BY_ID[w.aesthetic]?.name) || aesIds.has(w.aesthetic));
    const cols = COLLECTIONS.filter((c) => has(c.title, c.description, AESTHETIC_BY_ID[c.aesthetic]?.name));
    const packs = ICON_PACKS.filter((p) => has(p.name, p.config.style, AESTHETIC_BY_ID[p.aesthetic]?.name));
    const themes = state.themes.filter((t) => has(t.name, t.description, t.folder));
    const creations = state.creations.filter((c) => has(c.name));
    const sec = (title, icon, items, cls = 'g-md') => (items.length ? h('section', { class: 'section' }, sectionHead(`${title} (${items.length})`, icon), h('div', { class: `grid ${cls}` }, ...items)) : null);
    const postsBox = h('div', { class: 'grid g-md' }, h('div', { class: 'card skeleton', style: { aspectRatio: '4/3.4' } }));
    const local = [
      sec('Aesthetics', 'compass', aes.map((a) => aestheticCard(a))),
      sec('Wallpapers', 'image', wps.slice(0, 24).map((w) => wallpaperCard(w, { onOpen: openWallpaperPreview }))),
      sec('Collections', 'folder', cols.map((c) => collectionCard(c, { onOpen: openCollectionPreview }))),
      sec('Icon packs', 'apps', packs.map(iconPackCard)),
      sec('Your themes', 'layers', themes.map((t) => h('article', { class: 'card clickable' }, h('div', { class: 'card-media' }, themePreview(t.data, { labels: false })), h('button', { class: 'stretch', 'aria-label': `Open theme ${t.name}`, onclick: () => openThemeWindow(t) }), h('div', { class: 'card-body' }, h('h3', { class: 'card-title' }, t.name), h('span', { class: 'card-meta' }, 'My theme'))))),
      sec('Your creations', 'sliders', creations.map((c) => creationCard(c, { onOpen: () => navigate('/studio', { creation: c.id }) }))),
    ].filter(Boolean);
    const commSec = h('section', { class: 'section' }, sectionHead('Community themes', 'users', h('a', { class: 'link-btn', href: `#/community?q=${encodeURIComponent(q)}` }, 'Open in Community ', icEl('arrowRight'))), postsBox);
    const summary = h('p', { class: 'small muted', 'aria-live': 'polite', style: { margin: 0 } }, `${aes.length + wps.length + cols.length + packs.length + themes.length + creations.length} results in the library for “${q}”`);
    results.replaceChildren(summary, ...local, commSec);
    try {
      const r = await get('/posts', { query: { q, limit: 9, samples: state.settings.hideSamples ? '0' : undefined } });
      if (my !== req || !ctx.isActive()) return;
      postsBox.replaceChildren(...(r.posts.length ? r.posts.map((p) => postCard(p)) : [h('p', { class: 'dim' }, 'No community themes match.')]));
      if (!local.length && !r.posts.length) results.replaceChildren(emptyState({ icon: 'search', title: `Nothing found for “${q}”`, text: 'Try an aesthetic name, a colour, or a mood like “cozy”.' }));
    } catch (e) { if (my === req) postsBox.replaceChildren(errorBox(e, run)); }
  };
  root.append(
    h('header', { class: 'page-head' }, h('div', null, h('p', { class: 'eyebrow' }, 'Search'), h('h2', { class: 'h1' }, 'Find it on the information superhighway.'))),
    h('form', { class: 'search big', role: 'search', onsubmit: (e) => { e.preventDefault(); q = input.value.trim(); run(); } }, h('span', { class: 'search-ic', html: ic('search') }), input, h('button', { class: 'btn btn-primary', type: 'submit' }, 'Search')),
    results);
  run();
  setTimeout(() => input.focus(), 50);
}

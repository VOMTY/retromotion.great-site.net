// Moderation queue: review reported / hidden posts (mods & admins only).
import { h, timeAgo } from '../core/dom.js';
import { icEl } from '../core/icons.js';
import { get, post } from '../core/api.js';
import { isMod } from '../core/store.js';
import { emptyState, errorBox, loadingBox, toast, toastError, withBusy, confirmDialog } from '../core/ui.js';
import { themePreview } from '../components/themeview.js';
import { authorLine, openPost } from '../components/community.js';
import { segField } from '../components/fields.js';
import { REPORT_REASONS } from '../components/community.js';

const REASON = Object.fromEntries(REPORT_REASONS);

export async function render(root, ctx) {
  if (!isMod()) {
    root.append(emptyState({ icon: 'lock', title: 'Moderators only', text: 'This area is for community moderators. The first registered account becomes the admin, or the server owner can set MOD_USERNAMES.', action: h('a', { class: 'btn btn-primary', href: '#/community' }, 'Back to Community') }));
    return;
  }
  let view = 'open';
  const list = h('div', { class: 'stack' });
  const load = async () => {
    list.replaceChildren(loadingBox('Loading queue...'));
    try {
      const r = await get('/mod/queue', { query: { status: view === 'resolved' ? 'resolved' : undefined } });
      if (!ctx.isActive()) return;
      list.replaceChildren(...(r.items.length ? r.items.map(row) : [emptyState({ icon: 'check', title: view === 'open' ? 'Queue is clear' : 'No resolved reports yet', text: view === 'open' ? 'No open reports or hidden posts. Nice and peaceful.' : 'Resolved reports will be listed here.' })]));
    } catch (e) { list.replaceChildren(errorBox(e, load)); }
  };
  const act = (p, action, btn) => withBusy(btn, async () => {
    if (action === 'remove' && !(await confirmDialog({ title: 'Remove post?', message: `“${p.title}” will be removed from the community permanently (the author can no longer see it publicly).`, okText: 'Remove', danger: true }))) return;
    try { await post(`/mod/posts/${p.id}`, { action }); toast({ dismiss: 'Reports dismissed — post visible.', hide: 'Post hidden.', restore: 'Post restored.', remove: 'Post removed.' }[action]); load(); }
    catch (e) { toastError(e); }
  });
  const row = (it) => {
    const p = it.post;
    return h('article', { class: 'panel mod-row' },
      h('button', { class: 'mod-thumb', 'aria-label': `Open ${p.title}`, onclick: () => openPost(p) }, themePreview(p.theme, { labels: false })),
      h('div', { class: 'stack', style: { gap: '6px', flex: 1, minWidth: '220px' } },
        h('div', { class: 'row tight' }, h('b', null, p.title), h('span', { class: `badge ${p.status === 'visible' ? 'badge-ok' : 'badge-warn'}` }, p.status)),
        authorLine(p.author),
        h('div', { class: 'small' }, it.reports ? `${it.reports} report${it.reports === 1 ? '' : 's'} · ${it.reasons.map((r) => REASON[r] || r).join(', ')}` : 'Hidden without open reports', it.last ? ` · ${timeAgo(it.last)}` : ''),
        it.details ? h('blockquote', { class: 'small mod-details' }, it.details) : null),
      h('div', { class: 'stack mod-actions' },
        view === 'open' ? h('button', { class: 'btn btn-sm btn-green', onclick: (e) => act(p, 'dismiss', e.currentTarget) }, icEl('check'), 'Dismiss & show') : null,
        p.status === 'visible' ? h('button', { class: 'btn btn-sm btn-ghost', onclick: (e) => act(p, 'hide', e.currentTarget) }, icEl('eyeOff'), 'Hide') : h('button', { class: 'btn btn-sm btn-ghost', onclick: (e) => act(p, 'restore', e.currentTarget) }, icEl('eye'), 'Restore'),
        p.status !== 'removed' ? h('button', { class: 'btn btn-sm btn-danger', onclick: (e) => act(p, 'remove', e.currentTarget) }, icEl('trash'), 'Remove') : null));
  };
  root.append(
    h('header', { class: 'page-head' }, h('div', null, h('p', { class: 'eyebrow' }, 'Moderation'), h('h2', { class: 'h1' }, 'Report queue'), h('p', { class: 'muted' }, 'Posts are hidden automatically after 3 open reports. Dismissing makes a post visible again; removing takes it down for good.'))),
    h('div', { class: 'toolbar' }, segField(null, [['open', 'Open', 'flag'], ['resolved', 'Resolved', 'check']], view, (v) => { view = v; load(); }), h('button', { class: 'btn btn-ghost btn-sm', onclick: load }, icEl('refresh'), 'Refresh')),
    list);
  load();
}

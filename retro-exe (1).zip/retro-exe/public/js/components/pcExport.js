// "Use on my PC" dialog: choose what to export, preview browser + Windows colours, download, then follow steps.
import { h, swap, downloadBlob } from '../core/dom.js';
import { icEl } from '../core/icons.js';
import { openModal, toast, toastError } from '../core/ui.js';
import { normalizeThemeData } from '../data/schema.js';
import { wallpaperView } from '../lib/render.js';
import { luminance } from '../lib/wallgen.js';
import { GLYPHS } from '../lib/iconkit.js';
import { buildPcPack, browserColors, installGuide, readable } from '../lib/pcexport.js';
import { toggleField, selectField, segField } from './fields.js';

const ICON_COUNT = Object.keys(GLYPHS).length;

function screenSize() {
  const dpr = window.devicePixelRatio || 1;
  let w = Math.round((screen.width || 1920) * dpr), hh = Math.round((screen.height || 1080) * dpr);
  const max = 7680 * 2160; // keep canvases within browser limits
  if (w * hh > max) { const k = Math.sqrt(max / (w * hh)); w = Math.round(w * k); hh = Math.round(hh * k); }
  return [w - (w % 2), hh - (hh % 2)];
}

function guideView(sections) {
  return h('div', { class: 'pc-guide stack' }, ...sections.map((s, i) => h('details', { class: 'xp-group', open: i === 0 },
    h('summary', null, icEl(s.icon), s.title),
    h('div', { class: 'xg-body stack' }, h('ol', { class: 'steps' }, ...s.steps.map((st) => h('li', null, st))),
      s.manual ? h('p', { class: 'small muted', style: { margin: 0 } }, s.manual) : null,
      s.undo ? h('p', { class: 'small dim', style: { margin: 0 } }, s.undo) : null))));
}

export function openPcExport(theme) {
  const data = normalizeThemeData(theme.data);
  const pal = data.palette;
  const scr = screenSize();
  const st = {
    windows: true, chrome: true, firefox: false, icons: true, clock: false,
    size: 'screen', accent: pal[2], dark: luminance(pal[0]) < 0.2,
  };
  const SIZES = { screen: scr, fhd: [1920, 1080], qhd: [2560, 1440], uhd: [3840, 2160] };

  // ---------- live preview ----------
  const preview = h('div', { class: 'pc-preview stack' });
  function drawPreview() {
    const c = browserColors(pal);
    const browser = h('div', { class: 'pcb', 'aria-label': 'Browser theme preview', role: 'img', style: { '--pcb-frame': c.frame } },
      h('div', { class: 'pcb-frame' },
        h('span', { class: 'pcb-tab active', style: { background: c.toolbar, color: c.toolbarText } }, h('i', { style: { background: c.line } }), 'New Tab'),
        h('span', { class: 'pcb-tab', style: { color: c.frameText } }, h('i', { style: { background: c.frameText } }), 'RETRO.EXE'),
        h('span', { class: 'pcb-win', style: { color: c.frameText } }, '— ▢ ✕')),
      h('div', { class: 'pcb-bar', style: { background: c.toolbar, color: c.toolbarIcon } }, h('span', null, '‹  ›  ⟳'),
        h('span', { class: 'pcb-omni', style: { background: c.omnibox, color: c.omniText } }, 'Search or type a URL')),
      h('div', { class: 'pcb-ntp', style: { background: c.ntpBg } },
        st.chrome ? wallpaperView(data.wallpaper, { thumb: true, className: 'pcb-wall' }) : null,
        h('span', { class: 'pcb-search', style: { background: c.toolbar, color: c.toolbarText } }, 'Search the web')));
    const barBg = st.dark ? '#202020' : '#f3f3f3', barFg = st.dark ? '#ffffff' : '#1b1b1b';
    const win = h('div', { class: 'pcw', role: 'img', 'aria-label': 'Windows desktop preview' },
      wallpaperView(data.wallpaper, { thumb: true, className: 'pcw-wall' }),
      h('div', { class: 'pcw-bar', style: { background: barBg, color: barFg } },
        h('span', { class: 'pcw-start', style: { background: st.accent } }),
        ...[0, 1, 2].map((k) => h('span', { class: `pcw-app ${k === 0 ? 'on' : ''}`, style: { '--acc': st.accent, borderColor: k === 0 ? st.accent : 'transparent' } })),
        h('span', { class: 'pcw-clock' }, new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }))));
    swap(preview,
      h('div', { class: 'small muted', style: { fontWeight: 700 } }, 'Browser'), (st.chrome || st.firefox) ? browser : h('div', { class: 'pc-off small dim' }, 'Browser theme not included'),
      h('div', { class: 'small muted', style: { fontWeight: 700 } }, 'Windows'), st.windows ? win : h('div', { class: 'pc-off small dim' }, 'Windows theme not included'));
  }

  // ---------- options ----------
  const accentRow = h('div', { class: 'pc-swatches', role: 'radiogroup', 'aria-label': 'Windows accent colour' });
  const drawAccent = () => swap(accentRow, ...[...new Set(pal)].map((col) => h('button', {
    type: 'button', role: 'radio', 'aria-checked': String(col === st.accent), 'aria-label': `Accent ${col}`, title: col,
    style: { background: col, color: readable(col, '#ffffff') }, onclick: () => { st.accent = col; drawAccent(); drawPreview(); },
  }, col === st.accent ? icEl('check') : null)));
  drawAccent();
  const winOpts = h('div', { class: 'pc-sub stack' },
    selectField('Wallpaper size', [['screen', `Match this screen (${scr[0]}×${scr[1]})`], ['fhd', 'Full HD 1920×1080'], ['qhd', 'QHD 2560×1440'], ['uhd', '4K 3840×2160']], st.size, (v) => { st.size = v; }),
    h('div', { class: 'field' }, h('span', { class: 'small muted', style: { fontWeight: 700 } }, 'Accent colour'), accentRow),
    segField('Windows mode', [['dark', 'Dark', 'moon'], ['light', 'Light', 'sun']], st.dark ? 'dark' : 'light', (v) => { st.dark = v === 'dark'; drawPreview(); }));
  const sync = () => { winOpts.hidden = !st.windows; drawPreview(); dl.disabled = !(st.windows || st.chrome || st.firefox || st.icons || st.clock); };
  const opt = (key, label, desc) => toggleField(label, desc, st[key], (v) => { st[key] = v; sync(); });

  const optionsView = h('div', { class: 'pc-grid' },
    h('div', { class: 'stack' },
      h('div', { class: 'notice' }, icEl('info'), h('span', null, 'Websites can’t change Windows or your browser directly. Instead, RETRO.EXE builds a small pack of standard theme files that you install once. It takes about 2 minutes and needs no admin rights.')),
      h('div', { class: 'pc-opts panel stack' },
        opt('windows', 'Windows desktop', 'Wallpaper, accent colour and dark/light mode. Applied with one double-click.'), winOpts,
        opt('chrome', 'Chrome & Edge theme', 'Tab bar, toolbar and new-tab wallpaper'),
        opt('firefox', 'Firefox theme', 'Tab bar and toolbar colours (loads as a temporary add-on)'),
        opt('icons', 'Icons (.ico)', `${ICON_COUNT} icons for shortcuts, folders, This PC and Recycle Bin`),
        opt('clock', 'Desktop clock widget', 'A Rainmeter skin in your theme’s colours (needs the free Rainmeter app)'))),
    h('aside', { class: 'stack' }, preview, h('p', { class: 'small dim', style: { margin: 0 } }, 'This is a preview. Exact styling varies a little between browser and Windows versions.')));

  const body = h('div', { class: 'pc-export' }, optionsView);
  const status = h('span', { class: 'small muted pc-status', role: 'status', 'aria-live': 'polite' });
  const dl = h('button', { class: 'btn btn-primary', onclick: () => run() }, icEl('download'), 'Download PC pack (.zip)');
  const cancel = h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancel');
  let busy = false;

  async function run() {
    if (busy) return;
    busy = true; dl.disabled = true; cancel.disabled = true; dl.classList.add('loading');
    try {
      const res = await buildPcPack({ name: theme.name, description: theme.description, data },
        { windows: st.windows, size: SIZES[st.size], accent: st.accent, dark: st.dark, chrome: st.chrome, firefox: st.firefox, icons: st.icons, clock: st.clock },
        (s) => { status.textContent = s; });
      downloadBlob(res.blob, res.filename);
      toast(`${res.filename} downloaded. The install steps are below and in START HERE.txt.`, { title: 'PC pack ready' });
      const sections = installGuide(st, res.info);
      swap(body, h('div', { class: 'stack' },
        h('div', { class: 'notice ok' }, icEl('check'), h('span', null, h('b', null, 'Downloaded! '), `Open ${res.filename} from your Downloads folder and follow these steps. They’re also in START HERE.txt inside the ZIP.`)),
        guideView(sections)));
      swap(m.foot, h('button', { class: 'btn btn-ghost', onclick: () => { swap(body, optionsView); swap(m.foot, status, cancel, dl); status.textContent = ''; } }, icEl('back'), 'Back'),
        h('button', { class: 'btn btn-primary', onclick: () => m.close() }, 'Done'));
    } catch (e) { toastError(e, 'Couldn’t build the PC pack'); status.textContent = ''; }
    finally { busy = false; dl.disabled = false; cancel.disabled = false; dl.classList.remove('loading'); }
  }

  const m = openModal({ title: `Use “${theme.name}” on my PC`, icon: 'monitor', width: 980, body, footer: [status, cancel, dl], beforeClose: () => !busy });
  drawPreview();
  return m;
}

// Accessible form field builders shared by studios and editors.
import { h } from '../core/dom.js';
import { icEl } from '../core/icons.js';

let fid = 0;
const nid = (p) => `${p}-${++fid}`;

export function rangeField(label, { min = 0, max = 100, step = 1, value = 0, unit = '', onInput }) {
  const id = nid('rng');
  const out = h('output', { for: id }, `${value}${unit}`);
  const input = h('input', { type: 'range', id, min, max, step, value, oninput: (e) => { out.textContent = `${e.target.value}${unit}`; onInput(Number(e.target.value)); } });
  const wrap = h('div', { class: 'range' }, h('label', { for: id }, label), out, input);
  wrap.set = (v) => { input.value = v; out.textContent = `${v}${unit}`; };
  return wrap;
}

export function toggleField(label, desc, checked, onChange) {
  const input = h('input', { type: 'checkbox', checked: !!checked, onchange: (e) => onChange(e.target.checked) });
  const el = h('label', { class: 'switch' }, h('span', { class: 'sw-text' }, h('b', null, label), desc ? h('small', null, desc) : null), input, h('span', { class: 'sw', 'aria-hidden': 'true' }));
  el.set = (v) => { input.checked = !!v; };
  return el;
}

export function colorField(label, value, onInput) {
  const id = nid('col');
  const text = h('input', { class: 'input', type: 'text', value, maxlength: 7, 'aria-label': `${label} hex value`, spellcheck: 'false' });
  const picker = h('input', { type: 'color', id, value, 'aria-label': `${label} colour picker` });
  picker.addEventListener('input', () => { text.value = picker.value; onInput(picker.value); });
  text.addEventListener('change', () => { const v = text.value.trim(); if (/^#[0-9a-f]{6}$/i.test(v)) { picker.value = v.toLowerCase(); onInput(v.toLowerCase()); } else text.value = picker.value; });
  const el = h('div', { class: 'field color-row' }, h('label', { for: id, class: 'small muted', style: { fontWeight: 700 } }, label), h('div', { class: 'color-field' }, picker, text));
  el.set = (v) => { picker.value = v; text.value = v; };
  return el;
}

export function selectField(label, options, value, onChange) {
  const id = nid('sel');
  const sel = h('select', { class: 'select', id, onchange: (e) => onChange(e.target.value) },
    ...options.map(([v, l]) => h('option', { value: v, selected: v === value }, l)));
  const el = h('label', { class: 'field', for: id }, label, h('div', { class: 'select-wrap' }, sel));
  el.set = (v) => { sel.value = v; };
  el.select = sel;
  return el;
}

/** Segmented button group: options [[value, label, icon?]] */
export function segField(label, options, value, onChange) {
  const btns = options.map(([v, l, i]) => h('button', { type: 'button', 'aria-pressed': String(v === value), onclick: () => { set(v); onChange(v); } }, i ? icEl(i) : null, l));
  const set = (v) => btns.forEach((b, k) => b.setAttribute('aria-pressed', String(options[k][0] === v)));
  const el = h('div', { class: 'field' }, label ? h('span', { class: 'small muted', style: { fontWeight: 700 } }, label) : null, h('div', { class: 'seg', role: 'group', 'aria-label': label || 'Options' }, ...btns));
  el.set = set;
  return el;
}

export function textField(label, { value = '', placeholder = '', maxlength = 60, multiline = false, onInput, list, hint } = {}) {
  const id = nid('txt');
  const input = multiline ? h('textarea', { class: 'textarea', id, maxlength, placeholder }, value) : h('input', { class: 'input', id, value, maxlength, placeholder, list });
  if (onInput) input.addEventListener('input', () => onInput(input.value));
  const el = h('label', { class: 'field', for: id }, h('span', null, label, hint ? h('span', { class: 'field-hint' }, ` — ${hint}`) : null), input);
  el.input = input;
  return el;
}

export function chipToggles(options, selected, onChange, { max = 99 } = {}) {
  const set = new Set(selected);
  const wrap = h('div', { class: 'chips' });
  const draw = () => {
    wrap.replaceChildren(...options.map(([v, l, extra]) => h('button', {
      type: 'button', class: 'chip', 'aria-pressed': String(set.has(v)),
      onclick: () => { if (set.has(v)) set.delete(v); else { if (set.size >= max) return; set.add(v); } draw(); onChange([...set]); },
    }, extra || null, l)));
  };
  draw();
  wrap.set = (vals) => { set.clear(); vals.forEach((v) => set.add(v)); draw(); };
  return wrap;
}

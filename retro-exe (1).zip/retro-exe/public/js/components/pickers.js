// Wallpaper picker window (library + my creations) and icon configuration controls.
import { h, debounce } from '../core/dom.js';
import { icEl } from '../core/icons.js';
import { openModal, emptyState } from '../core/ui.js';
import { state } from '../core/store.js';
import { WALLPAPERS, AESTHETICS, ICON_PACKS, AESTHETIC_BY_ID } from '../data/catalog.js';
import { ICON_STYLES, ICON_SHAPES } from '../data/schema.js';
import { wallpaperView } from '../lib/render.js';
import { iconImg } from '../lib/iconkit.js';
import { colorField, selectField, segField } from './fields.js';

export function openWallpaperPicker({ title = 'Choose a wallpaper', onPick }) {
  let tab = 'library', aes = '', q = '';
  const grid = h('div', { class: 'grid g-sm picker-grid' });
  const pickCard = (label, cfg, sub) => h('button', { class: 'card clickable pick-card', onclick: () => { onPick(cfg, label); m.close(); } },
    h('div', { class: 'card-media' }, wallpaperView(cfg, { thumb: true })), h('div', { class: 'card-body' }, h('span', { class: 'card-title' }, label), h('span', { class: 'card-meta' }, sub)));
  const draw = () => {
    if (tab === 'library') {
      const list = WALLPAPERS.filter((w) => (!aes || w.aesthetic === aes) && (!q || `${w.title} ${w.aesthetic} ${w.mood} ${w.colors.join(' ')}`.toLowerCase().includes(q)));
      grid.replaceChildren(...(list.length ? list.map((w) => pickCard(w.title, { base: { type: 'wp', id: w.id } }, AESTHETIC_BY_ID[w.aesthetic]?.name)) : [emptyState({ icon: 'search', title: 'No wallpapers match', text: 'Try another search or aesthetic.' })]));
    } else {
      const list = state.creations.filter((c) => !q || c.name.toLowerCase().includes(q));
      grid.replaceChildren(...(list.length ? list.map((c) => pickCard(c.name, c.config, 'My creation')) : [emptyState({ icon: 'sliders', title: 'No creations yet', text: 'Make one in the Wallpaper Studio and it will show up here.' })]));
    }
  };
  const tabs = h('div', { class: 'tabs', role: 'tablist' },
    ...[['library', 'Library'], ['mine', 'My Creations']].map(([v, l]) => h('button', { role: 'tab', 'aria-selected': String(v === tab), onclick: (e) => { tab = v; tabs.querySelectorAll('button').forEach((b) => b.setAttribute('aria-selected', String(b === e.currentTarget))); aesSel.classList.toggle('hidden', v !== 'library'); draw(); } }, l)));
  const aesSel = selectField('Aesthetic', [['', 'All aesthetics'], ...AESTHETICS.map((a) => [a.id, a.name])], '', (v) => { aes = v; draw(); });
  const search = h('input', { class: 'input', type: 'search', placeholder: 'Search wallpapers…', 'aria-label': 'Search wallpapers', oninput: debounce((e) => { q = e.target.value.trim().toLowerCase(); draw(); }, 150) });
  const m = openModal({ title, icon: 'image', width: 900, body: h('div', { class: 'stack' }, tabs, h('div', { class: 'row', style: { alignItems: 'end' } }, h('div', { style: { flex: '1 1 220px' } }, search), h('div', { style: { flex: '0 1 220px' } }, aesSel)), grid) });
  draw();
  return m;
}

export const STYLE_LABELS = { aero: 'Aero Glass', chrome: 'Chrome', pixel: 'Pixel', win98: 'Classic 98', bubble: 'Bubble', neon: 'Neon', outline: 'Outline', sticker: 'Sticker' };
export const SHAPE_LABELS = { squircle: 'Squircle', circle: 'Circle', square: 'Square', hexagon: 'Hexagon', none: 'No shape' };

/** Icon configuration panel. cfg is mutated; onChange called after each edit. */
export function iconControls(cfg, onChange) {
  const fire = () => onChange({ ...cfg });
  const packs = h('div', { class: 'pack-chips' }, ...ICON_PACKS.map((p) => h('button', {
    type: 'button', class: 'pack-chip', 'aria-pressed': String(cfg.pack === p.id), title: `${p.name} (${AESTHETIC_BY_ID[p.aesthetic]?.name})`,
    onclick: () => { Object.assign(cfg, p.config, { pack: p.id }); sync(); fire(); },
  }, iconImg('folder', p.config, { alt: '' }), h('span', null, p.name))));
  const style = selectField('Style', ICON_STYLES.map((s) => [s, STYLE_LABELS[s]]), cfg.style, (v) => { cfg.style = v; cfg.pack = ''; sync(); fire(); });
  const shape = segField('Shape', ICON_SHAPES.map((s) => [s, SHAPE_LABELS[s]]), cfg.shape, (v) => { cfg.shape = v; cfg.pack = ''; sync(); fire(); });
  const bg = colorField('Background', cfg.bg, (v) => { cfg.bg = v; cfg.pack = ''; syncPacks(); fire(); });
  const fg = colorField('Symbol', cfg.fg, (v) => { cfg.fg = v; cfg.pack = ''; syncPacks(); fire(); });
  const ac = colorField('Accent', cfg.accent, (v) => { cfg.accent = v; cfg.pack = ''; syncPacks(); fire(); });
  const syncPacks = () => packs.querySelectorAll('.pack-chip').forEach((b, i) => b.setAttribute('aria-pressed', String(cfg.pack === ICON_PACKS[i].id)));
  const sync = () => { style.set(cfg.style); shape.set(cfg.shape); bg.set(cfg.bg); fg.set(cfg.fg); ac.set(cfg.accent); syncPacks(); };
  const swap = h('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: () => { [cfg.bg, cfg.fg] = [cfg.fg, cfg.bg]; cfg.pack = ''; sync(); fire(); } }, icEl('refresh'), 'Swap colours');
  const el = h('div', { class: 'stack' },
    h('div', { class: 'field' }, h('span', { class: 'small muted', style: { fontWeight: 700 } }, 'Start from a pack'), packs),
    style, shape, h('div', { class: 'color-grid' }, bg, fg, ac), h('div', null, swap));
  el.sync = sync;
  return el;
}

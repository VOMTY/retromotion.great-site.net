// Resolve saved item references ({type, id}) into displayable tiles for Recent, Favorites & Collections.
import { h } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { get } from '../core/api.js';
import { themeById, creationById } from '../core/store.js';
import { navigate } from '../core/router.js';
import { WP_BY_ID, COLLECTION_BY_ID, ICONPACK_BY_ID, AESTHETIC_BY_ID } from '../data/catalog.js';
import { wallpaperView } from '../lib/render.js';
import { iconImg, APP_SET } from '../lib/iconkit.js';
import { themePreview } from './themeview.js';
import { openWallpaperPreview, openCollectionPreview } from './preview.js';
import { openPost } from './community.js';

const postCache = new Map();
const TYPE_LABEL = { wallpaper: 'Wallpaper', collection: 'Collection', iconpack: 'Icon pack', aesthetic: 'Aesthetic', post: 'Community', theme: 'My theme', creation: 'My creation' };

export function resolveItem({ type, id }) {
  switch (type) {
    case 'wallpaper': { const w = WP_BY_ID[id]; return w && { title: w.title, media: () => wallpaperView({ base: { type: 'wp', id } }, { thumb: true }), open: () => openWallpaperPreview(w) }; }
    case 'collection': { const c = COLLECTION_BY_ID[id]; return c && { title: c.title, media: () => h('div', { class: 'mosaic' }, ...c.items.slice(0, 4).map((wid) => wallpaperView({ base: { type: 'wp', id: wid } }, { thumb: true }))), open: () => openCollectionPreview(c) }; }
    case 'iconpack': { const p = ICONPACK_BY_ID[id]; return p && { title: p.name, media: () => h('div', { class: 'pack-grid mini', style: { background: AESTHETIC_BY_ID[p.aesthetic]?.palette[1] } }, ...APP_SET.slice(0, 4).map((g) => iconImg(g, p.config, { alt: '' }))), open: () => navigate('/icons', { pack: id }) }; }
    case 'aesthetic': { const a = AESTHETIC_BY_ID[id]; const cover = WP_BY_ID[`img-${id}`] ? `img-${id}` : Object.values(WP_BY_ID).find((w) => w.aesthetic === id)?.id; return a && { title: a.name, media: () => wallpaperView({ base: { type: 'wp', id: cover } }, { thumb: true }), open: () => navigate(`/explore/${id}`) }; }
    case 'theme': { const t = themeById(id); return t && { title: t.name, media: () => themePreview(t.data, { labels: false }), open: () => navigate('/world', { theme: t.id }) }; }
    case 'creation': { const c = creationById(id); return c && { title: c.name, media: () => wallpaperView(c.config, { thumb: true }), open: () => navigate('/studio', { creation: c.id }) }; }
    case 'post': {
      const cached = postCache.get(id);
      return {
        title: cached?.title || 'Community theme',
        media: () => {
          const box = h('div', { class: 'post-thumb-load' }, h('span', { class: 'ic', html: ic('users') }));
          const fill = (p) => { box.replaceWith(themePreview(p.theme, { labels: false })); };
          if (cached?.theme) queueMicrotask(() => fill(cached));
          else get(`/posts/${id}`).then((r) => { postCache.set(id, r.post); fill(r.post); const t = box.closest('.item-tile')?.querySelector('.it-title'); if (t) t.textContent = r.post.title; })
            .catch(() => { box.classList.add('gone'); box.replaceChildren(h('span', { class: 'small dim' }, 'Unavailable')); });
          return box;
        },
        open: () => openPost(Number(id)),
      };
    }
    default: return null;
  }
}

/** Small tile for an item reference; onRemove adds an × button. Returns null for unknown/deleted items unless keepMissing. */
export function itemTile(ref, { onRemove, keepMissing = false } = {}) {
  const r = resolveItem(ref);
  if (!r && !keepMissing) return null;
  const media = h('div', { class: 'it-media' }, r ? r.media() : h('div', { class: 'post-thumb-load gone' }, h('span', { class: 'small dim' }, 'Deleted')));
  return h('article', { class: 'item-tile card clickable' }, media,
    r ? h('button', { class: 'stretch', 'aria-label': `Open ${TYPE_LABEL[ref.type]}: ${r.title}`, onclick: r.open }) : null,
    onRemove ? h('div', { class: 'card-actions' }, h('button', { class: 'icon-toggle', 'aria-label': 'Remove from this list', title: 'Remove', html: ic('x'), onclick: (e) => { e.stopPropagation(); onRemove(ref); } })) : null,
    h('div', { class: 'card-body' }, h('span', { class: 'card-title it-title' }, r ? r.title : 'Missing item'), h('span', { class: 'card-meta' }, TYPE_LABEL[ref.type] || ref.type)));
}

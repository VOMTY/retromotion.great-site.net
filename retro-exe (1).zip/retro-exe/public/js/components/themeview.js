// Visual theme previews: a mini desktop or phone home screen composed from theme data.
import { h } from '../core/dom.js';
import { wallpaperView } from '../lib/render.js';
import { iconImg, GLYPHS, APP_SET, DOCK_SET } from '../lib/iconkit.js';
import { clockSVG, dateSVG, stickerSVG, timeParts } from '../lib/widgets.js';
import { normalizeThemeData } from '../data/schema.js';

// one global ticker re-renders every live clock on the page (no per-element intervals to leak)
setInterval(() => {
  document.querySelectorAll('[data-clock]').forEach((el) => {
    if (!el.isConnected) return;
    const pal = el.dataset.pal.split(',');
    el.innerHTML = clockSVG(el.dataset.clock, { h24: el.dataset.h24 === '1', palette: pal });
  });
}, 1000);

export function clockEl(style, h24, palette, live = true) {
  const el = h('div', { class: 'tp-clock', html: clockSVG(style, { h24, palette }) });
  if (live) Object.assign(el.dataset, { clock: style, h24: h24 ? '1' : '0', pal: palette.join(',') });
  return el;
}
export const dateEl = (style, palette) => h('div', { class: `tp-date d-${style}`, html: dateSVG(style, { palette }) });

const DESK_POS = [[84, 66], [62, 14], [92, 44], [48, 74], [36, 12], [72, 80]];
const MOB_POS = [[80, 30], [14, 30], [84, 62], [12, 70], [50, 78], [70, 20]];
const DESK_ICONS = [['computer', 'My Computer'], ['folder', 'Dreams'], ['browser', 'Internet'], ['palette', 'Paint']];

export function themePreview(raw, { size = 'desktop', live = false, labels = true, className = '' } = {}) {
  const t = normalizeThemeData(raw);
  const p = t.palette;
  const root = h('div', { class: `tp tp-${size} ${className}`, style: { '--p0': p[0], '--p1': p[1], '--p2': p[2], '--p3': p[3], '--p4': p[4] } });
  root.append(wallpaperView(t.wallpaper, { size, thumb: !live, live, className: 'tp-wall' }));
  const stickers = h('div', { class: 'tp-stickers', 'aria-hidden': 'true' },
    ...t.decor.stickers.map((s, i) => { const [x, y] = (size === 'mobile' ? MOB_POS : DESK_POS)[i % 6]; return h('span', { class: 'tp-sticker', style: { left: `${x}%`, top: `${y}%`, '--r': `${(i % 2 ? 1 : -1) * (8 + i * 3)}deg` }, html: stickerSVG(s, p) }); }));
  if (size === 'mobile') {
    const tp = timeParts(new Date(), t.widgets.h24);
    root.append(
      h('div', { class: 'tp-status' }, h('span', null, `${tp.hh}:${tp.mm}`), h('span', null, '▂▄▆ ◔')),
      h('div', { class: 'tp-widgets' }, clockEl(t.widgets.clock, t.widgets.h24, p, live), t.widgets.showDate ? dateEl(t.widgets.date, p) : null),
      h('div', { class: 'tp-grid' }, ...APP_SET.slice(4, 14).concat(['star', 'compass']).map((g) => h('div', { class: 'tp-app' }, iconImg(g, t.icons, { alt: '' }), labels ? h('span', null, GLYPHS[g].label) : null))),
      stickers,
      h('div', { class: 'tp-dock' }, ...DOCK_SET.map((g) => iconImg(g, t.icons, { alt: GLYPHS[g].label }))));
  } else {
    root.append(
      h('div', { class: 'tp-desk-icons' }, ...DESK_ICONS.map(([g, l]) => h('div', { class: 'tp-dicon' }, iconImg(g, t.icons, { alt: '' }), labels ? h('span', null, l) : null))),
      h('div', { class: 'tp-widgets' }, clockEl(t.widgets.clock, t.widgets.h24, p, live), t.widgets.showDate ? dateEl(t.widgets.date, p) : null),
      stickers,
      h('div', { class: 'tp-taskbar' }, h('span', { class: 'tp-start' }, 'start'), h('span', { class: 'tp-task' }), h('span', { class: 'tp-tray' })));
  }
  return root;
}

export const paletteStrip = (palette) => h('div', { class: 'swatches' }, ...palette.map((c) => h('span', { style: { background: c }, title: c })));

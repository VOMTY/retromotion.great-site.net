// Community building blocks: post cards, post window, likes, follows, reports, sharing.
import { h, timeAgo } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { get, post as apiPost, del } from '../core/api.js';
import { openModal, toast, toastError, withBusy, confirmDialog, avatarImg, loadingBox, errorBox } from '../core/ui.js';
import { state, isMod, createTheme, addRecent } from '../core/store.js';
import { navigate } from '../core/router.js';
import { AESTHETICS, AESTHETIC_BY_ID, WP_BY_ID } from '../data/catalog.js';
import { themePreview, paletteStrip } from './themeview.js';
import { favButton, saveButton, moreButton } from './cards.js';
import { requireAccount } from './auth.js';
import { textField, selectField, segField } from './fields.js';
import { openPcExport } from './pcExport.js';

const ACCOUNT_MSG = 'Create a free account to like, follow, share and report. Your guest library comes with you.';

export const sampleBadge = () => h('span', { class: 'badge badge-sample', title: 'Example content made by the RETRO.EXE team to show how the community works. Not a real user.' }, 'Sample');

export function authorLine(a, { onNavigate } = {}) {
  return h('a', { class: 'author', href: `#/u/${a.username}`, onclick: (e) => { e.stopPropagation(); onNavigate?.(); } },
    avatarImg(a.username, 'sm'), h('span', { class: 'author-name' }, a.displayName || a.username), h('span', { class: 'dim small' }, `@${a.username}`), a.isSample ? sampleBadge() : null);
}

export function likeButton(p, { onChange } = {}) {
  const b = h('button', { class: 'btn btn-sm btn-ghost like-btn', 'aria-pressed': String(p.liked), 'aria-label': `${p.liked ? 'Unlike' : 'Like'} ${p.title}` });
  const draw = () => { b.innerHTML = `${ic(p.liked ? 'heartFill' : 'heart')}<span>${p.likes}</span>`; b.setAttribute('aria-pressed', String(p.liked)); b.setAttribute('aria-label', `${p.liked ? 'Unlike' : 'Like'} ${p.title} (${p.likes} likes)`); };
  draw();
  b.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!requireAccount(ACCOUNT_MSG)) return;
    const was = p.liked;
    p.liked = !was; p.likes += was ? -1 : 1; draw();
    try { const r = was ? await del(`/posts/${p.id}/like`) : await apiPost(`/posts/${p.id}/like`); p.liked = r.liked; p.likes = r.likes; draw(); onChange?.(p); }
    catch (err) { p.liked = was; p.likes += was ? 1 : -1; draw(); toastError(err, "Couldn't update like"); }
  });
  return b;
}

export function followButton(username, following, { onChange } = {}) {
  let on = following;
  const b = h('button', { class: 'btn btn-sm' });
  const draw = () => { b.className = `btn btn-sm ${on ? 'btn-ghost' : 'btn-cyan'}`; b.replaceChildren(icEl(on ? 'check' : 'plus'), on ? 'Following' : 'Follow'); b.setAttribute('aria-pressed', String(on)); };
  draw();
  b.addEventListener('click', (e) => {
    e.stopPropagation();
    if (!requireAccount(ACCOUNT_MSG)) return;
    withBusy(b, async () => {
      try { const r = on ? await del(`/users/${username}/follow`) : await apiPost(`/users/${username}/follow`); on = r.following; draw(); onChange?.(r); toast(on ? `You're following @${username}.` : `Unfollowed @${username}.`, { type: on ? 'ok' : 'info' }); }
      catch (err) { toastError(err); }
    });
  });
  return b;
}

export const REPORT_REASONS = [['spam', 'Spam or advertising'], ['harassment', 'Harassment or bullying'], ['nsfw', 'Sexual or graphic content'], ['copyright', 'Copyright / not their artwork'], ['hate', 'Hate speech'], ['other', 'Something else']];
export function openReportDialog(p, { onDone } = {}) {
  if (!requireAccount(ACCOUNT_MSG)) return;
  let reason = '';
  const err = h('div', { class: 'form-error', role: 'alert' });
  const details = textField('Details (optional)', { multiline: true, maxlength: 500, placeholder: 'Anything that helps moderators understand the problem' });
  const send = h('button', { class: 'btn btn-danger', onclick: () => {
    if (!reason) { err.textContent = 'Choose a reason first.'; return; }
    withBusy(send, async () => {
      try { const r = await apiPost(`/posts/${p.id}/report`, { reason, details: details.input.value }); p.reported = true; m.close(); toast(r.hidden ? 'Thanks. This post has been hidden pending review.' : 'Thanks. A moderator will review this post.', { title: 'Report sent' }); onDone?.(r); }
      catch (e) { err.textContent = e.message; }
    });
  } }, icEl('flag'), 'Send report');
  const m = openModal({
    title: 'Report post', icon: 'flag', width: 480, className: 'dialog98',
    body: h('div', { class: 'stack' }, h('p', { style: { margin: 0 } }, 'Why are you reporting “', h('b', null, p.title), '”?'),
      h('fieldset', { class: 'radio-list' }, h('legend', { class: 'sr-only' }, 'Reason'),
        ...REPORT_REASONS.map(([v, l]) => h('label', { class: 'radio' }, h('input', { type: 'radio', name: 'reason', value: v, onchange: () => { reason = v; err.textContent = ''; } }), h('span', null, l)))),
      details, err, h('p', { class: 'small dim', style: { margin: 0 } }, 'Reports are anonymous to the poster. Posts with several reports are hidden automatically until reviewed.')),
    footer: [h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancel'), send],
  });
}

export async function saveThemeFromPost(p) {
  const t = await createTheme({ name: p.title.slice(0, 60), description: `${p.description ? p.description + '\n\n' : ''}Saved from @${p.author.username} on the RETRO.EXE community.`.slice(0, 280), folder: 'From the community', data: p.theme });
  toast(`“${t.name}” is now in My Digital World.`, { title: 'Theme saved', action: { label: 'Open', onClick: () => navigate('/world') } });
  return t;
}

export function postMenuItems(p, { onRemoved, close } = {}) {
  const items = [
    { label: 'Save theme to My World', icon: 'download', onClick: () => saveThemeFromPost(p).catch(toastError) },
    { label: 'View profile', icon: 'user', onClick: () => { close?.(); navigate(`/u/${p.author.username}`); } },
  ];
  if (!p.author.isMe) items.push({ sep: true }, { label: p.reported ? 'Reported' : 'Report…', icon: 'flag', disabled: p.reported, onClick: () => openReportDialog(p) });
  if (p.author.isMe || isMod()) items.push({ sep: true }, { label: p.author.isMe ? 'Delete my post' : 'Delete post (moderator)', icon: 'trash', danger: true, onClick: async () => {
    if (!(await confirmDialog({ title: 'Delete post?', message: `“${p.title}” will be removed from the community. Your theme stays in My Digital World.`, okText: 'Delete', danger: true }))) return;
    try { await del(`/posts/${p.id}`); toast('Post deleted.', { type: 'info' }); close?.(); onRemoved?.(p); } catch (e) { toastError(e); }
  } });
  return items;
}

export function postCard(p, { onRemoved } = {}) {
  const a = AESTHETIC_BY_ID[p.aesthetic];
  return h('article', { class: `card clickable post-card ${p.author.isSample ? 'is-sample' : ''}` },
    h('div', { class: 'card-media' }, themePreview(p.theme, { labels: false })),
    h('button', { class: 'stretch', 'aria-label': `Open ${p.title} by ${p.author.displayName}`, onclick: () => openPost(p, { onRemoved }) }),
    h('div', { class: 'card-badges' }, p.status !== 'visible' ? h('span', { class: 'badge badge-warn' }, p.status) : null),
    h('div', { class: 'card-actions' }, saveButton('post', p.id, p.title), moreButton(`More actions for ${p.title}`, () => postMenuItems(p, { onRemoved }))),
    h('div', { class: 'card-body' },
      h('h3', { class: 'card-title' }, p.title),
      h('div', { class: 'row tight', style: { justifyContent: 'space-between' } }, authorLine(p.author), likeButton(p)),
      h('div', { class: 'card-meta' }, a ? h('span', { class: 'dot', style: { width: '8px', height: '8px', borderRadius: '50%', background: a.palette[1] } }) : null, a?.name || 'Mixed', '·', timeAgo(p.createdAt))));
}

export async function openPost(pOrId, { onRemoved } = {}) {
  let p = typeof pOrId === 'object' ? pOrId : null;
  const m = openModal({ title: p ? `${p.title} — Community` : 'Community post', icon: 'users', width: 1000, body: loadingBox('Opening post...') });
  if (!p) {
    try { p = (await get(`/posts/${pOrId}`)).post; m.setTitle(`${p.title} — Community`); }
    catch (e) { m.setBody(errorBox(e, () => { m.close(); openPost(pOrId, { onRemoved }); })); return; }
  }
  addRecent('post', p.id);
  let size = 'desktop';
  const stage = h('div', { class: 'post-stage' });
  const draw = () => stage.replaceChildren(themePreview(p.theme, { size, live: true }));
  const a = AESTHETIC_BY_ID[p.aesthetic];
  m.setBody(h('div', { class: 'post-view' },
    h('div', { class: 'stack' }, segField(null, [['desktop', 'Desktop', 'monitor'], ['mobile', 'Phone', 'phone']], size, (v) => { size = v; draw(); }), stage),
    h('aside', { class: 'stack post-side' },
      p.author.isSample ? h('div', { class: 'notice' }, icEl('info'), h('span', null, 'This is ', h('b', null, 'sample content'), ' created by the RETRO.EXE team to demonstrate the community. Real posts from people have no Sample badge.')) : null,
      p.status !== 'visible' ? h('div', { class: 'notice warn' }, icEl('warning'), `This post is ${p.status} and only visible to you${isMod() ? ' and moderators' : ''}.`) : null,
      h('h3', { class: 'h2', style: { margin: 0 } }, p.title),
      h('div', { class: 'row tight' }, authorLine(p.author, { onNavigate: () => m.close() }), h('span', { class: 'spacer' }), !p.author.isMe ? followButton(p.author.username, p.author.following, { onChange: (r) => { p.author.following = r.following; } }) : null),
      p.description ? h('p', { class: 'post-desc' }, p.description) : null,
      h('div', { class: 'chips' }, a ? h('a', { class: 'chip', href: `#/explore/${a.id}`, onclick: () => m.close() }, h('span', { class: 'dot', style: { background: a.palette[1] } }), a.name) : null,
        ...p.tags.map((t) => h('a', { class: 'tag', href: `#/community?q=${encodeURIComponent(t)}`, onclick: () => m.close() }, `#${t}`))),
      h('div', null, h('div', { class: 'small muted', style: { marginBottom: '4px' } }, 'Palette'), paletteStrip(p.theme.palette)),
      h('div', { class: 'small dim' }, `Posted ${timeAgo(p.createdAt)}`),
      h('div', { class: 'row tight' }, likeButton(p), saveButton('post', p.id, p.title), moreButton('More actions', () => postMenuItems(p, { onRemoved, close: () => m.close() }))),
      h('button', { class: 'btn btn-primary', onclick: (e) => withBusy(e.currentTarget, () => saveThemeFromPost(p).catch(toastError)) }, icEl('download'), 'Save theme to My World'),
      h('button', { class: 'btn btn-cyan', onclick: () => { m.close(); openPcExport({ name: p.title, description: p.description, data: p.theme }); } }, icEl('monitor'), 'Use on my PC / browser'))));
  draw();
}

export function guessAesthetic(themeData) {
  const b = themeData?.wallpaper?.base;
  if (b?.type === 'wp') return WP_BY_ID[b.id]?.aesthetic || '';
  return '';
}

export function openShareDialog(theme, { onPosted } = {}) {
  if (!requireAccount('Create a free account to share themes with the community.')) return;
  const err = h('div', { class: 'form-error', role: 'alert' });
  const title = textField('Title', { value: theme.name, maxlength: 80 });
  const desc = textField('Description', { value: theme.description, maxlength: 500, multiline: true, placeholder: 'Tell people about the vibe' });
  const tags = textField('Tags', { maxlength: 140, placeholder: 'e.g. night, blue, cozy', hint: 'comma separated, up to 6' });
  const aes = selectField('Aesthetic', [['', 'Mixed / other'], ...AESTHETICS.map((x) => [x.id, x.name])], guessAesthetic(theme.data), () => {});
  const rights = h('input', { type: 'checkbox' });
  const pub = h('button', { class: 'btn btn-primary', onclick: () => {
    if (title.input.value.trim().length < 3) { err.textContent = 'Titles need at least 3 characters.'; return; }
    if (!rights.checked) { err.textContent = 'Please confirm the content guidelines.'; return; }
    withBusy(pub, async () => {
      try {
        const r = await apiPost('/posts', { themeId: theme.id, title: title.input.value.trim(), description: desc.input.value, tags: tags.input.value, aesthetic: aes.select.value });
        m.close(); toast(`“${r.post.title}” is live in the community.`, { title: 'Shared!', action: { label: 'View', onClick: () => openPost(r.post) } }); onPosted?.(r.post);
      } catch (e) { err.textContent = e.message; }
    });
  } }, icEl('share'), 'Publish');
  const m = openModal({
    title: 'Share to Community', icon: 'share', width: 760,
    body: h('div', { class: 'share-grid' }, h('div', { class: 'stack' }, themePreview(theme.data, { labels: false }), h('p', { class: 'small dim', style: { margin: 0 } }, 'A snapshot of this theme is published. Later edits to your copy won’t change the post.')),
      h('div', { class: 'stack' }, title, desc, tags, aes,
        h('label', { class: 'check' }, rights, h('span', null, 'I have the right to share this artwork, and it follows the community guidelines (no hate, harassment, explicit content or stolen art).')), err)),
    footer: [h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancel'), pub],
  });
}

// Reusable cards + favourite / save-to-collection controls.
import { h } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { state, isFav, toggleFavorite, addToCollection, removeFromCollection, createCollection, inCollection, subscribe } from '../core/store.js';
import { toast, toastError, openMenu, promptDialog } from '../core/ui.js';
import { AESTHETIC_BY_ID, WP_BY_ID } from '../data/catalog.js';
import { wallpaperView } from '../lib/render.js';
import { iconImg, APP_SET } from '../lib/iconkit.js';
import { navigate } from '../core/router.js';

// one global listener keeps every heart button in sync without per-card subscriptions
subscribe('favorites', () => {
  document.querySelectorAll('[data-fav]').forEach((b) => {
    const [type, ...rest] = b.dataset.fav.split(':');
    const on = isFav(type, rest.join(':'));
    b.setAttribute('aria-pressed', String(on));
    b.innerHTML = ic(on ? 'heartFill' : 'heart');
  });
});

export function favButton(type, id, label = 'item') {
  const on = isFav(type, id);
  const b = h('button', { class: 'icon-toggle', 'data-fav': `${type}:${id}`, 'aria-pressed': String(on), 'aria-label': `Favorite ${label}`, title: 'Favorite', html: ic(on ? 'heartFill' : 'heart') });
  b.addEventListener('click', async (e) => {
    e.stopPropagation();
    try {
      const now = await toggleFavorite(type, String(id));
      b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop');
      toast(now ? `Saved “${label}” to Favorites.` : `Removed “${label}” from Favorites.`, { type: now ? 'ok' : 'info' });
    } catch (err) { toastError(err, "Couldn't update favorites"); }
  });
  return b;
}

export function openSaveMenu(anchor, type, id, label = 'item') {
  const cols = state.collections;
  openMenu(anchor, [
    { heading: 'Save to collection' },
    ...cols.slice(0, 12).map((c) => ({
      label: c.name, icon: 'folder', checked: inCollection(c, type, id),
      onClick: async () => {
        try {
          if (inCollection(c, type, id)) { await removeFromCollection(c.id, type, id); toast(`Removed from “${c.name}”.`, { type: 'info' }); }
          else { await addToCollection(c.id, type, id); toast(`Added “${label}” to “${c.name}”.`, { action: { label: 'View', onClick: () => navigate('/world/collections') } }); }
        } catch (e) { toastError(e); }
      },
    })),
    cols.length ? { sep: true } : null,
    { label: 'New collection…', icon: 'plus', onClick: async () => {
      const name = await promptDialog({ title: 'New Collection', label: 'Collection name', placeholder: 'e.g. Pool rooms for rainy days', okText: 'Create & save', maxLength: 50 });
      if (!name) return;
      try { const c = await createCollection(name); await addToCollection(c.id, type, id); toast(`Created “${name}” and saved “${label}”.`); } catch (e) { toastError(e); }
    } },
  ]);
}
export function saveButton(type, id, label) {
  return h('button', { class: 'icon-toggle', 'aria-label': `Save ${label} to a collection`, title: 'Save to collection', html: ic('bookmark'), 'aria-haspopup': 'menu',
    onclick: (e) => { e.stopPropagation(); openSaveMenu(e.currentTarget, type, id, label); } });
}

const aesName = (id) => AESTHETIC_BY_ID[id]?.name || id;

export function wallpaperCard(wp, { onOpen, size = 'desktop' } = {}) {
  const media = h('div', { class: `card-media ${size === 'mobile' ? 'tall' : ''}` }, wallpaperView({ base: { type: 'wp', id: wp.id } }, { size, thumb: true }));
  return h('article', { class: 'card clickable' },
    media,
    h('button', { class: 'stretch', 'aria-label': `Preview wallpaper ${wp.title}`, onclick: () => onOpen?.(wp) }),
    h('div', { class: 'card-badges' }, wp.tier === 'plus' ? h('span', { class: 'badge badge-plus', title: 'RETRO+ pack — free during beta' }, 'Plus') : null, wp.kind === 'gen' ? h('span', { class: 'badge badge-ghost', title: 'Procedural artwork — renders sharp at any resolution' }, 'Vector') : null),
    h('div', { class: 'card-actions' }, saveButton('wallpaper', wp.id, wp.title), favButton('wallpaper', wp.id, wp.title)),
    h('div', { class: 'card-body' }, h('h3', { class: 'card-title' }, wp.title),
      h('div', { class: 'card-meta' }, h('span', { class: 'dot', style: { width: '8px', height: '8px', borderRadius: '50%', background: AESTHETIC_BY_ID[wp.aesthetic]?.palette[1] } }), aesName(wp.aesthetic), '·', wp.mood)));
}

export function collectionCard(col, { onOpen } = {}) {
  const ids = col.items.slice(0, 4);
  const mosaic = h('div', { class: 'card-media mosaic' }, ...ids.map((id) => wallpaperView({ base: { type: 'wp', id } }, { thumb: true })));
  const a = AESTHETIC_BY_ID[col.aesthetic];
  return h('article', { class: 'card clickable' }, mosaic,
    h('button', { class: 'stretch', 'aria-label': `Open collection ${col.title}`, onclick: () => onOpen?.(col) }),
    h('div', { class: 'card-actions' }, favButton('collection', col.id, col.title)),
    h('div', { class: 'card-body' }, h('h3', { class: 'card-title' }, col.title),
      h('div', { class: 'card-meta' }, `${col.items.length} wallpapers · ${a?.name || ''}`),
      a ? h('div', { class: 'swatches', style: { marginTop: '6px' } }, ...a.palette.map((c) => h('span', { style: { background: c } }))) : null));
}

export function iconPackCard(pack) {
  const grid = h('div', { class: 'card-media pack-grid', style: { background: `linear-gradient(135deg, ${AESTHETIC_BY_ID[pack.aesthetic]?.palette[0]}, ${AESTHETIC_BY_ID[pack.aesthetic]?.palette[1]})` } },
    ...APP_SET.slice(0, 8).map((g) => iconImg(g, pack.config, { alt: '' })));
  return h('article', { class: 'card clickable' }, grid,
    h('button', { class: 'stretch', 'aria-label': `Open icon pack ${pack.name} in the Icon Studio`, onclick: () => navigate('/icons', { pack: pack.id }) }),
    h('div', { class: 'card-badges' }, pack.tier === 'plus' ? h('span', { class: 'badge badge-plus' }, 'Plus') : null),
    h('div', { class: 'card-actions' }, saveButton('iconpack', pack.id, pack.name), favButton('iconpack', pack.id, pack.name)),
    h('div', { class: 'card-body' }, h('h3', { class: 'card-title' }, pack.name), h('div', { class: 'card-meta' }, `Icon pack · ${aesName(pack.aesthetic)} · ${pack.config.style}`)));
}

export function aestheticCard(a, count) {
  const cover = WP_BY_ID[`img-${a.id}`] ? `img-${a.id}` : Object.values(WP_BY_ID).find((w) => w.aesthetic === a.id)?.id;
  return h('article', { class: `card clickable aes-card ${a.font}`, style: { '--a0': a.palette[0], '--a1': a.palette[1], '--a2': a.palette[2], '--a3': a.palette[3] } },
    h('div', { class: 'card-media' }, wallpaperView({ base: { type: 'wp', id: cover } }, { thumb: true }), h('div', { class: 'aes-glow' })),
    h('button', { class: 'stretch', 'aria-label': `Explore ${a.name}`, onclick: () => navigate(`/explore/${a.id}`) }),
    h('div', { class: 'card-actions' }, favButton('aesthetic', a.id, a.name)),
    h('div', { class: 'aes-label' }, h('h3', { class: 'aes-name' }, a.name), h('p', { class: 'aes-tag' }, a.tagline),
      h('div', { class: 'swatches' }, ...a.palette.map((c) => h('span', { style: { background: c } }))),
      count !== undefined ? h('span', { class: 'aes-count' }, `${count} items`) : null));
}

export function creationCard(cr, { onOpen, actions = [] } = {}) {
  return h('article', { class: 'card clickable' },
    h('div', { class: 'card-media' }, wallpaperView(cr.config, { thumb: true })),
    h('button', { class: 'stretch', 'aria-label': `Open creation ${cr.name}`, onclick: () => onOpen?.(cr) }),
    h('div', { class: 'card-badges' }, h('span', { class: 'badge badge-ghost' }, 'My creation')),
    h('div', { class: 'card-actions' }, ...actions),
    h('div', { class: 'card-body' }, h('h3', { class: 'card-title' }, cr.name), h('div', { class: 'card-meta' }, 'Custom composition')));
}

export function moreButton(label, items) {
  return h('button', { class: 'icon-toggle', 'aria-label': label, title: 'More actions', 'aria-haspopup': 'menu', html: ic('more'), onclick: (e) => { e.stopPropagation(); openMenu(e.currentTarget, typeof items === 'function' ? items() : items); } });
}

export function sectionHead(title, iconName, action) {
  return h('div', { class: 'section-head' }, h('h2', { class: 'h2' }, iconName ? h('span', { class: 'ic', style: { color: 'var(--accent)' }, html: ic(iconName) }) : null, title), action || null);
}

export function iconLabel(name, text) { return [icEl(name), h('span', null, text)]; }

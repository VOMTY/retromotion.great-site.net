// Sign up / sign in window. Guests are upgraded in place so their library is kept.
import { h } from '../core/dom.js';
import { icEl } from '../core/icons.js';
import { openModal, toast, withBusy } from '../core/ui.js';
import { state, register, login, isGuest } from '../core/store.js';
import { textField } from './fields.js';

export function requireAccount(reason) {
  if (!isGuest()) return true;
  openAuthModal('register', reason);
  return false;
}

export function openAuthModal(mode = 'register', reason = '') {
  let tab = mode;
  const err = h('div', { class: 'form-error', role: 'alert' });
  const user = textField('Username', { maxlength: 20, placeholder: 'letters, numbers, _', hint: '3–20 characters' });
  const pass = textField('Password', { maxlength: 200, placeholder: 'at least 8 characters' });
  pass.input.type = 'password'; pass.input.autocomplete = 'new-password';
  user.input.autocomplete = 'username'; user.input.autocapitalize = 'off'; user.input.spellcheck = false;
  const disp = textField('Display name', { maxlength: 40, placeholder: 'optional', hint: 'shown on your profile' });
  const note = h('p', { class: 'small muted', style: { margin: 0 } });
  const tabs = h('div', { class: 'tabs', role: 'tablist' }, ...[['register', 'Create account'], ['login', 'Sign in']].map(([v, l]) =>
    h('button', { role: 'tab', 'aria-selected': String(v === tab), onclick: () => { tab = v; sync(); } }, l)));
  const submit = h('button', { class: 'btn btn-primary', type: 'submit' });
  const sync = () => {
    tabs.querySelectorAll('button').forEach((b, i) => b.setAttribute('aria-selected', String(['register', 'login'][i] === tab)));
    disp.classList.toggle('hidden', tab !== 'register');
    pass.input.autocomplete = tab === 'register' ? 'new-password' : 'current-password';
    submit.replaceChildren(icEl(tab === 'register' ? 'user' : 'login'), tab === 'register' ? 'Create free account' : 'Sign in');
    note.textContent = tab === 'register'
      ? 'Everything you saved as a guest — themes, favourites, collections and creations — comes with you.'
      : 'Anything you created as a guest in this session will be merged into your account.';
    err.textContent = '';
  };
  const form = h('form', { class: 'stack', novalidate: true, onsubmit: (e) => {
    e.preventDefault();
    const u = user.input.value.trim(), p = pass.input.value;
    if (!/^[a-z0-9_]{3,20}$/i.test(u)) { err.textContent = 'Usernames are 3–20 characters: letters, numbers and underscores.'; user.input.focus(); return; }
    if (p.length < 8) { err.textContent = 'Passwords need at least 8 characters.'; pass.input.focus(); return; }
    withBusy(submit, async () => {
      try {
        if (tab === 'register') { await register(u, p, disp.input.value.trim()); toast(`Welcome to RETRO.EXE, @${u}!`, { title: 'Account created' }); }
        else { const r = await login(u, p); toast(r.merged ? `Signed in. ${r.merged} guest item(s) were merged into your account.` : `Welcome back, ${state.user.displayName}!`, { title: 'Signed in' }); }
        m.close();
      } catch (e2) { err.textContent = e2.message; }
    });
  } }, tabs, reason ? h('div', { class: 'notice' }, icEl('lock'), h('span', null, reason)) : null, user, pass, disp, note, err, h('div', { class: 'row' }, h('span', { class: 'spacer' }), submit),
  h('p', { class: 'small dim', style: { margin: 0 } }, 'Passwords are hashed with scrypt on the server. Sessions use a random token stored only in this browser.'));
  const m = openModal({ title: 'Log On to RETRO.EXE', icon: 'user', width: 460, body: form });
  sync();
  setTimeout(() => user.input.focus(), 60);
  return m;
}

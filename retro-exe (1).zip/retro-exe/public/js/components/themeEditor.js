// Theme editor window: name, wallpaper, palette, icons, widgets, decor + live preview.
import { h } from '../core/dom.js';
import { icEl } from '../core/icons.js';
import { openModal, toast, toastError, withBusy, confirmDialog } from '../core/ui.js';
import { state, createTheme, updateTheme, setActiveTheme } from '../core/store.js';
import { normalizeThemeData, CLOCK_STYLES, DATE_STYLES, STICKERS, DEFAULT_PALETTE } from '../data/schema.js';
import { AESTHETICS } from '../data/catalog.js';
import { wallpaperView, extractPalette } from '../lib/render.js';
import { STICKER_LABELS, stickerSVG } from '../lib/widgets.js';
import { luminance, darken } from '../lib/wallgen.js';
import { WALLPAPERS, ICON_PACKS } from '../data/catalog.js';
import { themePreview } from './themeview.js';
import { openWallpaperPicker, iconControls } from './pickers.js';
import { textField, colorField, segField, toggleField, rangeField, chipToggles, selectField } from './fields.js';

export const CLOCK_LABELS = { lcd: 'LCD', xp: 'XP Pill', analog: 'Analog', flip: 'Flip', pixel: 'Pixel' };
export const DATE_LABELS = { pill: 'Glossy pill', calendar98: 'Calendar 98', minimal: 'Minimal', sticky: 'Sticky note' };
const PAL_LABELS = ['Base', 'Surface', 'Accent', 'Highlight', 'Text'];

/** Theme palette [bg, surface, accent, highlight, text] derived from an aesthetic's identity colours. */
export function aestheticPalette(a) {
  const byLum = [...a.palette].sort((x, y) => luminance(x) - luminance(y));
  const bg = luminance(byLum[0]) < 0.06 ? byLum[0] : darken(byLum[0], 0.78);
  return [bg, darken(byLum[1], 0.45), a.palette[0], a.palette[1], '#ffffff'];
}
const AES_WIDGETS = { dreamcore: ['analog', 'sticky'], y2k: ['lcd', 'pill'], windowscore: ['xp', 'calendar98'], retrocore: ['flip', 'minimal'], 'frutiger-aero': ['analog', 'pill'], liminal: ['lcd', 'minimal'], vaporwave: ['flip', 'pill'], cybercore: ['lcd', 'minimal'], weirdcore: ['pixel', 'sticky'], ps2: ['lcd', 'minimal'], 'old-internet': ['pixel', 'calendar98'], pixelcore: ['pixel', 'calendar98'] };
const AES_STICKERS = { dreamcore: ['cloud', 'butterfly', 'flower'], y2k: ['sparkle', 'cd', 'star'], windowscore: ['cursor', 'loading'], retrocore: ['smiley', 'cd'], 'frutiger-aero': ['flower', 'sparkle'], liminal: ['moon'], vaporwave: ['star', 'cd', 'heart'], cybercore: ['eye', 'loading'], weirdcore: ['eye', 'smiley', 'moon'], ps2: ['sparkle', 'cd'], 'old-internet': ['cursor', 'star', 'heart'], pixelcore: ['heart', 'star', 'smiley'] };
/** Complete starter theme for an aesthetic: its wallpaper, palette, icon pack, widgets & stickers. */
export function themeDataFromAesthetic(a, wallpaperId) {
  const wp = wallpaperId || (WALLPAPERS.find((w) => w.id === `img-${a.id}`) || WALLPAPERS.find((w) => w.aesthetic === a.id))?.id;
  const pack = ICON_PACKS.find((p) => p.aesthetic === a.id) || ICON_PACKS[0];
  const [clock, date] = AES_WIDGETS[a.id] || ['xp', 'pill'];
  return normalizeThemeData({ wallpaper: { base: { type: 'wp', id: wp }, overlays: { scanlines: ['liminal', 'cybercore', 'ps2', 'weirdcore'].includes(a.id) ? 25 : 0, grain: ['retrocore', 'liminal', 'weirdcore', 'dreamcore'].includes(a.id) ? 20 : 0 } },
    palette: aestheticPalette(a), icons: { ...pack.config, pack: pack.id }, widgets: { clock, date, showDate: true }, decor: { stickers: AES_STICKERS[a.id] || ['sparkle'] } });
}

export function blankThemeData(base) {
  return normalizeThemeData({ wallpaper: { base: base || { type: 'wp', id: 'img-windowscore' } }, palette: DEFAULT_PALETTE, icons: { pack: 'luna-glass' }, widgets: {}, decor: { stickers: ['sparkle'] } });
}

/** theme: existing theme object or null (create). initial: { name, description, folder, data } */
export function openThemeEditor(theme, initial = {}) {
  const isNew = !theme;
  const draft = {
    name: theme?.name ?? initial.name ?? 'My New Theme', description: theme?.description ?? initial.description ?? '', folder: theme?.folder ?? initial.folder ?? '',
    data: normalizeThemeData(structuredClone(theme?.data ?? initial.data ?? blankThemeData())),
  };
  let dirty = false, size = 'desktop';
  const d = draft.data;
  const previewBox = h('div', { class: 'te-preview' });
  const wallThumb = h('div', { class: 'te-wall-thumb' });
  const drawPreview = () => {
    previewBox.replaceChildren(themePreview(d, { size, live: true }));
    wallThumb.replaceChildren(wallpaperView(d.wallpaper, { thumb: true }));
  };
  const changed = () => { dirty = true; drawPreview(); };

  const folders = [...new Set(state.themes.map((t) => t.folder).filter(Boolean))];
  const nameF = textField('Theme name', { value: draft.name, maxlength: 60, onInput: (v) => { draft.name = v; dirty = true; } });
  const descF = textField('Description', { value: draft.description, maxlength: 280, multiline: true, placeholder: 'What does this theme feel like?', onInput: (v) => { draft.description = v; dirty = true; } });
  const folderF = textField('Folder', { value: draft.folder, maxlength: 30, list: 'te-folders', placeholder: 'e.g. Dreams', hint: 'organise your library', onInput: (v) => { draft.folder = v; dirty = true; } });

  const palFields = d.palette.map((c, i) => colorField(PAL_LABELS[i], c, (v) => { d.palette[i] = v; changed(); }));
  const syncPal = () => palFields.forEach((f, i) => f.set(d.palette[i]));
  const extractBtn = h('button', { type: 'button', class: 'btn btn-cyan btn-sm', onclick: (e) => withBusy(e.currentTarget, async () => {
    try { const pal = await extractPalette(d.wallpaper); d.palette = pal; syncPal(); changed(); toast('Palette extracted from your wallpaper.'); } catch (err) { toastError(err); }
  }) }, icEl('wand'), 'Extract from wallpaper');
  const aesPresets = selectField('Or use an aesthetic palette', [['', 'Choose…'], ...AESTHETICS.map((a) => [a.id, a.name])], '', (v) => {
    const a = AESTHETICS.find((x) => x.id === v); if (!a) return;
    d.palette = aestheticPalette(a);
    syncPal(); changed();
  });

  const iconsPanel = iconControls(d.icons, (cfg) => { Object.assign(d.icons, cfg); changed(); });
  const clockF = segField('Clock', CLOCK_STYLES.map((s) => [s, CLOCK_LABELS[s]]), d.widgets.clock, (v) => { d.widgets.clock = v; changed(); });
  const h24F = toggleField('24-hour time', null, d.widgets.h24, (v) => { d.widgets.h24 = v; changed(); });
  const dateF = segField('Date widget', DATE_STYLES.map((s) => [s, DATE_LABELS[s]]), d.widgets.date, (v) => { d.widgets.date = v; changed(); });
  const showDateF = toggleField('Show date widget', null, d.widgets.showDate, (v) => { d.widgets.showDate = v; changed(); });
  const stickersF = chipToggles(STICKERS.map((s) => [s, STICKER_LABELS[s], h('span', { class: 'chip-stk', html: stickerSVG(s, d.palette) })]), d.decor.stickers, (v) => { d.decor.stickers = v; changed(); }, { max: 6 });

  const ov = d.wallpaper.overlays;
  const wallGroup = h('div', { class: 'stack' },
    h('div', { class: 'row' }, wallThumb, h('div', { class: 'stack', style: { gap: '8px', flex: 1 } },
      h('button', { type: 'button', class: 'btn btn-primary btn-sm', onclick: () => openWallpaperPicker({ onPick: (cfg) => { d.wallpaper = normalizeThemeData({ wallpaper: cfg }).wallpaper; resetOverlays(); changed(); } }) }, icEl('image'), 'Choose wallpaper'),
      h('span', { class: 'small dim' }, 'Need finer control? Build a composition in the Wallpaper Studio, save it, then pick it under “My Creations”.'))),
    ...['grain', 'scanlines', 'vignette'].map((k) => rangeField(k[0].toUpperCase() + k.slice(1), { value: ov[k], onInput: (v) => { d.wallpaper.overlays[k] = v; changed(); } })),
    textField('Caption text', { value: d.wallpaper.caption.text, maxlength: 80, placeholder: 'optional — e.g. “you were here before”', onInput: (v) => { d.wallpaper.caption.text = v; changed(); } }));
  const overlayRanges = () => wallGroup.querySelectorAll('.range');
  const resetOverlays = () => overlayRanges().forEach((r, i) => r.set(d.wallpaper.overlays[['grain', 'scanlines', 'vignette'][i]]));

  const group = (title, icon, body, open = false) => h('details', { class: 'xp-group', open }, h('summary', null, icEl(icon), title), h('div', { class: 'xg-body' }, body));
  const seg = segField(null, [['desktop', 'Desktop', 'monitor'], ['mobile', 'Phone', 'phone']], size, (v) => { size = v; drawPreview(); });

  const save = async (apply) => {
    if (!draft.name.trim()) { toast('Give your theme a name first.', { type: 'err' }); nameF.input.focus(); return; }
    const payload = { name: draft.name.trim(), description: draft.description, folder: draft.folder.trim(), data: d };
    const t = isNew ? await createTheme(payload) : await updateTheme(theme.id, payload);
    if (apply) await setActiveTheme(t.id);
    dirty = false;
    toast(apply ? `“${t.name}” saved and applied to RETRO.EXE.` : `“${t.name}” saved to My Digital World.`, { title: isNew ? 'Theme created' : 'Theme updated' });
    m.close();
  };
  const saveBtn = h('button', { class: 'btn btn-primary', onclick: (e) => withBusy(e.currentTarget, () => save(false).catch(toastError)) }, icEl('save'), isNew ? 'Create theme' : 'Save changes');
  const applyBtn = h('button', { class: 'btn btn-green', onclick: (e) => withBusy(e.currentTarget, () => save(true).catch(toastError)) }, icEl('check'), 'Save & apply');

  const m = openModal({
    title: isNew ? 'New Theme — Theme Editor' : `${theme.name} — Theme Editor`, icon: 'layers', width: 1180, closeOnBackdrop: false,
    beforeClose: async () => !dirty || confirmDialog({ title: 'Discard changes?', message: 'You have unsaved changes to this theme.', okText: 'Discard', danger: true }),
    body: h('div', { class: 'theme-editor' },
      h('datalist', { id: 'te-folders' }, ...folders.map((f) => h('option', { value: f }))),
      h('div', { class: 'te-form' },
        group('Details', 'edit', [nameF, descF, folderF], true),
        group('Wallpaper', 'image', wallGroup, true),
        group('Colour palette', 'palette', [h('div', { class: 'color-grid' }, ...palFields), h('div', { class: 'row' }, extractBtn), aesPresets]),
        group('Icons', 'apps', iconsPanel),
        group('Widgets', 'clock', [clockF, h24F, dateF, showDateF]),
        group('Decorations', 'sparkles', [h('span', { class: 'small muted' }, 'Pick up to 6 stickers to scatter across your desktop.'), stickersF])),
      h('div', { class: 'te-side' }, h('div', { class: 'row' }, h('b', null, 'Live preview'), h('span', { class: 'spacer' }), seg), previewBox,
        h('p', { class: 'small dim' }, 'Applying a theme changes the RETRO.EXE desktop wallpaper, accent colours, home-screen icons, clock and stickers. Use the Icon Studio export to set things up on your own device.'))),
    footer: [h('button', { class: 'btn btn-ghost', onclick: () => m.requestClose() }, 'Cancel'), saveBtn, applyBtn],
  });
  drawPreview();
  return m;
}

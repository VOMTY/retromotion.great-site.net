// Wallpaper preview window (desktop / phone / tablet), collection window, device frames.
import { h, slug } from '../core/dom.js';
import { ic, icEl } from '../core/icons.js';
import { openModal, openMenu, toast, toastError } from '../core/ui.js';
import { state, addRecent, setSetting } from '../core/store.js';
import { navigate } from '../core/router.js';
import { wallpaperView, exportComposition, EXPORT_SIZES } from '../lib/render.js';
import { AESTHETIC_BY_ID, COLLECTION_BY_ID, WP_BY_ID } from '../data/catalog.js';
import { favButton, saveButton, wallpaperCard } from './cards.js';
import { timeParts } from '../lib/widgets.js';

export function deviceFrame(content, size = 'desktop', { chrome = true } = {}) {
  const t = timeParts(new Date());
  const screen = h('div', { class: 'screen' }, content);
  if (size === 'mobile') { screen.append(h('div', { class: 'notch' })); if (chrome) screen.append(h('div', { class: 'mock-status' }, h('span', null, `${t.hh}:${t.mm}`), h('span', null, '▂▄▆ ◔'))); }
  if (size === 'desktop' && chrome) screen.append(h('div', { class: 'mock-taskbar' }, h('span', { class: 'mt-start' }, 'start'), h('span', { class: 'mt-tray' }, `${t.hh}:${t.mm} ${t.ampm}`)));
  const el = h('div', { class: `device ${size}` }, screen);
  if (size === 'desktop') el.append(h('div', { class: 'stand' }));
  return el;
}

export function enableTilt(el) {
  if (!state.settings.motion || !matchMedia('(hover: hover)').matches) return;
  el.classList.add('tilt');
  el.addEventListener('pointermove', (e) => {
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    el.style.transform = `perspective(900px) rotateY(${x * 6}deg) rotateX(${-y * 6}deg)`;
  });
  el.addEventListener('pointerleave', () => { el.style.transform = ''; });
}

export function downloadMenu(anchor, cfg, name) {
  openMenu(anchor, [{ heading: 'Export PNG' }, ...Object.entries(EXPORT_SIZES).map(([k, s]) => ({
    label: s.label, icon: k.startsWith('mobile') ? 'phone' : k === 'tablet' ? 'tablet' : 'monitor',
    onClick: async () => {
      const dismiss = toast(`Rendering ${s.w}×${s.h}…`, { type: 'info', timeout: 20000 });
      try { await exportComposition(cfg, k, slug(name)); dismiss(); toast('Wallpaper exported. Check your downloads folder.', { title: 'Download ready' }); }
      catch (e) { dismiss(); toastError(e, 'Export failed'); }
    },
  }))]);
}

/** item: catalog wallpaper | { title, config, creationId } */
export function openWallpaperPreview(item) {
  const isCatalog = !!item.kind;
  const cfg = isCatalog ? { base: { type: 'wp', id: item.id } } : item.config;
  const title = item.title || item.name || 'Wallpaper';
  if (isCatalog) addRecent('wallpaper', item.id);
  let size = 'desktop';
  const stage = h('div', { class: 'preview-stage' });
  const render = () => {
    stage.replaceChildren(deviceFrame(wallpaperView(cfg, { size, live: true, eager: true, label: `${title} wallpaper preview` }), size));
    enableTilt(stage.firstChild);
    seg.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.size === size)));
  };
  const seg = h('div', { class: 'seg', role: 'group', 'aria-label': 'Preview device' },
    ...[['desktop', 'monitor', 'Desktop'], ['mobile', 'phone', 'Phone'], ['tablet', 'tablet', 'Tablet']].map(([s, i, l]) =>
      h('button', { 'data-size': s, onclick: () => { size = s; render(); } }, icEl(i), l)));
  const a = AESTHETIC_BY_ID[item.aesthetic];
  const meta = isCatalog ? h('div', { class: 'row tight' },
    a ? h('a', { class: 'chip', href: `#/explore/${a.id}`, onclick: () => m.close(), style: { '--chip-bg': a.palette[1] } }, h('span', { class: 'dot', style: { background: a.palette[1] } }), a.name) : null,
    h('span', { class: 'tag' }, item.mood), ...item.colors.map((c) => h('span', { class: 'tag' }, c)),
    h('span', { class: 'badge badge-ghost' }, item.kind === 'image' ? 'Original artwork' : 'Procedural · any resolution'),
    item.tier === 'plus' ? h('span', { class: 'badge badge-plus' }, 'RETRO+ · free in beta') : null) : null;
  const studioQuery = isCatalog ? { wp: item.id } : item.creationId ? { creation: item.creationId } : {};
  const m = openModal({
    title: `${title} — Preview`, icon: 'image', width: 940,
    body: h('div', { class: 'stack' },
      h('div', { class: 'row' }, seg, h('span', { class: 'spacer' }), h('span', { class: 'small muted' }, 'Move your cursor over the preview to tilt it.')),
      stage,
      h('div', { class: 'row' }, h('div', { class: 'stack', style: { gap: '6px' } }, h('h3', { class: 'h2' }, title), meta),
        h('span', { class: 'spacer' }), isCatalog ? saveButton('wallpaper', item.id, title) : null, isCatalog ? favButton('wallpaper', item.id, title) : null)),
    footer: [
      h('button', { class: 'btn btn-ghost', onclick: () => { setSetting('desktopOverride', cfg); toast('Applied as your RETRO.EXE desktop background.', { title: 'Desktop updated', action: { label: 'Undo', onClick: () => setSetting('desktopOverride', null) } }); } }, icEl('monitor'), 'Set as app desktop'),
      h('button', { class: 'btn btn-ghost', onclick: () => { m.close(); navigate('/world', { newTheme: isCatalog ? item.id : '', fromCreation: item.creationId || '' }); } }, icEl('layers'), 'Use in new theme'),
      h('button', { class: 'btn btn-cyan', onclick: () => { m.close(); navigate('/studio', studioQuery); } }, icEl('sliders'), 'Edit in Studio'),
      h('button', { class: 'btn btn-primary', 'aria-haspopup': 'menu', onclick: (e) => downloadMenu(e.currentTarget, cfg, title) }, icEl('download'), 'Download'),
    ],
  });
  render();
  return m;
}

export function openCollectionPreview(colOrId) {
  const col = typeof colOrId === 'string' ? COLLECTION_BY_ID[colOrId] : colOrId;
  if (!col) return toast('That collection no longer exists.', { type: 'err' });
  addRecent('collection', col.id);
  const a = AESTHETIC_BY_ID[col.aesthetic];
  const m = openModal({
    title: `${col.title} — Collection`, icon: 'folder', width: 980,
    body: h('div', { class: 'stack' },
      h('div', { class: 'row' }, h('div', { class: 'stack', style: { gap: '4px' } }, h('h3', { class: 'h2' }, col.title), h('p', { class: 'muted', style: { margin: 0 } }, col.description)),
        h('span', { class: 'spacer' }), a ? h('a', { class: 'chip', href: `#/explore/${a.id}`, onclick: () => m.close() }, h('span', { class: 'dot', style: { background: a.palette[1] } }), a.name) : null, favButton('collection', col.id, col.title)),
      h('div', { class: 'grid g-sm' }, ...col.items.map((id) => WP_BY_ID[id]).filter(Boolean).map((wp) => wallpaperCard(wp, { onOpen: (w) => { openWallpaperPreview(w); } })))),
  });
}

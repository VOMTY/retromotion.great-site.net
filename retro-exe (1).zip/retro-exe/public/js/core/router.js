// Hash router with lazy-loaded page modules.
const ROUTES = [
  { re: /^\/?$/, page: 'home' },
  { re: /^\/home$/, page: 'home' },
  { re: /^\/explore$/, page: 'explore' },
  { re: /^\/explore\/([a-z0-9-]+)$/, page: 'explore', keys: ['aesthetic'] },
  { re: /^\/wallpapers$/, page: 'wallpapers' },
  { re: /^\/studio$/, page: 'studio' },
  { re: /^\/icons$/, page: 'icons' },
  { re: /^\/world$/, page: 'world' },
  { re: /^\/world\/([a-z]+)$/, page: 'world', keys: ['tab'] },
  { re: /^\/community$/, page: 'community' },
  { re: /^\/u\/([A-Za-z0-9_]{1,20})$/, page: 'profile', keys: ['username'] },
  { re: /^\/settings$/, page: 'settings' },
  { re: /^\/mod$/, page: 'mod' },
  { re: /^\/search$/, page: 'search' },
];

export function parseHash(hash = location.hash) {
  const raw = decodeURIComponent(hash.replace(/^#/, '')) || '/';
  const [path, qs = ''] = raw.split('?');
  const query = Object.fromEntries(new URLSearchParams(qs));
  for (const r of ROUTES) {
    const m = r.re.exec(path);
    if (m) return { page: r.page, path, query, params: Object.fromEntries((r.keys || []).map((k, i) => [k, m[i + 1]])) };
  }
  return { page: 'notfound', path, query, params: {} };
}

export function navigate(path, query) {
  const qs = query ? '?' + new URLSearchParams(Object.entries(query).filter(([, v]) => v !== undefined && v !== null && v !== '')).toString() : '';
  const target = '#' + path + (qs.length > 1 ? qs : '');
  if (location.hash === target) window.dispatchEvent(new HashChangeEvent('hashchange'));
  else location.hash = target;
}

/** Update the query string without re-rendering the page (for filters). */
export function replaceQuery(query) {
  const { path } = parseHash();
  const qs = new URLSearchParams(Object.entries(query).filter(([, v]) => v !== undefined && v !== null && v !== '' && v !== false)).toString();
  history.replaceState(null, '', '#' + path + (qs ? '?' + qs : ''));
}

export const href = (path, query) => '#' + path + (query ? '?' + new URLSearchParams(query).toString() : '');

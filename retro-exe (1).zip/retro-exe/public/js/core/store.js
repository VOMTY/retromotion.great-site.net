// Global state + persistence. Server is the source of truth for library data;
// device-level accessibility settings live in localStorage.
import { api, get, post, patch, del, setToken, getToken, onSessionLost } from './api.js';

const SETTINGS_KEY = 'retro.settings';
const prefersReduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
const finePointer = matchMedia('(pointer: fine)').matches;
const DEFAULT_SETTINGS = {
  motion: !prefersReduced, crt: false, vhs: false, particles: !prefersReduced, trail: finePointer && !prefersReduced,
  cursor: finePointer, boot: true, legible: false, hideSamples: false, desktopOverride: null,
};

export const state = {
  user: null, stats: null, ready: false,
  settings: { ...DEFAULT_SETTINGS, ...readSettings() },
  favorites: new Map(), // key "type:id" -> createdAt
  themes: [], collections: [], creations: [], recent: [],
  activeThemeId: null,
};

function readSettings() { try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}'); } catch { return {}; } }

// ---- pub/sub ----
const subs = new Map();
export function subscribe(topic, fn) {
  if (!subs.has(topic)) subs.set(topic, new Set());
  subs.get(topic).add(fn);
  return () => subs.get(topic)?.delete(fn);
}
export function emit(topic, payload) { subs.get(topic)?.forEach((fn) => { try { fn(payload); } catch (e) { console.error(e); } }); subs.get('*')?.forEach((fn) => fn(topic)); }

// ---- settings ----
export function setSetting(key, value) {
  state.settings[key] = value;
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(state.settings)); } catch {}
  applySettings();
  emit('settings', key);
}
export function applySettings() {
  const s = state.settings, c = document.documentElement.classList;
  c.toggle('motion', !!s.motion);
  c.toggle('fx-crt', !!s.crt);
  c.toggle('fx-vhs', !!s.vhs);
  c.toggle('legible', !!s.legible);
  document.body.classList.toggle('retro-cursor', !!s.cursor && !s.legible);
}

// ---- session ----
async function newGuest() {
  const r = await api('POST', '/auth/guest', {}, { noRetry: true });
  setToken(r.token);
  state.user = r.user;
}
let renewing = null;
onSessionLost(() => (renewing ||= newGuest().then(loadLibrary).finally(() => { renewing = null; })));

export async function initSession() {
  if (getToken()) {
    try { const r = await get('/me', { noRetry: true }); state.user = r.user; state.stats = r.stats; } catch (e) { if (e.status === 401) setToken(null); else throw e; }
  }
  if (!state.user) await newGuest();
  await loadLibrary();
  state.ready = true;
}

export async function loadLibrary() {
  const [me, fav, th, col, cr, rec] = await Promise.all([get('/me'), get('/favorites'), get('/themes'), get('/collections'), get('/creations'), get('/recent')]);
  state.user = me.user; state.stats = me.stats;
  state.favorites = new Map(fav.favorites.map((f) => [`${f.type}:${f.id}`, f.createdAt]));
  state.themes = th.themes; state.collections = col.collections; state.creations = cr.creations; state.recent = rec.recent;
  state.activeThemeId = state.user.prefs?.activeThemeId ?? null;
  if (state.activeThemeId && !state.themes.some((t) => t.id === state.activeThemeId)) state.activeThemeId = null;
  ['user', 'favorites', 'themes', 'collections', 'creations', 'recent', 'activeTheme'].forEach((t) => emit(t));
}

export async function refreshMe() {
  const r = await get('/me'); state.user = r.user; state.stats = r.stats; emit('user');
}

export async function register(username, password, displayName) {
  const r = await post('/auth/register', { username, password, displayName });
  setToken(r.token); await loadLibrary(); return r.user;
}
export async function login(username, password) {
  const r = await post('/auth/login', { username, password });
  setToken(r.token); await loadLibrary(); return r;
}
export async function logout() {
  try { await post('/auth/logout'); } catch {}
  setToken(null); state.user = null;
  await newGuest(); await loadLibrary();
}
export async function updateProfile(fields) { const r = await patch('/me', fields); state.user = r.user; emit('user'); return r.user; }
export async function deleteAccount(password) { await del('/me', { password }); setToken(null); state.user = null; await newGuest(); await loadLibrary(); }

export const isGuest = () => !state.user || state.user.isGuest;
export const isMod = () => ['mod', 'admin'].includes(state.user?.role);

// ---- favorites ----
export const isFav = (type, id) => state.favorites.has(`${type}:${id}`);
export async function toggleFavorite(type, id) {
  const key = `${type}:${id}`, was = state.favorites.has(key);
  was ? state.favorites.delete(key) : state.favorites.set(key, Date.now());
  emit('favorites', { type, id });
  try {
    was ? await del(`/favorites/${type}/${encodeURIComponent(id)}`) : await post('/favorites', { type, id });
    return !was;
  } catch (e) {
    was ? state.favorites.set(key, Date.now()) : state.favorites.delete(key);
    emit('favorites', { type, id });
    throw e;
  }
}
export function favoritesOf(type) { return [...state.favorites.entries()].filter(([k]) => k.startsWith(type + ':')).sort((a, b) => b[1] - a[1]).map(([k]) => k.slice(type.length + 1)); }

// ---- recent ----
export function addRecent(type, id) {
  id = String(id);
  state.recent = [{ type, id, viewedAt: Date.now() }, ...state.recent.filter((r) => !(r.type === type && r.id === id))].slice(0, 12);
  emit('recent');
  post('/recent', { type, id }).catch(() => {});
}
export async function clearRecent() { await del('/recent'); state.recent = []; emit('recent'); }

// ---- themes ----
export async function createTheme(t) { const r = await post('/themes', t); state.themes.unshift(r.theme); emit('themes'); return r.theme; }
export async function updateTheme(id, fields) {
  const r = await patch(`/themes/${id}`, fields);
  state.themes = state.themes.map((t) => (t.id === id ? r.theme : t)).sort((a, b) => b.updatedAt - a.updatedAt);
  emit('themes');
  if (id === state.activeThemeId) emit('activeTheme');
  return r.theme;
}
export async function duplicateTheme(id) { const r = await post(`/themes/${id}/duplicate`); state.themes.unshift(r.theme); emit('themes'); return r.theme; }
export async function deleteTheme(id) {
  await del(`/themes/${id}`);
  state.themes = state.themes.filter((t) => t.id !== id); emit('themes');
  if (state.activeThemeId === id) await setActiveTheme(null);
}
export const themeById = (id) => state.themes.find((t) => t.id === Number(id));
export const activeTheme = () => themeById(state.activeThemeId);
export async function setActiveTheme(id) {
  const prev = state.activeThemeId;
  if (id && state.settings.desktopOverride) setSetting('desktopOverride', null);
  state.activeThemeId = id; emit('activeTheme');
  try { const r = await patch('/me', { prefs: { activeThemeId: id } }); state.user = r.user; }
  catch (e) { state.activeThemeId = prev; emit('activeTheme'); throw e; }
}

// ---- collections ----
export async function createCollection(name, description = '') { const r = await post('/collections', { name, description }); state.collections.unshift(r.collection); emit('collections'); return r.collection; }
export async function renameCollection(id, name, description) { await patch(`/collections/${id}`, { name, description }); const c = state.collections.find((x) => x.id === id); if (c) { c.name = name ?? c.name; if (description !== undefined) c.description = description; } emit('collections'); }
export async function deleteCollection(id) { await del(`/collections/${id}`); state.collections = state.collections.filter((c) => c.id !== id); emit('collections'); }
export async function addToCollection(cid, type, id) {
  const r = await post(`/collections/${cid}/items`, { type, id: String(id) });
  const c = state.collections.find((x) => x.id === cid);
  if (c && r.added) c.items.unshift({ type, id: String(id), addedAt: Date.now() });
  emit('collections');
  return r.added;
}
export async function removeFromCollection(cid, type, id) {
  await del(`/collections/${cid}/items/${type}/${encodeURIComponent(id)}`);
  const c = state.collections.find((x) => x.id === cid);
  if (c) c.items = c.items.filter((i) => !(i.type === type && i.id === String(id)));
  emit('collections');
}
export const inCollection = (c, type, id) => c.items.some((i) => i.type === type && i.id === String(id));

// ---- creations ----
export async function createCreation(name, config) { const r = await post('/creations', { name, config }); state.creations.unshift(r.creation); emit('creations'); return r.creation; }
export async function updateCreation(id, fields) { const r = await patch(`/creations/${id}`, fields); state.creations = state.creations.map((c) => (c.id === id ? r.creation : c)); emit('creations'); return r.creation; }
export async function deleteCreation(id) { await del(`/creations/${id}`); state.creations = state.creations.filter((c) => c.id !== id); emit('creations'); }
export const creationById = (id) => state.creations.find((c) => c.id === Number(id));

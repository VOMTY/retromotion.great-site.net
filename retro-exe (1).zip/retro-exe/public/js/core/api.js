// API client: bearer-token auth, JSON in/out, friendly errors, automatic session renewal.
const TOKEN_KEY = 'retro.token';
let token = null;
try { token = localStorage.getItem(TOKEN_KEY); } catch {}
let renewHandler = null;

export class ApiError extends Error {
  constructor(message, status = 0, code = '') { super(message); this.status = status; this.code = code; }
}

export const getToken = () => token;
export function setToken(t) {
  token = t || null;
  try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch {}
}
export const onSessionLost = (fn) => { renewHandler = fn; };

export async function api(method, path, body, opts = {}) {
  const headers = { Accept: 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (body instanceof Blob) { payload = body; headers['Content-Type'] = body.type; }
  else if (body !== undefined) { payload = JSON.stringify(body); headers['Content-Type'] = 'application/json'; }
  if (opts.query) {
    const q = new URLSearchParams(Object.entries(opts.query).filter(([, v]) => v !== undefined && v !== null && v !== '')).toString();
    if (q) path += (path.includes('?') ? '&' : '?') + q;
    opts = { ...opts, query: undefined };
  }
  let res;
  try {
    res = await fetch(`/api${path}`, { method, headers, body: payload, signal: opts.signal });
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    throw new ApiError("Can't reach the RETRO.EXE server. Check your connection and try again.", 0, 'NETWORK');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && data.code === 'NO_SESSION' && !opts.noRetry && renewHandler) {
      await renewHandler();
      return api(method, path, body, { ...opts, noRetry: true });
    }
    throw new ApiError(data.error || `Request failed (${res.status})`, res.status, data.code);
  }
  return data;
}

export const get = (p, o) => api('GET', p, undefined, o);
export const post = (p, b, o) => api('POST', p, b ?? {}, o);
export const patch = (p, b) => api('PATCH', p, b);
export const del = (p, b) => api('DELETE', p, b);

// UI primitives: toasts, retro modal windows, dialogs, popover menus, states.
import { h, clear, hashStr } from './dom.js';
import { ic, icEl } from './icons.js';

// ---------- toasts (XP balloon tips) ----------
export function toast(message, opts = {}) {
  const { type = 'ok', title, action, timeout = type === 'err' ? 6500 : 3800 } = opts;
  const root = document.getElementById('toasts');
  const icon = type === 'err' ? 'warning' : type === 'info' ? 'info' : 'check';
  const color = type === 'err' ? '#c8341b' : type === 'info' ? '#2f6cf5' : '#2a8a2f';
  const el = h('div', { class: `toast ${type === 'err' ? 'err' : ''}`, role: type === 'err' ? 'alert' : 'status' },
    h('span', { class: 't-ic', style: { color }, html: ic(icon) }),
    h('div', null, title ? h('b', null, title) : null, h('div', null, message),
      action ? h('button', { class: 'btn btn-sm btn-primary t-action', onclick: () => { action.onClick(); dismiss(); } }, action.label) : null),
    h('button', { class: 't-close', 'aria-label': 'Dismiss', onclick: () => dismiss() }, '×'));
  root.append(el);
  while (root.children.length > 4) root.firstChild.remove();
  let t = setTimeout(dismiss, timeout);
  el.addEventListener('mouseenter', () => clearTimeout(t));
  el.addEventListener('mouseleave', () => { t = setTimeout(dismiss, 1800); });
  function dismiss() { clearTimeout(t); el.classList.add('out'); setTimeout(() => el.remove(), 260); }
  return dismiss;
}
export const toastError = (e, title = 'Something went wrong') => toast(e?.message || String(e), { type: 'err', title });

// ---------- modal windows ----------
const openModals = [];
export function openModal({ title, icon = 'info', width = 560, body, footer, onClose, className = '', closeOnBackdrop = true, beforeClose }) {
  const root = document.getElementById('modal-root');
  const prevFocus = document.activeElement;
  const titleId = `m-${Math.random().toString(36).slice(2, 8)}`;
  const bodyEl = h('div', { class: 'modal-body' });
  const footEl = h('div', { class: 'modal-foot' });
  const win = h('div', { class: `window modal ${className}`, role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': titleId, style: { '--w': `${width}px` } },
    h('header', { class: 'titlebar' },
      h('span', { class: 'tb-icon', style: { color: '#fff' }, html: ic(icon) }),
      h('h2', { class: 'tb-title', id: titleId }, title),
      h('div', { class: 'tb-controls' }, h('button', { class: 'tb-btn tb-close', 'aria-label': 'Close', onclick: () => requestClose() }, h('span')))),
    bodyEl, footEl);
  const backdrop = h('div', { class: 'modal-backdrop', onmousedown: (e) => { if (closeOnBackdrop && e.target === backdrop) requestClose(); } }, win);
  const api = { el: win, body: bodyEl, foot: footEl, close, requestClose: () => requestClose(), setTitle: (t) => { win.querySelector('.tb-title').textContent = t; } };
  const setBody = (b) => { clear(bodyEl); if (b) bodyEl.append(...[].concat(typeof b === 'function' ? b(api) : b)); };
  const setFoot = (f) => { clear(footEl); const arr = f ? [].concat(typeof f === 'function' ? f(api) : f).filter(Boolean) : []; footEl.append(...arr); footEl.hidden = !arr.length; };
  api.setBody = setBody; api.setFoot = setFoot;
  setBody(body); setFoot(footer);
  function onKey(e) {
    if (openModals[openModals.length - 1] !== api) return;
    if (e.key === 'Escape') { e.stopPropagation(); requestClose(); }
    if (e.key === 'Tab') {
      const f = [...win.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')].filter((x) => !x.disabled && x.offsetParent !== null);
      if (!f.length) return;
      if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
    }
  }
  let closed = false, asking = false;
  async function requestClose(result) {
    if (asking) return;
    if (beforeClose) { asking = true; const ok = await beforeClose(); asking = false; if (!ok) return; }
    close(result);
  }
  function close(result) {
    if (closed) return; closed = true;
    document.removeEventListener('keydown', onKey, true);
    backdrop.remove();
    openModals.splice(openModals.indexOf(api), 1);
    if (!openModals.length) document.body.style.overflow = '';
    onClose?.(result);
    prevFocus?.focus?.({ preventScroll: true });
  }
  document.addEventListener('keydown', onKey, true);
  root.append(backdrop);
  openModals.push(api);
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(() => (win.querySelector('[autofocus]') || win.querySelector('.modal-body input, .modal-body button, .modal-foot button') || win).focus?.());
  return api;
}
export const closeAllModals = () => [...openModals].forEach((m) => m.close());

export function confirmDialog({ title = 'Are you sure?', message, okText = 'OK', danger = false, icon = 'warning' }) {
  return new Promise((resolve) => {
    let result = false;
    const m = openModal({
      title, icon, width: 440, className: 'dialog98', onClose: () => resolve(result),
      body: h('div', { class: 'dialog-msg' }, h('span', { class: 'dm-ic', style: { color: danger ? '#ff6b7d' : '#ffd166' }, html: ic(icon) }), h('div', null, message)),
      footer: [h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancel'),
        h('button', { class: `btn ${danger ? 'btn-danger' : 'btn-primary'}`, autofocus: true, onclick: () => { result = true; m.close(); } }, okText)],
    });
  });
}

export function promptDialog({ title, label, value = '', placeholder = '', okText = 'Save', maxLength = 60, multiline = false, icon = 'edit', extra }) {
  return new Promise((resolve) => {
    let result = null;
    const input = multiline ? h('textarea', { class: 'textarea', maxlength: maxLength, placeholder }, value) : h('input', { class: 'input', value, maxlength: maxLength, placeholder, autofocus: true });
    const err = h('div', { class: 'form-error' });
    const submit = () => { const v = input.value.trim(); if (!v) { err.textContent = 'Please enter a value.'; input.focus(); return; } result = v; m.close(); };
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !multiline) { e.preventDefault(); submit(); } });
    const m = openModal({
      title, icon, width: 440, onClose: () => resolve(result),
      body: h('div', { class: 'stack' }, h('label', { class: 'field' }, label, input), extra || null, err),
      footer: [h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancel'), h('button', { class: 'btn btn-primary', onclick: submit }, okText)],
    });
    setTimeout(() => input.select?.(), 50);
  });
}

// ---------- popover menu ----------
let openMenuEl = null;
export function openMenu(anchor, items) {
  closeMenu();
  const menu = h('div', { class: 'menu', role: 'menu' });
  for (const it of items) {
    if (!it) continue;
    if (it.sep) { menu.append(h('div', { class: 'menu-sep', role: 'separator' })); continue; }
    if (it.heading) { menu.append(h('div', { class: 'menu-label' }, it.heading)); continue; }
    menu.append(h('button', {
      class: `menu-item ${it.danger ? 'danger' : ''}`, role: 'menuitem', disabled: it.disabled,
      onclick: (e) => { e.stopPropagation(); closeMenu(); it.onClick?.(); },
    }, it.icon ? icEl(it.icon) : h('span', { style: { width: '16px' } }), h('span', null, it.label), it.checked ? h('span', { class: 'check' }, '✓') : null));
  }
  document.body.append(menu);
  const r = anchor.getBoundingClientRect();
  const mw = menu.offsetWidth, mh = menu.offsetHeight;
  let left = Math.min(window.innerWidth - mw - 8, Math.max(8, r.right - mw));
  let top = r.bottom + 6;
  if (top + mh > window.innerHeight - 8) top = Math.max(8, r.top - mh - 6);
  menu.style.left = `${left}px`; menu.style.top = `${top}px`;
  openMenuEl = menu;
  menu.querySelector('.menu-item')?.focus();
  const onDoc = (e) => { if (!menu.contains(e.target)) closeMenu(); };
  const onKey = (e) => {
    if (e.key === 'Escape') { closeMenu(); anchor.focus(); }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const btns = [...menu.querySelectorAll('.menu-item:not([disabled])')];
      const i = btns.indexOf(document.activeElement);
      btns[(i + (e.key === 'ArrowDown' ? 1 : -1) + btns.length) % btns.length]?.focus();
    }
  };
  setTimeout(() => { document.addEventListener('mousedown', onDoc); document.addEventListener('keydown', onKey); window.addEventListener('scroll', closeMenu, { once: true, capture: true }); });
  menu._cleanup = () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey); };
}
export function closeMenu() { if (openMenuEl) { openMenuEl._cleanup?.(); openMenuEl.remove(); openMenuEl = null; } }

// ---------- states ----------
export const hourglass = () => h('span', { html: `<svg class="hourglass" viewBox="0 0 26 34" shape-rendering="crispEdges" aria-hidden="true"><path d="M2 1h22v4h-2v5l-6 6v2l6 6v5h2v4H2v-4h2v-5l6-6v-2l-6-6V5H2z" fill="#000"/><path d="M6 5h14v4l-6 6h-2L6 9z" fill="#fff"/><path d="M8 8h10l-4 4h-2z" fill="#e8c35a"/><path d="M6 29v-4l6-6h2l6 6v4z" fill="#fff"/><path d="M8 29v-2l5-4 5 4v2z" fill="#e8c35a"/></svg>` });
export function loadingBox(text = 'Loading...') {
  return h('div', { class: 'loading-box', role: 'status' }, hourglass(), h('div', { class: 'xp-progress', 'aria-hidden': 'true' }), h('span', null, text));
}
export function emptyState({ icon = 'folder', title, text, action }) {
  return h('div', { class: 'empty' }, h('span', { class: 'empty-ic', html: ic(icon) }), h('b', null, title), text ? h('div', null, text) : null,
    action ? h('button', { class: 'btn btn-primary', onclick: action.onClick }, action.label) : null);
}
export function errorBox(err, retry) {
  return h('div', { class: 'bsod', role: 'alert' },
    h('div', { class: 'bsod-title' }, ' RETRO.EXE '),
    h('p', null, 'A problem has been detected and this window could not be displayed.'),
    h('p', null, `* ${err?.message || 'Unknown error'}`),
    retry ? h('p', null, h('button', { class: 'btn btn-chrome', onclick: retry }, 'Press to retry _')) : null);
}

export async function withBusy(btn, fn) {
  if (!btn) return fn();
  btn.classList.add('loading'); btn.setAttribute('aria-busy', 'true'); btn.disabled = true;
  try { return await fn(); } finally { btn.classList.remove('loading'); btn.removeAttribute('aria-busy'); btn.disabled = false; }
}

// ---------- generated pixel avatar ----------
const avatarCache = new Map();
export function avatarSrc(seed = 'guest') {
  if (avatarCache.has(seed)) return avatarCache.get(seed);
  const hsh = hashStr(seed);
  const hues = [200, 280, 320, 170, 40, 230, 140];
  const hue = hues[hsh % hues.length], hue2 = (hue + 140) % 360;
  let cells = '';
  for (let y = 0; y < 6; y++) for (let x = 0; x < 3; x++) {
    const bit = (hsh >> ((y * 3 + x) % 31)) & 1;
    if (bit) { cells += `<rect x="${x + 1}" y="${y + 1}" width="1" height="1"/><rect x="${6 - x}" y="${y + 1}" width="1" height="1"/>`; }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8" shape-rendering="crispEdges"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="hsl(${hue2},70%,30%)"/><stop offset="1" stop-color="hsl(${hue2},60%,14%)"/></linearGradient></defs><rect width="8" height="8" fill="url(#g)"/><g fill="hsl(${hue},95%,68%)">${cells}</g></svg>`;
  const v = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  avatarCache.set(seed, v);
  return v;
}
export const avatarImg = (seed, cls = '') => h('img', { class: `avatar ${cls}`, src: avatarSrc(seed), alt: '' });

// RETRO.EXE content catalog — pure data, shared by client and server.
// Image wallpapers are original AI-generated artwork made for this project;
// "gen" wallpapers are original procedural artwork rendered on-device (see lib/wallgen.js).

export const AESTHETICS = [
  { id: 'dreamcore', name: 'Dreamcore', tagline: "Somewhere you've been before.", font: 'f-serif',
    palette: ['#f7d6e8', '#bfe3ff', '#fff4c2', '#9fd8a8', '#c9b6ff'],
    description: 'Soft-focus memories, impossible doorways and pastel skies that feel like a half-remembered childhood afternoon.',
    keywords: ['pastel', 'clouds', 'doors', 'nostalgia', 'surreal', 'soft', 'childhood'] },
  { id: 'y2k', name: 'Y2K', tagline: 'Chrome, bubbles & butterfly clips.', font: 'f-chrome',
    palette: ['#ff7ad9', '#9be7ff', '#d9d9e6', '#b388ff', '#ffffff'],
    description: 'Liquid chrome, iridescent plastic and the glittering optimism of the millennium bug era.',
    keywords: ['chrome', 'metallic', 'glossy', 'pink', 'futuristic', 'millennium', 'iridescent'] },
  { id: 'windowscore', name: 'Windowscore', tagline: 'Every hill is a desktop.', font: 'f-tahoma',
    palette: ['#245edb', '#3c9a3c', '#ece9d8', '#7ec8ff', '#ffffff'],
    description: 'Rolling green hills, glossy taskbars and the comforting blue of an operating system that booted your childhood.',
    keywords: ['desktop', 'windows', 'hills', 'taskbar', 'os', 'blue', 'start menu'] },
  { id: 'retrocore', name: 'Retrocore', tagline: 'Beige plastic & warm CRT glow.', font: 'f-mono',
    palette: ['#d8cbb0', '#6b8f71', '#e08a3c', '#3a3f58', '#9fd3ff'],
    description: 'Beige towers, cassette tapes and bedroom desks lit by the hum of a cathode-ray monitor.',
    keywords: ['crt', 'beige', 'cassette', 'floppy', 'bedroom', '90s', 'warm'] },
  { id: 'frutiger-aero', name: 'Frutiger Aero', tagline: 'Glossy optimism, crystal water.', font: 'f-aero',
    palette: ['#00b4ff', '#7ee081', '#e8fbff', '#0077c8', '#b8f1ff'],
    description: 'Clean water, glass bubbles, lens flares and the eco-tech utopia promised by mid-2000s interfaces.',
    keywords: ['aero', 'glass', 'bubbles', 'water', 'nature', 'glossy', 'fresh'] },
  { id: 'liminal', name: 'Liminal Spaces', tagline: 'Empty rooms that hum.', font: 'f-thin',
    palette: ['#e8e3c9', '#9fc9c4', '#c8d6d0', '#f2efe6', '#6c7b7a'],
    description: 'Fluorescent hallways, empty pools and transitional places caught between somewhere and nowhere.',
    keywords: ['empty', 'pool', 'hallway', 'fluorescent', 'eerie', 'quiet', 'transitional'] },
  { id: 'vaporwave', name: 'Vaporwave', tagline: 'Aesthetic sunsets, forever.', font: 'f-vapor',
    palette: ['#ff71ce', '#01cdfe', '#05ffa1', '#b967ff', '#fffb96'],
    description: 'Neon grids, marble busts and endless sunsets scored by slowed-down mall music.',
    keywords: ['neon', 'grid', 'sunset', 'marble', 'palm', '80s', 'pink', 'aesthetic'] },
  { id: 'cybercore', name: 'Cybercore', tagline: 'Neon data, endless night.', font: 'f-cyber',
    palette: ['#00f0ff', '#7a00ff', '#ff00a8', '#0b0f2a', '#c8ff00'],
    description: 'Electric circuits, rain-slick megacities and holograms humming with data after midnight.',
    keywords: ['neon', 'city', 'circuit', 'hacker', 'night', 'data', 'futuristic'] },
  { id: 'weirdcore', name: 'Weirdcore', tagline: 'Are you still there?', font: 'f-weird',
    palette: ['#e9e4ff', '#ffe6a8', '#a8e6ff', '#ff9db5', '#5b5b5b'],
    description: 'Low-res uncanny scenes, floating eyes and cryptic messages from an internet that never existed.',
    keywords: ['uncanny', 'eyes', 'strange', 'lowres', 'surreal', 'lost', 'cryptic'] },
  { id: 'ps2', name: 'PS2 Nostalgia', tagline: 'Summer 2004 memory card.', font: 'f-ps2',
    palette: ['#0a1a6b', '#1e90ff', '#bfe8ff', '#f5c542', '#e6e6e6'],
    description: 'Low-poly summers, distance fog and the glowing towers of a console boot screen.',
    keywords: ['console', 'lowpoly', 'fog', 'game', 'summer', 'blue', '2004'] },
  { id: 'old-internet', name: 'Old Internet', tagline: 'Under construction, forever.', font: 'f-web',
    palette: ['#000080', '#00ffff', '#ff00ff', '#ffff00', '#c0c0c0'],
    description: 'Starfield backgrounds, spinning globes, guestbooks and personal homepages from the early web.',
    keywords: ['web', 'homepage', 'stars', 'guestbook', 'glitter', 'globe', '90s'] },
  { id: 'pixelcore', name: 'Pixelcore', tagline: 'One pixel at a time.', font: 'f-pixel',
    palette: ['#2b2d42', '#8d99ae', '#ef476f', '#ffd166', '#06d6a0'],
    description: 'Crisp 8 and 16-bit landscapes, dithered skies and cosy cottages rendered one pixel at a time.',
    keywords: ['pixel', '8bit', '16bit', 'game', 'dither', 'sprite', 'cozy'] },
];
export const AESTHETIC_BY_ID = Object.fromEntries(AESTHETICS.map((a) => [a.id, a]));

export const COLORS = ['blue', 'purple', 'pink', 'green', 'cyan', 'warm', 'dark', 'pastel'];
export const MOODS = ['dreamy', 'eerie', 'cozy', 'energetic', 'calm', 'nostalgic'];
export const DEVICES = ['desktop', 'mobile', 'tablet'];
const ALL = ['desktop', 'mobile', 'tablet'];

const img = (id, title, aesthetic, colors, mood, devices, focus = 50, tier = 'free') => ({
  id: `img-${id}`, kind: 'image', title, aesthetic, colors, mood, devices, focus, tier,
  src: `/img/wp/${id}.jpg`, thumb: `/img/wp/${id}-thumb.webp`,
});
const gen = (id, title, aesthetic, scene, palette, colors, mood, opts = {}, seed = 7, tier = 'free') => ({
  id, kind: 'gen', title, aesthetic, colors, mood, devices: ALL, tier,
  gen: { type: 'gen', scene, palette, seed, opts: { stars: false, sun: true, object: 'none', ...opts } },
});

export const WALLPAPERS = [
  // Dreamcore
  img('dreamcore', 'Somewhere Familiar', 'dreamcore', ['pastel', 'green'], 'dreamy', ALL, 30),
  gen('dc-door', 'Door to the Sky', 'dreamcore', 'clouds', ['#9fd3ff', '#ffe3f1', '#ffffff', '#ffffff', '#a8dca0'], ['pastel', 'blue'], 'dreamy', { object: 'door' }, 11),
  gen('dc-stairs', 'Stairs Up There', 'dreamcore', 'clouds', ['#ffb8d9', '#ffe9c7', '#fff8f0', '#c9b6ff', '#f5c6dc'], ['pastel', 'pink'], 'dreamy', { object: 'stairs' }, 23),
  gen('dc-checker', 'Playroom at 4PM', 'dreamcore', 'checker', ['#bfe3ff', '#fff3d6', '#ffd1e6', '#ffffff', '#ffdf7a'], ['pastel'], 'nostalgic', { object: 'door' }, 5),
  gen('dc-aurora', 'Pastel Lullaby', 'dreamcore', 'aurora', ['#3b3a78', '#f2b8d8', '#ffd6f0', '#b8f0ff', '#8c7bd1'], ['pastel', 'purple'], 'calm', { stars: true }, 4),
  // Y2K
  img('y2k', 'Liquid Millennium', 'y2k', ['pink', 'cyan'], 'energetic', ALL, 50),
  gen('y2k-chrome', 'Chrome Heart Drive', 'y2k', 'chrome', ['#ff8ad8', '#c9a7ff', '#8fe9ff', '#ffd6f5', '#ffffff'], ['pink', 'purple'], 'energetic', {}, 31),
  gen('y2k-silver', 'Silver Lilac 2000', 'y2k', 'chrome', ['#d9d4ff', '#f4f4fb', '#b8c4ff', '#9ad7ff', '#ffffff'], ['pastel', 'purple'], 'calm', {}, 77),
  gen('y2k-mesh', 'Bubblegum Gloss', 'y2k', 'mesh', ['#ffd1ef', '#ff7ad9', '#9be7ff', '#b388ff', '#ffffff'], ['pink', 'pastel'], 'dreamy', {}, 12),
  gen('y2k-bubbles', 'Iridescent Pop', 'y2k', 'bubbles', ['#ff9ee2', '#a4e8ff', '#ffffff', '#ffb3ec', '#c4b5ff'], ['pink', 'cyan'], 'energetic', {}, 41, 'plus'),
  // Windowscore
  img('windowscore', 'Glass Windows Over Hills', 'windowscore', ['blue', 'green'], 'nostalgic', ['desktop', 'tablet'], 50),
  gen('wc-hills', 'Rolling Desktop', 'windowscore', 'hills', ['#1f5fe0', '#8fc8ff', '#7fd34e', '#2f8a1f', '#ffffff'], ['blue', 'green'], 'calm', { sun: true }, 3),
  gen('wc-midnight', 'After Midnight Hill', 'windowscore', 'hills', ['#050a2a', '#1b2f7a', '#1f6b4a', '#0a2a1f', '#7d8fd8'], ['dark', 'blue'], 'calm', { stars: true, sun: false }, 9),
  gen('wc-98', 'Desktop 98', 'windowscore', 'desktop98', ['#008080', '#c0c0c0', '#000080', '#1084d0', '#ffffff'], ['cyan'], 'nostalgic', {}, 14),
  gen('wc-bsod', 'Blue Screen Nostalgia', 'windowscore', 'bsod', ['#0000aa', '#ffffff', '#aaaaaa', '#ffffff', '#ffffff'], ['blue', 'dark'], 'nostalgic', {}, 1),
  // Retrocore
  img('retrocore', 'Bedroom CRT, 1999', 'retrocore', ['warm'], 'cozy', ['desktop', 'tablet'], 40),
  gen('rc-beige', 'Beige Box', 'retrocore', 'desktop98', ['#6b8f71', '#d8cbb0', '#3a3f58', '#7a6f9b', '#fff1d6'], ['green', 'warm'], 'cozy', {}, 8),
  gen('rc-tape', 'Sunset Tape', 'retrocore', 'grid', ['#2b1a3a', '#e08a3c', '#ffd27a', '#e0503c', '#ffb36b'], ['warm'], 'nostalgic', { stars: true }, 16),
  gen('rc-cathode', 'Warm Cathode', 'retrocore', 'mesh', ['#2a2018', '#e08a3c', '#d8cbb0', '#6b8f71', '#9fd3ff'], ['warm', 'dark'], 'cozy', {}, 6),
  gen('rc-arcade', 'Arcade Dusk', 'retrocore', 'pixel', ['#3a2a5a', '#ff9e6b', '#5a3a6b', '#2a1f3a', '#ffd27a'], ['warm', 'purple'], 'cozy', {}, 19),
  // Frutiger Aero
  img('frutiger-aero', 'Crystal Lagoon', 'frutiger-aero', ['cyan', 'green'], 'calm', ALL, 60),
  gen('fa-bubbles', 'Fresh Bubbles', 'frutiger-aero', 'bubbles', ['#0aa8ff', '#bff3ff', '#e8fbff', '#3fd37a', '#0b8fd9'], ['cyan', 'blue'], 'calm', {}, 21),
  gen('fa-install', 'Fresh Install', 'frutiger-aero', 'hills', ['#0a8fff', '#c9f1ff', '#9be15d', '#2fa84f', '#ffffff'], ['green', 'blue'], 'energetic', { sun: true }, 27),
  gen('fa-aqua', 'Aqua Gloss', 'frutiger-aero', 'mesh', ['#dff8ff', '#00b4ff', '#7ee081', '#0077c8', '#b8f1ff'], ['cyan', 'green'], 'calm', {}, 33),
  gen('fa-deep', 'Deep Aqua', 'frutiger-aero', 'bubbles', ['#003f7a', '#00b4ff', '#b8f1ff', '#0077c8', '#00d6a0'], ['blue', 'dark'], 'dreamy', {}, 52, 'plus'),
  // Liminal
  img('liminal', 'Pool Hall, 2AM', 'liminal', ['cyan', 'pastel'], 'eerie', ALL, 50),
  gen('lm-yellow', 'Yellow Hall', 'liminal', 'hallway', ['#d9cf8f', '#b8a86a', '#e8e3c9', '#fffbe0', '#3a3420'], ['warm'], 'eerie', {}, 2),
  gen('lm-mint', 'Mint Corridor', 'liminal', 'hallway', ['#bfe0d6', '#8fb8ad', '#e8f2ee', '#ffffff', '#2f4f4a'], ['green', 'pastel'], 'eerie', {}, 10),
  gen('lm-pool', 'Tile Echo', 'liminal', 'pool', ['#e8f4f4', '#9fc9c4', '#4fc3d9', '#ffffff', '#0f6f8a'], ['cyan', 'pastel'], 'calm', {}, 13),
  gen('lm-night', 'Closed Pool', 'liminal', 'pool', ['#2a3a4a', '#1a2530', '#0f4f6a', '#9fe7ff', '#05141f'], ['dark', 'cyan'], 'eerie', {}, 17),
  // Vaporwave
  img('vaporwave', 'Marble Sunset', 'vaporwave', ['pink', 'purple'], 'nostalgic', ALL, 50),
  gen('vw-grid', 'Sunset Protocol', 'vaporwave', 'grid', ['#1a0033', '#ff71ce', '#fffb96', '#ff71ce', '#01cdfe'], ['pink', 'purple'], 'energetic', { stars: true }, 4),
  gen('vw-miami', 'Mall Mainframe', 'vaporwave', 'grid', ['#011a3a', '#01cdfe', '#ffb3f0', '#b967ff', '#05ffa1'], ['cyan', 'purple'], 'dreamy', { stars: true }, 44),
  gen('vw-checker', 'Lobby Music', 'vaporwave', 'checker', ['#b967ff', '#ffb3f0', '#01cdfe', '#ff71ce', '#fffb96'], ['pink', 'cyan'], 'dreamy', { object: 'none' }, 18),
  gen('vw-mesh', 'Plaza Haze', 'vaporwave', 'mesh', ['#2a0a4a', '#ff71ce', '#01cdfe', '#b967ff', '#fffb96'], ['purple', 'pink'], 'calm', {}, 29, 'plus'),
  // Cybercore
  img('cybercore', 'Holo City', 'cybercore', ['dark', 'cyan'], 'energetic', ALL, 50),
  gen('cy-circuit', 'Trace Route', 'cybercore', 'circuit', ['#05071a', '#00f0ff', '#ff00a8', '#7a00ff', '#00f0ff'], ['dark', 'cyan'], 'energetic', {}, 6),
  gen('cy-magenta', 'Night Shift', 'cybercore', 'circuit', ['#0b0014', '#ff00a8', '#c8ff00', '#7a00ff', '#ff00a8'], ['dark', 'pink'], 'energetic', {}, 37),
  gen('cy-grid', 'Data Plane', 'cybercore', 'grid', ['#000008', '#0b0f2a', '#00f0ff', '#7a00ff', '#00f0ff'], ['dark', 'cyan'], 'calm', { stars: true, sun: false }, 22),
  gen('cy-towers', 'Server Fog', 'cybercore', 'ps2', ['#05001a', '#1a0040', '#7a00ff', '#00f0ff', '#ff00a8'], ['dark', 'purple'], 'eerie', {}, 15, 'plus'),
  // Weirdcore
  img('weirdcore', 'Indoor Weather', 'weirdcore', ['pastel', 'warm'], 'eerie', ALL, 50),
  gen('wd-eye', 'Are You Still There?', 'weirdcore', 'checker', ['#e9e4ff', '#fff6d6', '#a8e6ff', '#ffffff', '#ff9db5'], ['pastel'], 'eerie', { object: 'eye' }, 3),
  gen('wd-hall', 'Wrong Hallway', 'weirdcore', 'hallway', ['#ffd6e0', '#c9e4a8', '#fff0c9', '#ffffff', '#5b3a5b'], ['pastel', 'pink'], 'eerie', {}, 26),
  gen('wd-sky', 'The Sky Is Watching', 'weirdcore', 'clouds', ['#a8e6ff', '#fff6d6', '#ffffff', '#ff9db5', '#b8e6a0'], ['pastel', 'blue'], 'eerie', { object: 'eye' }, 32),
  gen('wd-door', 'Exit Not Found', 'weirdcore', 'checker', ['#3a3a4a', '#9a8fb8', '#e9e4ff', '#5b5b5b', '#ffe6a8'], ['dark', 'purple'], 'eerie', { object: 'door' }, 8),
  // PS2
  img('ps2', 'Summer 2004', 'ps2', ['blue', 'warm'], 'nostalgic', ['desktop', 'tablet'], 50),
  gen('ps-boot', 'Boot Sequence', 'ps2', 'ps2', ['#000418', '#04145a', '#1e90ff', '#bfe8ff', '#bfe8ff'], ['dark', 'blue'], 'nostalgic', {}, 2),
  gen('ps-fog', 'Memory Fog', 'ps2', 'ps2', ['#02101f', '#0a3a5a', '#2fd3c4', '#bffff4', '#e6e6e6'], ['dark', 'cyan'], 'calm', {}, 24),
  gen('ps-plane', 'Loading Plane', 'ps2', 'grid', ['#000a2a', '#0a1a6b', '#bfe8ff', '#1e90ff', '#1e90ff'], ['blue', 'dark'], 'calm', { stars: true, sun: false }, 36),
  gen('ps-disc', 'Disc Read Error', 'ps2', 'mesh', ['#0a1a6b', '#1e90ff', '#bfe8ff', '#f5c542', '#3a6bff'], ['blue'], 'nostalgic', {}, 40),
  // Old Internet
  gen('oi-stars', 'Homepage After Dark', 'old-internet', 'stars', ['#000033', '#000080', '#ffffff', '#00ffff', '#ff00ff'], ['dark', 'blue'], 'nostalgic', {}, 5),
  gen('oi-rainbow', 'Webring Night', 'old-internet', 'stars', ['#0a0014', '#2a0050', '#ffff00', '#ff00ff', '#00ffff'], ['dark', 'purple'], 'energetic', {}, 21),
  gen('oi-window', 'Guestbook Window', 'old-internet', 'desktop98', ['#000080', '#c0c0c0', '#800080', '#ff00ff', '#ffff00'], ['blue', 'purple'], 'nostalgic', {}, 30),
  gen('oi-tile', 'Under Construction', 'old-internet', 'checker', ['#000033', '#000080', '#ffff00', '#000000', '#00ffff'], ['dark', 'warm'], 'energetic', { object: 'none' }, 12),
  // Pixelcore
  gen('px-night', 'Cottage Night', 'pixelcore', 'pixel', ['#1a1035', '#5a3a8a', '#2b2d42', '#1d3a2a', '#ffd166'], ['dark', 'purple'], 'cozy', {}, 7),
  gen('px-sunset', 'Pixel Sunset', 'pixelcore', 'pixel', ['#3a1f5a', '#ff9e6b', '#5a2a4a', '#2a3a2a', '#ffe08a'], ['warm', 'purple'], 'cozy', {}, 28),
  gen('px-dawn', 'Teal Dawn', 'pixelcore', 'pixel', ['#0f3a4a', '#9fe0c9', '#2a5a6a', '#1a4a3a', '#fff4c2'], ['cyan', 'green'], 'calm', {}, 45),
  gen('px-candy', 'Candy Hills', 'pixelcore', 'pixel', ['#ef476f', '#ffd166', '#8d5aa8', '#06d6a0', '#ffffff'], ['pink', 'warm'], 'energetic', {}, 50, 'plus'),
];
export const WP_BY_ID = Object.fromEntries(WALLPAPERS.map((w) => [w.id, w]));

export const COLLECTIONS = [
  { id: 'c-hills', title: 'Desktop Hills Forever', aesthetic: 'windowscore', description: 'Green hills and blue skies, as preinstalled by memory.', items: ['img-windowscore', 'wc-hills', 'wc-midnight', 'fa-install', 'wc-98'] },
  { id: 'c-pools', title: 'Pool Rooms & Hallways', aesthetic: 'liminal', description: 'Tiled echoes and fluorescent corridors. Nobody is here.', items: ['img-liminal', 'lm-pool', 'lm-yellow', 'lm-mint', 'lm-night'] },
  { id: 'c-chrome', title: 'Chrome Futures', aesthetic: 'y2k', description: 'Metallic blobs and iridescent gloss from the year 2000.', items: ['img-y2k', 'y2k-chrome', 'y2k-silver', 'y2k-mesh', 'y2k-bubbles'] },
  { id: 'c-aero', title: 'Bubble Utopia', aesthetic: 'frutiger-aero', description: 'Clean water, glass and lens flares. Everything is going to be fine.', items: ['img-frutiger-aero', 'fa-bubbles', 'fa-aqua', 'fa-install', 'fa-deep'] },
  { id: 'c-sunset', title: 'Sunset Grid', aesthetic: 'vaporwave', description: 'Neon horizons for late-night mall walks.', items: ['img-vaporwave', 'vw-grid', 'vw-miami', 'rc-tape', 'vw-mesh'] },
  { id: 'c-neon', title: 'Neon Night Shift', aesthetic: 'cybercore', description: 'Glowing traces and cities that never log off.', items: ['img-cybercore', 'cy-circuit', 'cy-magenta', 'cy-grid', 'cy-towers'] },
  { id: 'c-familiar', title: 'Somewhere Familiar', aesthetic: 'dreamcore', description: "Pastel places you're sure you've visited in a dream.", items: ['img-dreamcore', 'dc-door', 'dc-stairs', 'dc-checker', 'dc-aurora'] },
  { id: 'c-lost', title: 'Are You Lost?', aesthetic: 'weirdcore', description: 'The exit is always one more door away.', items: ['img-weirdcore', 'wd-eye', 'wd-hall', 'wd-sky', 'wd-door'] },
  { id: 'c-memcard', title: 'Memory Card Summer', aesthetic: 'ps2', description: 'Low-poly beaches and the towers that greeted every boot.', items: ['img-ps2', 'ps-boot', 'ps-fog', 'ps-plane', 'ps-disc'] },
  { id: 'c-homepage', title: 'Homepage After Dark', aesthetic: 'old-internet', description: 'Starfields, guestbooks and spinning globes. Best viewed at 800×600.', items: ['oi-stars', 'oi-rainbow', 'oi-window', 'oi-tile', 'wc-bsod'] },
  { id: 'c-8bit', title: '8-Bit Evenings', aesthetic: 'pixelcore', description: 'Cosy dithered skies and glowing cottage windows.', items: ['px-night', 'px-sunset', 'px-dawn', 'px-candy', 'rc-arcade'] },
  { id: 'c-beige', title: 'Beige Box Bedroom', aesthetic: 'retrocore', description: 'Warm CRT light, cassette stacks and floppy disks.', items: ['img-retrocore', 'rc-beige', 'rc-cathode', 'rc-arcade', 'rc-tape'] },
  { id: 'c-midnight', title: 'Midnight Computer Club', aesthetic: 'windowscore', description: 'For staying up way past bedtime with the monitor glow.', items: ['wc-midnight', 'wc-bsod', 'oi-stars', 'ps-boot', 'lm-night'] },
];
export const COLLECTION_BY_ID = Object.fromEntries(COLLECTIONS.map((c) => [c.id, c]));
export const FEATURED_COLLECTIONS = ['c-familiar', 'c-hills', 'c-chrome', 'c-pools', 'c-aero', 'c-sunset'];

export const ICON_PACKS = [
  { id: 'luna-glass', name: 'Luna Glass', aesthetic: 'windowscore', config: { style: 'aero', shape: 'squircle', bg: '#2f6cf5', fg: '#ffffff', accent: '#7ee0ff' } },
  { id: 'chrome-heart', name: 'Chrome Heart', aesthetic: 'y2k', config: { style: 'chrome', shape: 'circle', bg: '#ffb3ec', fg: '#2a2a3a', accent: '#ff7ad9' } },
  { id: 'bitmap-garden', name: 'Bitmap Garden', aesthetic: 'pixelcore', config: { style: 'pixel', shape: 'square', bg: '#2b2d42', fg: '#ffd166', accent: '#06d6a0' } },
  { id: 'classic-98', name: 'Classic 98', aesthetic: 'windowscore', config: { style: 'win98', shape: 'square', bg: '#c0c0c0', fg: '#000080', accent: '#008080' } },
  { id: 'bubblegum-orb', name: 'Bubblegum Orb', aesthetic: 'y2k', config: { style: 'bubble', shape: 'circle', bg: '#ff7ad9', fg: '#ffffff', accent: '#9be7ff' } },
  { id: 'neon-grid', name: 'Neon Grid', aesthetic: 'cybercore', config: { style: 'neon', shape: 'squircle', bg: '#0b0f2a', fg: '#00f0ff', accent: '#ff00a8' } },
  { id: 'pastel-ghost', name: 'Pastel Ghost', aesthetic: 'dreamcore', config: { style: 'outline', shape: 'circle', bg: '#ffffff', fg: '#7a5aa8', accent: '#ffb8d9' } },
  { id: 'sticker-sunset', name: 'Sticker Sunset', aesthetic: 'vaporwave', config: { style: 'sticker', shape: 'squircle', bg: '#ff71ce', fg: '#1a0033', accent: '#01cdfe' } },
  { id: 'aqua-drop', name: 'Aqua Drop', aesthetic: 'frutiger-aero', config: { style: 'bubble', shape: 'squircle', bg: '#00a8ff', fg: '#ffffff', accent: '#7ee081' } },
  { id: 'memory-card', name: 'Memory Card', aesthetic: 'ps2', config: { style: 'neon', shape: 'square', bg: '#04145a', fg: '#bfe8ff', accent: '#1e90ff' } },
  { id: 'webring', name: 'Webring', aesthetic: 'old-internet', config: { style: 'win98', shape: 'square', bg: '#c0c0c0', fg: '#ff00ff', accent: '#000080' } },
  { id: 'pool-tile', name: 'Pool Tile', aesthetic: 'liminal', config: { style: 'outline', shape: 'square', bg: '#e8f4f4', fg: '#2f6f73', accent: '#9fc9c4' } },
  { id: 'crt-amber', name: 'CRT Amber', aesthetic: 'retrocore', config: { style: 'pixel', shape: 'squircle', bg: '#2a2018', fg: '#ffb36b', accent: '#e08a3c' } },
  { id: 'eyeball-club', name: 'Eyeball Club', aesthetic: 'weirdcore', config: { style: 'sticker', shape: 'hexagon', bg: '#e9e4ff', fg: '#5b5b5b', accent: '#ff9db5' }, tier: 'plus' },
];
export const ICONPACK_BY_ID = Object.fromEntries(ICON_PACKS.map((p) => [p.id, p]));

const comp = (base, adjust = {}, overlays = {}, caption = {}) => ({ base, adjust, overlays, caption });

export const EXAMPLE_THEMES = [
  { name: 'Windows XP After Midnight', folder: 'Desktop', description: 'The family computer at 1AM. Quiet hills, a starry sky and a taskbar glowing softly in the dark.',
    data: { wallpaper: comp({ type: 'wp', id: 'wc-midnight' }, {}, { vignette: 35, grain: 15 }),
      palette: ['#050a2a', '#1b2f7a', '#3d7bff', '#7ee0ff', '#e6ecff'], icons: { style: 'aero', shape: 'squircle', bg: '#1f4fd1', fg: '#ffffff', accent: '#7ee0ff', pack: 'luna-glass' },
      widgets: { clock: 'xp', h24: false, date: 'pill' }, decor: { stickers: ['moon', 'sparkle'] } } },
  { name: 'Forgotten Internet Cafe', folder: 'Liminal', description: 'Rows of CRTs still humming after closing time. Amber light, dust and the smell of old keyboards.',
    data: { wallpaper: comp({ type: 'wp', id: 'img-retrocore' }, { saturation: 80, contrast: 108 }, { scanlines: 40, grain: 30, vignette: 40 }, { text: 'session expired', style: 'vcr', pos: 'bottom' }),
      palette: ['#1a140e', '#3a2c1e', '#e08a3c', '#9fd3ff', '#f3e6cf'], icons: { style: 'pixel', shape: 'squircle', bg: '#2a2018', fg: '#ffb36b', accent: '#e08a3c', pack: 'crt-amber' },
      widgets: { clock: 'lcd', h24: true, date: 'calendar98' }, decor: { stickers: ['cd', 'cursor'] } } },
  { name: 'Dreamcore: Somewhere Familiar', folder: 'Dreams', description: "A door in a meadow that you're sure you walked through once. Soft pastels, warm haze and a gentle message.",
    data: { wallpaper: comp({ type: 'wp', id: 'img-dreamcore' }, { brightness: 105, saturation: 90 }, { grain: 25, vignette: 20 }, { text: 'you were here before', style: 'serif', pos: 'top' }),
      palette: ['#2a2350', '#f7d6e8', '#c9b6ff', '#ffb8d9', '#fffaf0'], icons: { style: 'outline', shape: 'circle', bg: '#ffffff', fg: '#7a5aa8', accent: '#ffb8d9', pack: 'pastel-ghost' },
      widgets: { clock: 'analog', h24: false, date: 'minimal' }, decor: { stickers: ['cloud', 'butterfly', 'flower'] } } },
  { name: 'Y2K Chrome Dreams', folder: 'Y2K', description: 'Liquid chrome, bubblegum pink and the electric optimism of the year 2000.',
    data: { wallpaper: comp({ type: 'wp', id: 'img-y2k' }, { saturation: 115 }, { chroma: 20 }),
      palette: ['#1a0b2e', '#3a1f5a', '#ff7ad9', '#9be7ff', '#ffffff'], icons: { style: 'chrome', shape: 'circle', bg: '#ffb3ec', fg: '#2a2a3a', accent: '#ff7ad9', pack: 'chrome-heart' },
      widgets: { clock: 'flip', h24: false, date: 'pill' }, decor: { stickers: ['heart', 'star', 'sparkle'] } } },
  { name: 'PS2 Summer 2004', folder: 'Games', description: 'Low-poly beach town, distance fog and a memory card full of saves you never finished.',
    data: { wallpaper: comp({ type: 'wp', id: 'img-ps2' }, { saturation: 110, contrast: 105 }, { scanlines: 15, chroma: 10 }),
      palette: ['#04145a', '#0a2a8a', '#1e90ff', '#f5c542', '#e6f4ff'], icons: { style: 'neon', shape: 'square', bg: '#04145a', fg: '#bfe8ff', accent: '#1e90ff', pack: 'memory-card' },
      widgets: { clock: 'pixel', h24: false, date: 'pill' }, decor: { stickers: ['cd', 'star'] } } },
  { name: 'Blue Screen Nostalgia', folder: 'Desktop', description: 'A fatal exception has occurred — in the best way. Press any key to remember.',
    data: { wallpaper: comp({ type: 'wp', id: 'wc-bsod' }, {}, { scanlines: 35, vignette: 30, vhs: 20 }),
      palette: ['#00004a', '#0000aa', '#5a8cff', '#ffffff', '#ffffff'], icons: { style: 'win98', shape: 'square', bg: '#c0c0c0', fg: '#000080', accent: '#008080', pack: 'classic-98' },
      widgets: { clock: 'lcd', h24: true, date: 'calendar98' }, decor: { stickers: ['cursor', 'loading'] } } },
];

// Palette presets offered in the generator, derived from each aesthetic.
export const GEN_PRESETS = AESTHETICS.map((a) => ({ id: a.id, name: a.name, palette: a.palette }));

export const PREMIUM_FEATURES = [
  { title: 'Exclusive aesthetic packs', text: 'Seasonal drops of wallpapers, icon packs and widget skins.' },
  { title: 'Advanced studio tools', text: 'Layer stacks, custom fonts for captions and animated wallpapers.' },
  { title: 'Extra export options', text: '4K/8K exports, .ico and Android adaptive icon bundles.' },
  { title: 'Premium collections', text: 'Curated collections from community artists with revenue share.' },
  { title: 'AI artwork credits', text: 'Optional credit packs for server-side AI wallpaper generation.' },
];

// Shared validation / normalization used by BOTH the browser and the server.
// Everything that is persisted (themes, wallpaper compositions) passes through here,
// so the server never stores unexpected shapes and the client never renders them.

export const SCENES = ['grid', 'hills', 'clouds', 'bubbles', 'hallway', 'pool', 'chrome', 'circuit', 'checker', 'stars', 'pixel', 'desktop98', 'ps2', 'bsod', 'aurora', 'mesh'];
export const SCENE_LABELS = {
  grid: 'Sunset Grid', hills: 'Rolling Hills', clouds: 'Dream Clouds', bubbles: 'Aero Bubbles', hallway: 'Endless Hallway',
  pool: 'Pool Room', chrome: 'Liquid Chrome', circuit: 'Neon Circuit', checker: 'Checker Void', stars: 'Starfield Homepage',
  pixel: 'Pixel Landscape', desktop98: 'Desktop 98', ps2: 'Memory Fog Towers', bsod: 'Blue Screen', aurora: 'Midnight Aurora', mesh: 'Gloss Gradient',
};
export const SCENE_OBJECTS = ['none', 'door', 'stairs', 'eye'];
export const ICON_STYLES = ['aero', 'chrome', 'pixel', 'win98', 'bubble', 'neon', 'outline', 'sticker'];
export const ICON_SHAPES = ['squircle', 'circle', 'square', 'hexagon', 'none'];
export const CLOCK_STYLES = ['lcd', 'xp', 'analog', 'flip', 'pixel'];
export const DATE_STYLES = ['pill', 'calendar98', 'minimal', 'sticky'];
export const STICKERS = ['sparkle', 'star', 'heart', 'butterfly', 'cd', 'cursor', 'cloud', 'smiley', 'moon', 'eye', 'flower', 'loading'];
export const CAPTION_STYLES = ['pixel', 'chrome', 'serif', 'dialog', 'vcr', 'glitch'];
export const CAPTION_POS = ['top', 'center', 'bottom'];

const HEX = /^#[0-9a-f]{6}$/i;
const UPLOAD_URL = /^\/uploads\/[a-z0-9_-]{8,64}\.(png|jpg|webp)$/;

export const clamp = (n, lo, hi, d) => {
  n = Number(n);
  if (!Number.isFinite(n)) return d;
  return Math.min(hi, Math.max(lo, n));
};
const str = (s, max, d = '') => (typeof s === 'string' ? s.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max) : d);
const color = (c, d) => (typeof c === 'string' && HEX.test(c) ? c.toLowerCase() : d);
const oneOf = (v, list, d) => (list.includes(v) ? v : d);

export const DEFAULT_PALETTE = ['#0b1030', '#1b2a6b', '#3d8bff', '#ff8ad8', '#eaf2ff'];

export function normalizeBase(b) {
  b = b && typeof b === 'object' ? b : {};
  if (b.type === 'upload' && typeof b.url === 'string' && UPLOAD_URL.test(b.url)) return { type: 'upload', url: b.url, label: str(b.label, 60, 'My upload') };
  if (b.type === 'gen') {
    const pal = Array.isArray(b.palette) ? b.palette.slice(0, 5).map((c, i) => color(c, DEFAULT_PALETTE[i])) : DEFAULT_PALETTE.slice();
    while (pal.length < 5) pal.push(DEFAULT_PALETTE[pal.length]);
    const opts = b.opts && typeof b.opts === 'object' ? b.opts : {};
    return {
      type: 'gen', scene: oneOf(b.scene, SCENES, 'mesh'), palette: pal, seed: Math.floor(clamp(b.seed, 1, 999999, 1)),
      opts: { stars: !!opts.stars, sun: opts.sun !== false, object: oneOf(opts.object, SCENE_OBJECTS, 'none') },
    };
  }
  return { type: 'wp', id: str(b.id, 60, 'img-windowscore') || 'img-windowscore' };
}

export function defaultComposition(base) {
  return normalizeComposition({ base: base || { type: 'wp', id: 'img-windowscore' } });
}

export function normalizeComposition(c) {
  c = c && typeof c === 'object' ? c : {};
  const a = c.adjust || {}, o = c.overlays || {}, cap = c.caption || {};
  return {
    base: normalizeBase(c.base),
    adjust: {
      brightness: clamp(a.brightness, 30, 170, 100), contrast: clamp(a.contrast, 30, 170, 100),
      saturation: clamp(a.saturation, 0, 200, 100), hue: clamp(a.hue, -180, 180, 0), blur: clamp(a.blur, 0, 20, 0),
    },
    overlays: {
      grain: clamp(o.grain, 0, 100, 0), scanlines: clamp(o.scanlines, 0, 100, 0), chroma: clamp(o.chroma, 0, 100, 0),
      vignette: clamp(o.vignette, 0, 100, 0), vhs: clamp(o.vhs, 0, 100, 0),
      tint: color(o.tint, '#000000'), tintAmount: clamp(o.tintAmount, 0, 100, 0),
    },
    caption: { text: str(cap.text, 80), style: oneOf(cap.style, CAPTION_STYLES, 'pixel'), pos: oneOf(cap.pos, CAPTION_POS, 'center') },
  };
}

export function normalizeIcons(i) {
  i = i && typeof i === 'object' ? i : {};
  return {
    style: oneOf(i.style, ICON_STYLES, 'aero'), shape: oneOf(i.shape, ICON_SHAPES, 'squircle'),
    bg: color(i.bg, '#2f6cf5'), fg: color(i.fg, '#ffffff'), accent: color(i.accent, '#7ee0ff'),
    pack: str(i.pack, 40, ''),
  };
}

export function normalizeWidgets(w) {
  w = w && typeof w === 'object' ? w : {};
  return { clock: oneOf(w.clock, CLOCK_STYLES, 'xp'), h24: !!w.h24, date: oneOf(w.date, DATE_STYLES, 'pill'), showDate: w.showDate !== false };
}

export function normalizeDecor(d) {
  d = d && typeof d === 'object' ? d : {};
  const st = Array.isArray(d.stickers) ? [...new Set(d.stickers.filter((s) => STICKERS.includes(s)))].slice(0, 6) : [];
  return { stickers: st, scanlines: !!d.scanlines, particles: d.particles !== false };
}

export function normalizeThemeData(t) {
  t = t && typeof t === 'object' ? t : {};
  const pal = Array.isArray(t.palette) ? t.palette.slice(0, 5).map((c, i) => color(c, DEFAULT_PALETTE[i])) : DEFAULT_PALETTE.slice();
  while (pal.length < 5) pal.push(DEFAULT_PALETTE[pal.length]);
  return {
    wallpaper: normalizeComposition(t.wallpaper), palette: pal, icons: normalizeIcons(t.icons),
    widgets: normalizeWidgets(t.widgets), decor: normalizeDecor(t.decor),
  };
}

export function normalizeThemeMeta(m) {
  m = m && typeof m === 'object' ? m : {};
  return { name: str(m.name, 60, 'Untitled Theme') || 'Untitled Theme', description: str(m.description, 280), folder: str(m.folder, 30) };
}

export const ITEM_TYPES = ['wallpaper', 'collection', 'iconpack', 'aesthetic', 'post', 'theme', 'creation'];
export const isItemId = (s) => typeof s === 'string' && /^[a-z0-9_-]{1,60}$/i.test(s);

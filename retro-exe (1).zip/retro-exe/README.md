# RETRO.EXE — Retro Aesthetic Studio

A forgotten 2003 operating system that's also a dream world. You can browse 12 nostalgic aesthetics, build wallpapers, icon and widget sets, and full desktop themes, then share them with the community.

## Quick start (no terminal)

1. Install **Node.js 20 or newer** (LTS) from https://nodejs.org.
2. **Windows:** double-click `Start RETRO.EXE (Windows).bat`. **Mac/Linux:** run `./start.sh`.
3. The first run installs dependencies (about a minute). Then your browser opens http://localhost:3000. Keep the window open while you use the app; close it to stop.

## Run

```bash
npm install
npm start            # http://localhost:3000  (PORT env to change)
npm run dev          # auto-restart on server changes
```

Requires Node 18+ (uses built-in `fetch`). Data is stored in `data/retro.db` (SQLite) and `data/uploads/`. Both are created on first run.

## Environment (all optional)

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | HTTP port (binds 0.0.0.0) |
| `OPENAI_API_KEY` | — | Turns on real AI wallpaper generation (server-side only, never sent to the browser) |
| `OPENAI_IMAGE_MODEL` | `gpt-image-1` | Image model used for AI generation |
| `AI_DAILY_LIMIT` | `5` | AI generations per account per day |
| `MOD_USERNAMES` | — | Comma-separated usernames with moderator rights |

Without `OPENAI_API_KEY`, the **Dream Machine** still works. It turns your prompt into original procedural wallpapers in the browser, and the app tells users what's needed to turn on true AI generation. AI generation requires a registered account.

**Moderation:** the first registered account automatically becomes an admin. Use `MOD_USERNAMES` to add more moderators. A post is hidden automatically after 3 reports, and moderators review it at `/mod`.

## Use a theme on your PC / browser

Websites can't restyle Windows or the browser itself. So **My Digital World → open a theme → "Use on my PC / browser"** builds a ZIP of standard theme files, entirely in the browser:

| In the ZIP | What it does |
|---|---|
| `Install Windows theme.bat` + `windows/wallpaper.png` | Copies the wallpaper to `%LOCALAPPDATA%\RETRO.EXE\Themes\<theme>` and writes and opens a normal Windows `.theme` file that sets the wallpaper, accent colour and dark/light mode. No admin rights needed. Undo in Settings → Personalisation → Themes. |
| `browser/chrome-edge/` | A Chrome theme (manifest v3) with a glossy tab bar, palette toolbar and new-tab wallpaper. Install with Load unpacked in chrome:// or edge://extensions. |
| `browser/firefox/` | A Firefox theme (manifest v2). Loads as a temporary add-on; needs free Mozilla signing to keep permanently. |
| `icons/*.ico` | Multi-size icons (16–256 px) for shortcuts, folders, This PC and Recycle Bin. |
| `rainmeter/RETRO.EXE/` | A desktop clock and date skin in the theme's colours, for the free Rainmeter app. |
| `START HERE.txt` | Step-by-step instructions, plus manual alternatives. |

The same button appears on community posts. Code: `public/js/lib/pcexport.js` (builders) and `public/js/components/pcExport.js` (dialog).

## Structure

```
server/   index.js (Express API + static), db.js (schema), auth.js (scrypt + tokens), seed.js (sample community)
public/
  index.html            app shell (desktop, window, taskbar, start menu, boot screen)
  css/                  base (tokens, effects), components, pages
  js/core/              dom helpers, router, store (pub/sub + persistence), api client, ui (modals/toasts/menus)
  js/data/              aesthetic catalog, wallpapers, icon packs, collections, theme schema
  js/lib/               wallgen (procedural art), render (canvas compositor/export), iconkit, widgets, zip, effects
  js/components/        cards, device previews, theme editor, auth, community, pickers
  js/pages/             one module per route
  img/wp/               original wallpapers (jpg + webp thumbnails)
tools/    smoke.mjs + flows.mjs (Playwright checks), preview-gen.mjs
assets-src/  full-resolution source art (not served)
```

## Content & licensing

- All raster wallpapers are original AI-generated artwork made for this project. All other art (Old Internet, Pixelcore, XP Midnight, Internet Café and more) is procedural and drawn in code.
- Fonts: VT323 and Press Start 2P, under the SIL Open Font License (`public/fonts/OFL.txt`).
- Community profiles marked **SAMPLE** are demo content. Users can hide them under Settings → Community.

## Future premium (not implemented — no payments)

Items marked **PLUS** (for example, the Eyeball Club icon pack) show where premium packs, advanced tools, high-res exports and AI credits could go. Everything in the app is free and usable today.

## Dev checks

```bash
node tools/smoke.mjs                 # load every route, report console/page/network errors
node tools/smoke.mjs /,/studio mobile
node tools/flows.mjs                 # end-to-end: favourites, collections, themes, studio, export, auth, share, like, report, mod
```
(First run: `npx playwright install chromium`.) Run `flows.mjs` against a throwaway database, because its test account becomes the admin.
